<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Session;
use Stripe;

class PaymentController extends Controller
{
    public function stripe()
    {
        return view('stripe');
    }

    public function stripePost(Request $request)
    {
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
        Stripe\Charge::create ([
                "amount" => 100,
                "currency" => "USD",
                "source" => $request->stripeToken,
                "description" => "This payment is testing purpose of techsolutionstuff",
        ]);

        Session::flash('success', 'Payment Successfull!');
           
        return back();
    }
}