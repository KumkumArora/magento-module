<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>App Name - @yield('title')</title>
<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/fontawesome.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
