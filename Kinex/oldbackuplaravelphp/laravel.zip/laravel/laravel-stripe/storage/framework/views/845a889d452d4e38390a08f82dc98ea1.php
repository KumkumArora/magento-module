<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/fontawesome.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
<?php /**PATH /var/www/html/laravel/laravel-stripe/resources/views/partials/head.blade.php ENDPATH**/ ?>