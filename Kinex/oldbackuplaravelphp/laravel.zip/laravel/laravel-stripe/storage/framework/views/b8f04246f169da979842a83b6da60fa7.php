<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script>
    $('[data-toggle="tooltip"]').tooltip();
</script>
<?php /**PATH /var/www/html/laravel/laravel-stripe/resources/views/partials/footer.blade.php ENDPATH**/ ?>