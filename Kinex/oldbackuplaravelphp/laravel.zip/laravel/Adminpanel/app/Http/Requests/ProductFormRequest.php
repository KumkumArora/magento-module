<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'product_name' => 'required',
            'sku' => 'required|unique:products,sku',
            'category' => 'required',
            'featured_image' => 'required',
            'file.*' => 'required',
            'stock' => 'required',
            'price' => 'required',
            'description' => 'required',
            'attribute' => 'required',
        ];
    }

    public function messages()
    {
        return [
            'product_name.required' => 'Please Enter Product name',
            'sku.required' => 'Please enter Sku code',
            'category.required' => 'select category',
            'featured_image.required' => 'Upload Featured image',
            'file.*.required' => 'Upload multiple images of product',
            'stock.required' => 'please enter stock',
            'price.required' => 'please enter price',
            'description.required' => 'please enter the description of product',
            'attribute.required' => 'Please select the type of Product',
        ];
    }
}