<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Stripe\Exception\CardException;
use Stripe\StripeClient;
use App\Models\Cart;
use App\Models\Order;

class PaymentController extends Controller
{
    private $stripe;
    public function __construct()
    {
        $this->stripe = new StripeClient(config('stripe.api_keys.secret_key'));
    }

    public function index()
    {   
        $getCartItems= Cart::with('products','user')->where('user_id', Auth::id())->get();
        $total = 0;
        foreach($getCartItems as $value)
        {   
            $total  +=  $value->qty* $value->products->price;
        }
        return view('payment', compact('total'));
    }

    public function payment(Request $request)
    {    
        $validator = Validator::make($request->all(), [
            'fullName' => 'required',
            'cardNumber' => 'required',
            'month' => 'required',
            'year' => 'required',
            'cvv' => 'required'
        ]);

        if ($validator->fails()) {
            $request->session()->flash('danger', $validator->errors()->first());
            return response()->redirectTo('checkout');
        }

        $token = $this->createToken($request);
        if (!empty($token['error'])) {
            $request->session()->flash('danger', $token['error']);
            return response()->redirectTo('/');
        }
        if (empty($token['id'])) {
            $request->session()->flash('danger', 'Payment failed.');
            return response()->redirectTo('/');
        }
        
        $amount = 100* $request['amount'];
        $charge = $this->createCharge($token['id'],$amount);    
        if (!empty($charge) && $charge['status'] == 'succeeded') {

            $addOrder = new Order();
            $addOrder->user_id = Auth::id();
            $addOrder->order_no = rand(100, 10000);
            $addOrder->transection_id = $charge['id'];
            $addOrder->transection_amount = $charge['amount']/100;
            $addOrder->save();

            $getCartItems= Cart::where('user_id', Auth::id())->get();
            foreach($getCartItems as $value)
            {   
                $cartIds[] = $value->id;
            }
            $order = Order::find($addOrder['id']);
            $order->orderedProducts()->attach($cartIds);

            $cartItems= Cart::where('user_id', Auth::id())->get();
            $cartItems->each->delete();
            
            $request->session()->flash('success', 'Your Payment Successfully Done thanks for the shopping.');
            
        } else {
            $request->session()->flash('danger', 'Payment failed.');
        }
        return response()->redirectTo('products');
    }

    private function createToken($cardData)
    {
        $token = null;
        try {
            $token = $this->stripe->tokens->create([
                'card' => [
                    'number' => $cardData['cardNumber'],
                    'exp_month' => $cardData['month'],
                    'exp_year' => $cardData['year'],
                    'cvc' => $cardData['cvv']
                ]
            ]);
        } catch (CardException $e) {
            $token['error'] = $e->getError()->message;
        } catch (Exception $e) {
            $token['error'] = $e->getMessage();
        }
        return $token;
    }

    private function createCharge($tokenId, $amount)
    {
        $charge = null;
        try {
            $charge = $this->stripe->charges->create([
                'amount' => $amount,
                'currency' => 'INR',
                'source' => $tokenId,
                'description' => 'Payment Received From SrtDash'
            ]);
        } catch (Exception $e) {
            $charge['error'] = $e->getMessage();
        }
        return $charge;
    }
}