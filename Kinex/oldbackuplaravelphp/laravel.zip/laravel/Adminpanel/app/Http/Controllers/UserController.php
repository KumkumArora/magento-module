<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\RegisterationFormRequest;
use App\Models\User;
use App\Http\Requests\LoginFormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
  public function registration(RegisterationFormRequest $request)
  {
    $addUser = new User();
    $addUser->fullname = $request['fullname'];
    $addUser->email = $request['email'];
    $addUser->password = Hash::make($request['password']);
    $addUser->type = $request['type'];
    $addUser->save();

    return redirect('/')->with('message', 'Your Account Registered Successfully');
  }

  public function login(LoginFormRequest  $request)
  {
    $credentials = [
      'email' => $request['email'],
      'password' => $request['password'],
    ];
    if (Auth::attempt($credentials)) {
      if (Auth::check()) {
        if (Auth::user()->type == 1) {
          $request->session()->regenerate();
          return redirect()->intended('/admin/dashboard');
        } elseif (Auth::user()->type == 2) {
          $request->session()->regenerate();
          return redirect()->intended('products');
        } else {
          abort(401);
        }
      }
    }
    return back()->withErrors([
      'email' => 'The provided credentials do not match our records.',
    ])->onlyInput('email');
  }

  public function logout()
  {
    Auth::logout();
    return redirect('/');
  }

  public function showCustomers()
  {
    $getCustomers = User::get();
    return view('admin.customers.listing', compact('getCustomers'));
  }
}
