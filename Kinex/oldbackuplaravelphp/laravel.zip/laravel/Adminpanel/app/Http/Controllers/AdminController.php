<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProductAttributeFormRequest;
use App\Http\Requests\ProductCategoryFormRequest;
use App\Models\ProductCategory;
use App\Models\ProImages;
use Attribute;
use App\Models\Product;
use App\Models\Attributes;
use Illuminate\Http\Request;
use App\Models\AttributeType;
use App\Models\AttributeValues;
use App\Http\Requests\AttributesRequest;
use App\Http\Requests\ProductFormRequest;
use App\Http\Requests\AttributeTypeRequest;
use App\Http\Requests\AttributeValuesRequest;
use App\Http\Requests\AsignAttributeFormRequest;
use App\Models\AttributeFamily;
use App\Models\User;

class AdminController extends Controller
{
    /**
     * Show the form for creating attribute type
     */
    public function showAttributeNameForm()
    {
        return view('admin.product.attributes.attributetype_form');
    }

    public function showAttributevalueForm()
    {
        $getAttributes = Attributes::all();
        return view('admin.product.attributes.attributevalue_form', compact('getAttributes'));
    }

    public function showAttributeForm()
    {
        return view('admin.product.attributes.attributes_form');
    }

    public function showDashborad()
    {
        return view('admin.dashboard');
    }

    /**
     * Store Attribute type into the database
     *
     * Summary of addAttributeType
     * @param \App\Http\Requests\AttributeTypeRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addAttributeType(AttributeTypeRequest $request)
    {
        $add = new AttributeType();
        $add->name = $request['attribute_type'];
        $add->save();

        return redirect()->back()->with('message', 'Type of attribute successfully added!');
    }

    /**
     * Store Attributes name into the database
     *
     * Summary of addAttributeNames
     * @param \App\Http\Requests\AttributesRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addAttributeNames(AttributesRequest $request)
    {
        $add = new Attributes();
        $add->attribute_name = $request['attribute_name'];
        $add->type = $request['attribute_type'];
        $add->save();

        return redirect()->back()->with('message', 'Attribute name successfully added!');
    }

    /**
     * Store Attributes values into the database
     *
     * Summary of addAttributeValues
     * @param \App\Http\Requests\AttributeValuesRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addAttributeValues(AttributeValuesRequest $request)
    {
        $add = new AttributeValues();
        $add->attributes_id = $request['attribute_id'];
        $add->value = $request['attribute_value'];
        $add->save();
        return redirect()->back()->with('message', 'Attribute value successfully added!');
    }

    public function attributeTypeListing()
    {
        $attributeTypes = AttributeType::get();
        return view('admin.product.attributes.attribute_type_listing', compact('attributeTypes'));
    }

    public function asignAttributes($id)
    {
        $getAttributeType = AttributeType::with('attributes')->find($id);
        $attributeIds = $getAttributeType->attributes->pluck('id')->toArray();
        $getAttributes = Attributes::get();
        return view('admin.product.attributes.asign_attributes_form', compact('getAttributeType', 'getAttributes', 'id', 'attributeIds'));
    }

    public function addAsignedAttributes(AsignAttributeFormRequest $request)
    {
        $types = AttributeType::find($request['attribute_type_id']);
        $types->attributes()->detach();
        $types->attributes()->attach($request['attributes']);
        return redirect()->back()->with('message', 'Attribute Asigned Successfully');
    }

    public function showProductForm()
    {
        $attributeTypes = AttributeType::get();
        $getCategories = ProductCategory::get();
        return view('admin.product.products.product_form', compact('attributeTypes', 'getCategories'));
    }

    public function addProduct(ProductFormRequest $request)
    {
        if ($request->hasFile('featured_image')) {
            $image = $request->file('featured_image');
            $new_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->storeAs('public', $new_name);
            $product = new Product();
            $product->product_name = $request['product_name'];
            $product->sku = $request['sku'];
            $product->product_category = $request['category'];
            $product->feature_image = $new_name;
            $product->stock = $request['stock'];
            $product->price = $request['price'];
            $product->description = $request['description'];
            $product->attribute = $request['attribute'];
            $product->save();
        }
        foreach ($request->file('file') as $imagefile) {
            $newImage = rand() . '.' . $imagefile->getClientOriginalExtension();
            $imagefile->storeAs('public', $newImage);
            $productImages = new ProImages();
            $productImages->product_id = $product->id;
            $productImages->product_images = $newImage;
            $productImages->save();
        }
        return Redirect(route('product.attribute.form', array('id' => $product->id)))->with('message', ' Product Added Successfully now add more deatils of product');
    }

    public function showProductAttributeForm($id)
    {
        $getProduct = Product::find($id);
        $getAttributeType = AttributeType::with('attributes.attribute_value')->find($getProduct->attribute);
        $attributeNames = $getAttributeType->attributes;
        return view('admin.product.products.product_attributes_form', compact('attributeNames', 'id'));
    }

    public function addProductAttributes(ProductAttributeFormRequest $request)
    {
        $productAttribute = Product::find($request['product_id']);
        $productAttribute->attributeValues()->attach($request['attribute_values_id']);
        return Redirect(route('admin.product.show'))->with('message', 'Your Product Added Successfully');
    }
    public function addCategory(ProductCategoryFormRequest $request)
    {
        $add = new ProductCategory();
        $add->category = $request['category'];
        $add->save();
        return redirect()->back()->with('message', ' Category successfully added!');
    }

    public function showCategories()
    {
        $categories = ProductCategory::get();
        return view('admin/product/categories/listing_category', compact('categories'));
    }

    public function showListing()
    {
        $products = Product::get();
        return view('/admin/product/products/product_listing', compact('products'));
    }

    public function viewProductImages($id)
    {
        $getImages = ProImages::where('product_id', $id)->get();
        return $getImages;
    }
    public function deleteImage($id)
    {
        $product = ProImages::find($id);
        unlink("storage/" . $product->product_images);
        $product->destroy($id);
        return response()->json([
            'success' => 'Image deleted successfully!'
        ]);
    }

    public function editSingleImage(Request $request)
    {
        $imageId = $request->image_id;
        if ($request->hasFile('file')) {
            $getOldImage = ProImages::find($imageId);
            unlink("storage/" . $getOldImage->product_images);
            $getNewImage = $request->file('file');
            $newName = rand() . '.' . $getNewImage->getClientOriginalExtension();
            $getNewImage->storeAs('public', $newName);
            $updateImage = ProImages::find($imageId);
            $updateImage->product_images = $newName;
            $updateImage->update();
        }
        return response()->json([
            'success' => 'Image updated successfully!'
        ]);
    }

    public function deleteProduct($id)
    {
        $product = Product::with('productImages')->with('productAttributes')->find($id);
        unlink("storage/" . $product->feature_image);
        foreach ($product->productImages as $value) {
            unlink("storage/" . $value->product_images);
        }
        $product->delete();
        return redirect()->back()->with('message', ' Product Deleted successfully!!');
    }

    public function editProduct($id)
    {
        $product = Product::with('productImages')->with('productAttributes')->find($id);
        $attributeValueId = $product->productAttributes->pluck('attribute_values_id')->toArray();
        $attributeTypes = AttributeType::get();
        $getCategories = ProductCategory::get();
        $getAttributeType = AttributeType::with('attributes.attribute_value')->find($product->attribute);
        $attributeNames = $getAttributeType->attributes;
        return view('/admin/product/products/product_edit_form', compact('product', 'attributeTypes', 'getCategories', 'attributeNames', 'attributeValueId'));
    }

    public function updateProduct(Request $request)
    {
        if ($request->hasFile('new_featured_image')) {
            $getProduct = Product::find($request->product_id);
            unlink("storage/" . $getProduct->feature_image);
            $image = $request->file('new_featured_image');
            $newImage = rand() . '.' . $image->getClientOriginalExtension();
            $image->storeAs('public', $newImage);
        } else {
            $newImage = $request['old_featured_image'];
        }
        $updateProduct = Product::find($request->product_id);
        $updateProduct->product_name = $request->product_name;
        $updateProduct->product_category = $request->category;
        $updateProduct->feature_image = $newImage;
        $updateProduct->stock = $request->stock;
        $updateProduct->price = $request->price;
        $updateProduct->description = $request->description;
        $updateProduct->update();

        if ($request->hasFile('new_file')) {
            $productImages = ProImages::where('product_id', $request->product_id)->get();
            foreach ($productImages as $oldImages) {
                unlink("storage/" . $oldImages->product_images);
            }
            $productImages->each->delete();

            foreach ($request->file('new_file') as $imagefile) {
                $newImage = rand() . '.' . $imagefile->getClientOriginalExtension();
                $imagefile->storeAs('public', $newImage);
                $productImages = new ProImages();
                $productImages->product_id = $request->product_id;
                $productImages->product_images = $newImage;
                $productImages->save();
            }
        }
        $productAttribute = Product::find($request['product_id']);
        $productAttribute->attributeValues()->detach();
        $productAttribute->attributeValues()->attach($request['attribute_values_id']);
        return Redirect(route('admin.product.show'))->with('message', 'Product Updated Successfully');
    }

}