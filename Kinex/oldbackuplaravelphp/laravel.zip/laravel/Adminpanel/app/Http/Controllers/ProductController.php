<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderProduct;

class ProductController extends Controller
{
    public function showAllProducts()
    {
        $allProducts = Product::get();
        return view('/all_products', compact('allProducts'));
    }

    public function showMoreDeatils($id)
    {
        $product = Product::with('productImages','productAttributes.getValues')->where('id', $id)->get();
        foreach($product as $productDettails){
          foreach($productDettails->productAttributes as $key => $attributes){ 
              $productInfo[$attributes->getValues->attributeNames['attribute_name']][$key] = $attributes->getValues['value'];
          }
        }
        return view('/detailed_product', compact('product','productInfo'));
    }
    
    public function addToCart(Request $request)
    {    
        $lessStock = Product::find($request['product_id']);
        $stock = $lessStock->stock - $request['qty'];
        $lessStock->update(['stock'=> $stock]);
        $checkProduct= Cart::where('product_id',$request['product_id'])->where('user_id', Auth::id())->first();
        if(is_null($checkProduct))
        {
           $addToCart = new Cart();
           $addToCart->product_id = $request['product_id'];
           $addToCart->user_id = Auth::id();
           $addToCart->qty = $request['qty'];
           $addToCart->save();
           return redirect(route('cart.list'))->with('message','Product Added to the Cart Successfully');
        }else{
            $updateQty= $checkProduct->qty + $request['qty'];
            $checkProduct->update(['qty'=> $updateQty]);
            return redirect(route('cart.list'))->with('message','You have this Item in your bag and we have increased the quantity');
        }
    }

    public function cartListing()
    {   
        $getCartItems= Cart::with('products','user')->where('user_id', Auth::id())->get();
        $total = 0;
        foreach($getCartItems as $value){   
          $total  +=  $value->qty* $value->products->price;
        }
        return view('addtocart', compact('getCartItems','total'));
    }

    public function deleteCartItem($id)
    {
        $getCartDetails = Cart::find($id);
        $addStock = Product::find($getCartDetails['product_id']);
        $stock = $addStock->stock + $getCartDetails['qty'];
        $addStock->update(['stock'=> $stock]);
        $getCartDetails->delete();
        return redirect(route('cart.list'))->with('message','Product Removed From the cart successfully');
    }

    public function updateCartQty(Request $request)
    {
        $getCartproduct = Cart::find($request['cart_id']);
        $getProduct = Product::find($getCartproduct['product_id']);
        $updateStock = $getProduct->stock + $getCartproduct['qty'];
        $getProduct->update(['stock'=> $updateStock]);
        $getCartproduct->update(['qty'=> $request['qty']]);
        $addStock = $getProduct->stock - $request['qty'];
        $getProduct->update(['stock'=> $addStock]);
    }
    
    public function myOrderList()
    {
        $myOrders= Order::where('user_id', Auth::id())->get();
        return view('myorders', compact('myOrders'));
    }

    public function orderDetails($id)
    {
        $orders = OrderProduct::with('getCartValues.products')->where('order_id', $id)->get();
        $total = 0;
        foreach($orders as $order){   
          $total  += $order->getCartValues->products->price * $order->getCartValues->qty;
        }
       return view('orderdetails', compact('orders','total'));
    }

}