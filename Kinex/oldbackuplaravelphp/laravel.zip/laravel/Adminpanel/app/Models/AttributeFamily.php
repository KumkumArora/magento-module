<?php

namespace App\Models;

use App\Models\Attributes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AttributeFamily extends Model
{
    use HasFactory;


}