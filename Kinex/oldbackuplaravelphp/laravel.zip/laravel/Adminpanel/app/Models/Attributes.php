<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AttributeValues;

class Attributes extends Model
{
    use HasFactory;

    // public function attibuteTypes()
    // {
    //     return $this->belongsToMany(AttributeType::class, 'attribute_families');
    // }
    public function attribute_value()
    {
        return $this->hasMany(AttributeValues::class);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_attributes');
    }
}