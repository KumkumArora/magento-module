<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Attributes;

class AttributeValues extends Model
{
    use HasFactory;

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_attributes');
    }
    
    public function attributeNames()
    {
        return $this->belongsTo(Attributes::class, 'attributes_id');
    }
}