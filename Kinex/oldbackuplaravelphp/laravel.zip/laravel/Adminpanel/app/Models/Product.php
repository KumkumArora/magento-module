<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Attributes;
use App\Models\ProductAttributes;
use App\Models\ProImages;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Product extends Model
{
    use HasFactory;

    // protected $table = 'products';
    public $timestamps = false;

    protected $fillable=[
        'stock',
    ];
    
    public function attributeValues()
    {
        return $this->belongsToMany(AttributeValues::class, 'product_attributes');
    }
    
    public function productImages()
    {
      return $this->hasMany(ProImages::class,'product_id');
    } 
    
    public function productAttributes()
    {
         return $this->hasMany(ProductAttributes::class,'product_id');
    }

    public static function boot() {
        parent::boot();
        self::deleting(function($product) { // before delete() method call this
             $product->productImages()->each(function($productImages) {
                $productImages->delete(); // <-- direct deletion
             });
             $product->productAttributes()->each(function($productAttributes) {
                $productAttributes->delete(); // <-- raise another deleting event on Post to delete comments
             });
        });
    }
}