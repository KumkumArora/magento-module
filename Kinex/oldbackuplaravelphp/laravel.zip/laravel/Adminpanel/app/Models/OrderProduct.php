<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Cart;
use App\Models\Order;

class OrderProduct extends Model
{
    use HasFactory;

    public function getCartValues()
    {
        return $this->belongsTo(Cart::class, 'cart_id', 'id')->withTrashed();
          
    }
}