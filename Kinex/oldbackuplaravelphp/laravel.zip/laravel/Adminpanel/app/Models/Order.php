<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Cart;
use App\Models\OrderProduct;

class Order extends Model
{
    use HasFactory;

     public function orderedProducts()
    {
        return $this->belongsToMany(Cart::class, 'order_products');
    }

}