<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AttributeValues;

class ProductAttributes extends Model
{
    use HasFactory;

    protected $table = 'product_attributes';
    public $timestamps = false;

    public function getValues()
    { 
       return $this->belongsTo(AttributeValues::class, 'attribute_values_id')->with('attributeNames');
    }
}