@extends('layout.default')
@section('content')
    @include('layout.include.header');

    <div class="main-content-inner">
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
        <div class="row">
            <!-- basic form start -->
            <div class="col-12 p-5 ml-5">
                <div class="carousel">
                    <ul class="slides">
                        @foreach ($product as $value)
                            @foreach ($value->productImages as $key => $images)
                                <input type="radio" name="radio-buttons" id="img-{{ $key + 1 }}" checked />
                                <li class="slide-container">
                                    <div class="slide-image">
                                        <img src="/storage/{{ $images->product_images }}" width="250px" height="400px">
                                    </div>
                                </li>
                            @endforeach
                        @endforeach
                        <div class="carousel-dots">
                            @foreach ($product as $value)
                                @foreach ($value->productImages as $key => $images)
                                    <label for="img-{{ $key + 1 }}" class="carousel-dot"
                                        id="img-dot-{{ $key + 1 }}"></label>
                                @endforeach
                            @endforeach
                        </div>
                    </ul>
                </div><br>
                @foreach ($product as $value)
                    <h1 class="">{{ $value->product_name }}</h1>
                    <h5 class="card-text">{{ $value->description }}</h5>
                    <br>
                    <h2 class="font-weight-bold text-dark">Price : ₹{{ $value->price }}</h2>
                    <br>
                    <div class="container">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="p-3 border bg-light">
                                    <h4>Product Sku :- {{ $value->sku }}</h4>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-3 border bg-light">
                                    <h4>In Stock :- {{ $value->stock }}</h4>
                                </div>
                            </div>
                            @if ($productInfo)
                                @foreach ($productInfo as $key => $data)
                                    <div class="col-6">
                                        <div class="p-3 border bg-light">
                                            <h4>{{ $key }} : {{ implode(',', $data) }}</h4>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                    <form method="POST" action="{{ route('add.to.cart') }}">
                        @csrf
                        <label for="exampleInputCategory">Add Qty</label>
                        <br>
                        <input type="hidden" name="product_id" value="{{ $value->id }}">
                        <input type="text" name="qty" value="" required>
                        <br><br>
                        <button type="submit" class="btn btn-flat btn-primary btn-lg mb-3">
                            <h5>Add To Cart <i class="fa fa-shopping-cart"></i></h5>
                        </button>
                    </form>
                @endforeach
            </div>
        </div>
    </div>
@endsection
<!-- Modal -->
