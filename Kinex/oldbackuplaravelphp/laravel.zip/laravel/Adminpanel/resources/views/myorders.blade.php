@extends('layout.default')
@section('content')
    @include('layout.include.header');

    <div class="main-content-inner">
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
        <div class="container padding-bottom-3x mb-1">
            <h4 class="text-dark p-2 mb-2">Order History</h4>
            <!-- Shopping Cart-->
            <div class="table-responsive shopping-cart">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="text-center">S.no</th>
                            <th class="text-center">Order NO</th>
                            <th class="text-center">Transection ID</th>
                            <th class="text-center">Transection Amount</th>
                            <th class="text-center">Order Date</th>
                            <th class="text-center">Action</th>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($myOrders as $key => $orders)
                            <tr>
                                <td class="text-center text-lg text-medium">
                                    {{ $key + 1 }}</td>
                                <td class="text-center text-lg text-medium">
                                    {{ $orders->order_no }}</td>
                                <td class="text-center text-lg text-medium">
                                    {{ $orders->transection_id }}</td>

                                <td class="text-center text-lg text-medium">₹
                                    {{ $orders->transection_amount }}</td>
                                <td class="text-center text-lg text-medium">
                                    {{ $orders->created_at }}</td>
                                <td class="text-center"><a class="view-from-cart"
                                        href="{{ route('ordered.products.details', $orders->id) }}" data-toggle="tooltip"
                                        title="view"><i class="fa fa-eye"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="shopping-cart-footer">
                <div class="column">
                </div>
                <div class="column text-lg"> <span class="text-medium"></span>
                </div>
            </div>
            <div class="shopping-cart-footer">
                <div class="column"><a class="btn btn-outline-secondary" href="{{ route('show.products') }}"><i
                            class="icon-arrow-left"></i>&nbsp;Back to Shopping</a></div>
            </div>
        </div>
    </div>
    </div>
@endsection
