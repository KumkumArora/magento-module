@extends('layout.default')
@section('content')
    @include('layout.include.header');

    <div class="main-content-inner">
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
        <div class="container padding-bottom-3x mb-1">

            <!-- Shopping Cart-->
            <div class="table-responsive shopping-cart">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-center">Unit Price</th>
                            <th class="text-center">Subtotal</th>
                            <th class="text-center">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($getCartItems as $cartItems)
                            <tr>
                                <td>
                                    <div class="product-item">
                                        <a class="product-thumb"
                                            href="{{ route('view.details.product', $cartItems->products->id) }}"><img
                                                src="/storage/{{ $cartItems->products->feature_image }}" alt="Product"></a>
                                        <div class="product-info">
                                            <h4 class="product-title"><a
                                                    href="#">{{ $cartItems->products->product_name }}</a></h4>
                                            <span><em>SKU:</em>{{ $cartItems->products->sku }}</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <div class="count-input">
                                        <input type="text" class="form-control" id="qty"
                                            data-id="{{ $cartItems->id }}" value="{{ $cartItems->qty }}" name="qty">
                                    </div>
                                </td>
                                <td class="text-center text-lg text-medium">₹
                                    {{ $cartItems->products->price }}</td>
                                <td class="text-center text-lg text-medium">₹
                                    {{ $cartItems->products->price * $cartItems->qty }}</td>
                                <td class="text-center"><a class="remove-from-cart"
                                        href="{{ route('delete.cart.item', $cartItems->id) }}" data-toggle="tooltip"
                                        title="Remove" data-original-title="Remove item"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="shopping-cart-footer">
                <div class="column">
                    <form class="coupon-form" method="post">
                        <input class="form-control form-control-sm" type="text" placeholder="Coupon code" required="">
                        <button class="btn btn-outline-primary btn-sm" type="submit">Apply Coupon</button>
                    </form>
                </div>
                <div class="column text-lg">Subtotal: <span class="text-medium">₹ {{ $total }}</span>
                </div>
            </div>
            <div class="shopping-cart-footer">
                <div class="column"><a class="btn btn-outline-secondary" href="{{ route('show.products') }}"><i
                            class="icon-arrow-left"></i>&nbsp;Back to Shopping</a></div>
                <div class="column"><a class="btn btn-success" href="{{ url('checkout') }}">Checkout</a></div>
            </div>
        </div>
    </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('input').on('change', function(e) {
                var cart_id = $(this).data('id');
                var qty = $(this).val();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "{{ route('update.cart.qty') }}",
                    type: 'Post',
                    data: {
                        "cart_id": cart_id,
                        "qty": qty,
                    },
                    success: function(data) {

                    }
                });
            });
        });
    </script>
@endsection
