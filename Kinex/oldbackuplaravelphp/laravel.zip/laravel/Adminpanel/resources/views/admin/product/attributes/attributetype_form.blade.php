@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h3 class="header-title">Attributes Types</h3>
                            <a href="{{ route('attribute_types') }}" class="btn btn-sm btn-info">Back To listing</a>
                        </div>
                        <form method="post" action="{{ route('add.attribute.type') }}">
                            @csrf
                            <div class="form-group">
                                <label for="exampleInputCategory">Attribute type</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Attribute type (example - cloths,furniture)" name="attribute_type"
                                    value="{{ old('attribute_type') }}">
                                @if ($errors->has('attribute_type'))
                                    <div class="text-danger">{{ $errors->first('attribute_type') }}</div>
                                @endif
                            </div>

                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
