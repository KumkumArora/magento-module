@extends('admin.layout.default')
@section('content')
<div class="main-content-inner">
    <div class="row">
        <!-- basic form start -->
        <div class="col-11 p-5 ml-5">
            {{-- sucessfully messages --}}
            @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif
            <br>
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add Category</h4>
                    <form method="post" action="{{ route('add.category') }}">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputCategory">Category Name</label>
                            <input type="text" class="form-control" id="exampleInputCategory" placeholder="Enter Category Name" name="category" value="{{ old('category') }}">
                            @if ($errors->has('category'))
                            <div class="text-danger">{{ $errors->first('category') }}</div>
                            @endif
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
