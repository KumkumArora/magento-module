@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                {{-- sucessfully messages --}}
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Attributes </h4>
                        <form method="post" action="{{ route('add.attribute.names') }}">
                            @csrf
                            <div class="form-group">
                                <label for="exampleInputCategory">Attribute Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Attribute name (like color,size)" name="attribute_name"
                                    value="{{ old('attribute_name') }}">
                                @if ($errors->has('attribute_name'))
                                    <div class="text-danger">{{ $errors->first('attribute_name') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute_type">
                                    <option value="">Select....</option>
                                    <option value="Multiple" @if (old('attribute_type') == 'Multiple') selected @endif>Multiple
                                    </option>
                                    <option value="boolean" @if (old('attribute_type') == 'boolean') selected @endif>Boolean
                                    </option>
                                    <option value="Single" @if (old('attribute_type') == 'Single') selected @endif>Single</option>
                                </select>
                                @if ($errors->has('attribute_type'))
                                    <div class="text-danger">{{ $errors->first('attribute_type') }}</div>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
