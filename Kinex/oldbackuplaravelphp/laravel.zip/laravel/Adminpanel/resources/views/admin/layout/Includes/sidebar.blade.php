<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="{{ route('admin.dashboard') }}"><img src="{{ asset('assets/images/icon/logo.png') }}" alt="logo"
                    class="img2"></a>
        </div>
    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <li class="active">
                        <a href="{{ route('admin.dashboard') }}" aria-expanded="true"><i
                                class="ti-dashboard"></i><span>dashboard</span></a>
                    </li>
                    <li>
                        <a href="{{ route('show.products') }}" aria-expanded="true"><i
                                class="ti-list"></i><span>Products</span></a>
                    </li>
                    <li>
                        <a href="{{ route('admin.customers') }}" aria-expanded="true"><i
                                class="ti-user"></i><span>Customers</span></a>
                    </li>
                    <li>
                        <a href="" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Products
                                Attributes
                            </span></a>
                        <ul class="collapse">
                            <li class="active"><a href="{{ route('attribute_types') }}">Add Attribute type</a>
                            </li>
                            <li><a href="{{ route('attribute.name.form') }}">Add Attribute Names</a></li>
                            <li><a href="{{ route('attribute.values.form') }}">Add Attribute Value</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="{{ route('show.product.categories') }}" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Product Categories
                            </span></a>
                    </li>
                    <li>
                        <a href="{{ route('admin.product.products') }}" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Add Products </span></a>
                    </li>
                    <li>
                        <a href="{{ route('admin.product.show') }}" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Listing</span></a>
                    </li>

                </ul>
            </nav>
        </div>
    </div>
</div>
