@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- table primary start -->
            <div class="col-lg-12 p-5">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h3 class="header-title">Attributes Types</h3>
                            <a href="{{ route('attribute.type.form') }}" class="btn btn-sm btn-info">Add New</a>
                        </div>
                        <div class="single-table mt-4">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="text-uppercase bg-primary">
                                        <tr class="text-white">
                                            <th scope="col">SR.No</th>
                                            <th scope="col">Title</th>
                                            <th scope="col">action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($attributeTypes as $key => $type)
                                            <tr>
                                                <td>{{ $key + 1 }}</td>
                                                <td>{{ $type->name }}</td>
                                                <td>
                                                    <a href="{{ route('asign_attributes', ['id' => $type->id]) }}"
                                                        class="btn btn-sm btn-info">Assign Attributes</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- table primary end -->
        </div>
    </div>
@endsection
