@extends('admin.layout.default')
@section('content')
<div class="main-content-inner">
    <div class="row">
        <!-- basic form start -->
        <div class="col-11 p-5 ml-5">
            @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h3 class="header-title">Asign Attributes</h3>
                        <a href="{{ route('attribute_types') }}" class="btn btn-sm btn-info">Back</a>
                    </div>
                    <form method="post" action="{{ route('add.asigned.attributes', ['id' => $id]) }}">
                        @csrf
                        <input type="hidden" value="{{ $getAttributeType->id }}" name="attribute_type_id">
                        <div class="form-group">
                            <label for="exampleInputCategory">Attribute type</label>
                            <input type="text" class="form-control" id="exampleInputCategory" placeholder="Enter Attribute type (example - cloths,furniture)" name="attribute_type" value="{{ $getAttributeType->name }}" disabled>
                        </div>
                        <div class="form-group">
                            <label for="hobby">Attributes:</label>
                            <div class="row">
                                @foreach ($getAttributes as $attributes)
                                <div class="col-2 mt-5">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="{{ $attributes->id }}" name="attributes[]" @if (in_array($attributes->id, $attributeIds)) checked @endif>{{ $attributes->attribute_name }}
                                        </label>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            @if ($errors->has('attributes'))
                            <div class="text-danger">{{ $errors->first('attributes') }}</div>
                            @endif
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Asign</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
