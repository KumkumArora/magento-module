@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                {{-- sucessfully messages --}}
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Values Of Attributes</h4>
                        <form method="post" action="{{ route('add.attribute.values') }}">
                            @csrf
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute</label>
                                <select class="custom-select" name="attribute_id">
                                    <option value="">Choose attribute name</option>
                                    @if ($getAttributes)
                                        @foreach ($getAttributes as $values)
                                            <option value="{{ $values->id }}"
                                                @if (old('attribute_id') == $values->id) selected @endif>
                                                {{ $values->attribute_name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                                @if ($errors->has('attribute_id'))
                                    <div class="text-danger">{{ $errors->first('attribute_id') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Enter Values</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter values of attribute" name="attribute_value"
                                    value="{{ old('attribute_value') }}">
                                @if ($errors->has('attribute_value'))
                                    <div class="text-danger">{{ $errors->first('attribute_value') }}</div>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
