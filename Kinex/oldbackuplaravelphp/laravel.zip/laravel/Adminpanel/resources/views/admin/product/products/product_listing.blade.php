@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-lg-12 p-5">
                <div class="card">
                    @if (session()->has('message'))
                        <div class="alert alert-success">
                            {{ session()->get('message') }}
                        </div>
                    @endif
                    <br>
                    <div class="card-body">
                        <h3 class="header-title">Customers</h3>
                        <div class="single-table">
                            <div class="table-responsive">
                                <table class="table text-center">
                                    <thead class="text-uppercase bg-primary">
                                        <tr class="text-white">
                                            <th scope="col">S.NO</th>
                                            <th scope="col">Product Name</th>
                                            <th scope="col">SKU</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Product Image</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($products as $key => $value)
                                            <tr>
                                                <th scope="row">{{ $key + 1 }}</th>
                                                <td>{{ $value->product_name }}</td>
                                                <td>{{ $value->sku }}</td>
                                                <td>{{ Str::words($value->description, 5) }}</td>
                                                <td>₹{{ $value->price }}</td>
                                                <td><img src="/storage/{{ $value->feature_image }}" alt="Product Image"
                                                        width="50"></td>
                                                <td> <button id="view" type="button" class="btn btn-sm btn-info"
                                                        data-toggle="modal" data-target="#viewModal"
                                                        data-attr="{{ route('view.more.images', $value->id) }}"><i
                                                            class="ti-eye"></i>
                                                    </button>
                                                    <a href="{{ route('delete.product', $value->id) }}"><button
                                                            class="btn btn-sm btn-danger" data-toggle="tooltip"
                                                            title="Delete!"><i class="ti-trash"></i></button></a>
                                                    <a href="{{ route('edit.product', $value->id) }}"><button
                                                            class="btn btn-sm btn-primary" data-toggle="tooltip"
                                                            title="Edit!"><i class="ti-pencil"></i></button></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function() {

            $(document).on("click", "#view", function() {
                event.preventDefault();
                let href = $(this).attr('data-attr');
                $.ajax({
                    url: href,
                    success: function(row) {
                        var trHTML = '';
                        $.each(row, function(key, value) {
                            trHTML +=
                                '<tr><td><img src = "/storage/' + value
                                .product_images +
                                '" width="150px" height="100px"><form class="editImageForm' +
                                value.id +
                                '" id="editImageForm' +
                                value.id +
                                '" enctype="multipart/form-data"><input type="hidden" id="imageId" value="' +
                                value.id +
                                '" name="imageId"><br><input type="file" id="' +
                                value.id +
                                'file" required class="form-control" id="edit_image" name="image"> <input type="submit" class="btn btn-primary btn-sm mt-2" id="addEditImage" value="Update" data-id="' +
                                value.id +
                                '"></form></td><td><a id="deleteimage" data-id="' +
                                value.id +
                                '" data-toggle="tooltip" title="Delete!"><button type="button" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button></a></td><td><button type="button" id="editimage" data-id="' +
                                value.id +
                                '" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></button></td></tr>'
                        });
                        $('#table').html(trHTML);
                        $('form').hide();

                    },
                    error: function(data) {
                        console.log(data)
                    }
                });
            });
        })

        $(document).on("click", "#editimage", function() {
            var imageId = $(this).data('id');
            $(".editImageForm" + imageId).toggle();
        })


        $(document).on("click", "#deleteimage", function() {
            var el = this;
            var id = $(this).data("id");
            var token = $("meta[name='csrf-token']").attr("content");

            $.ajax({
                url: "/admin/product/products/delete/" + id,
                type: 'GET',
                data: {
                    "id": id,
                    "_token": token,
                },
                success: function(data) {
                    $('#message').html(data);
                    $(el).closest('tr').fadeOut(800, function() {
                        $(this).remove();
                    });
                    setTimeout(() => {
                        $('#msg').html('');
                    }, 2000);
                }
            });
        });

        $(document).on("click", "#close", function(e) {
            $('#table').empty();
        });

        $(document).on("click", "#addEditImage", function(e) {
            e.preventDefault();
            let imageId = $(this).attr('data-id');
            var btn = '#' + imageId + 'file';
            var data = new FormData();
            var files = $(btn)[0].files;
            data.append('file', files[0]);
            data.append('image_id', imageId);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "{{ route('edit.single.image') }}",
                method: "POST",
                enctype: 'multipart/form-data',
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                dataType: 'JSON',
                success: function(data) {
                    $('form').trigger('reset');
                    $(".editImageForm" + $("#imageId").val()).hide();
                    $("#msg").html(data);
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                },
                error: function(data) {
                    console.log(data)
                }
            });
        });
    </script>
@endsection
<!-- Modal -->
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="msg"></h3>
                <h4 class="modal-title">Images</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <h4 id="message" class="text-primary font-weight-bold"></h4>
            <div class="modal-body" id="showimages">
                <table id="table">
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" id="close">Close</button>
            </div>
        </div>
    </div>
</div>
