@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                {{-- sucessfully messages --}}
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <h3 class="header-title text-dark ">Edit Product</h3>
                        <form method="post" action="{{ route('update.product') }}" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $product->id }}">
                            <div class="form-group">
                                <label for="exampleInputCategory">Product Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Name" name="product_name"
                                    value="{{ $product->product_name }}">
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="exampleInputCategory">Product SKU Code</label>
                                        <input type="text" class="form-control" id="exampleInputCategory"
                                            placeholder="Enter Product SKU code" name="sku"
                                            value="{{ $product->sku }}"disabled>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label class="col-form-label">Select Category</label>
                                        <select class="custom-select" name="category">
                                            <option value="">Select</option>
                                            @foreach ($getCategories as $category)
                                                <option value="{{ $category->id }}"
                                                    {{ $category->id == $product->product_category ? 'selected' : '' }}>
                                                    {{ $category->category }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Feature Image</label>
                                <input type="file" class="form-control" id="image" placeholder="Upload Feature Image"
                                    name="new_featured_image">
                                <input type="hidden" name="old_featured_image" value="{{ $product->feature_image }}">
                                <img src="/storage/{{ $product->feature_image }}" width="75">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Images</label>
                                <input type="file" class="form-control" id="images"
                                    placeholder="Upload Multiple Images" name="new_file[]" multiple>
                                @foreach ($product->productImages as $images)
                                    <img src="/storage/{{ $images->product_images }}" width="75">
                                    <input type="hidden" name="old_images[]" value="{{ $images->product_images }}">
                                    <input type="hidden" name="imagesId[]" value="{{ $images->id }}">
                                @endforeach
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Stock</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Stock" name="stock" value="{{ $product->stock }}">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Price</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Price (Without GST)" name="price"
                                    value="{{ $product->price }}">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Description</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Description" name="description" value="{{ $product->description }}">
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute" disabled>
                                    <option value="">Select</option>
                                    @foreach ($attributeTypes as $types)
                                        <option value="{{ $types->id }}"
                                            {{ $types->id == $product->attribute ? 'selected' : '' }}>{{ $types->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            @foreach ($attributeNames as $attributes)
                                <input type="hidden" name="attribute_id[]" value="{{ $attributes['id'] }}">
                                @if ($attributes['type'] == 'Multiple')
                                    <div class="form-group">
                                        <label class="col-form-label">Select {{ $attributes['attribute_name'] }}</label>
                                        <select class="custom-select" name="attribute_values_id[]" multiple>
                                            <option value="">Select....</option>
                                            @foreach ($attributes->attribute_value as $values)
                                                <option value="{{ $values['id'] }}"
                                                    {{ in_array($values['id'], $attributeValueId) ? 'selected' : '' }}>
                                                    {{ $values->value }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif
                                @if ($attributes['type'] == 'boolean')
                                    <div class="form-group">
                                        <label class="col-form-label">{{ $attributes['attribute_name'] }}</label>
                                        <br>
                                        @foreach ($attributes->attribute_value as $values)
                                            @if ($attributes['id'] == $values['attributes_id'])
                                                <label class="switch">
                                                    <input type="checkbox" value="{{ $values['id'] }}"
                                                        name="attribute_values_id[]"
                                                        {{ in_array($values['id'], $attributeValueId) ? 'checked' : '' }}>
                                                    <span class="slider round"></span>
                                                </label>
                                            @endif
                                        @endforeach
                                    </div>
                                @endif
                                @if ($attributes['type'] == 'Single')
                                    <div class="form-group">
                                        <label class="col-form-label">Select {{ $attributes['attribute_name'] }}</label>
                                        <select class="custom-select" name="attribute_values_id[]">
                                            <option value="">Select....</option>
                                            @foreach ($attributes->attribute_value as $values)
                                                <option value="{{ $values['id'] }}"
                                                    {{ in_array($values['id'], $attributeValueId) ? 'selected' : '' }}>
                                                    {{ $values->value }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif
                            @endforeach
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
