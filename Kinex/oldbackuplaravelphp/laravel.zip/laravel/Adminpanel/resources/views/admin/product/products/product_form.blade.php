@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                {{-- sucessfully messages --}}
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Product</h4>
                        <form method="post" action="{{ route('add.product') }}" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label for="exampleInputCategory">Product Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Name" name="product_name" value="{{ old('product_name') }}">
                                @if ($errors->has('product_name'))
                                    <div class="text-danger">{{ $errors->first('product_name') }}</div>
                                @endif
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="exampleInputCategory">Product SKU Code</label>
                                        <input type="text" class="form-control" id="exampleInputCategory"
                                            placeholder="Enter Product SKU code" name="sku" value="{{ old('sku') }}">
                                        @if ($errors->has('sku'))
                                            <div class="text-danger">{{ $errors->first('sku') }}</div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label class="col-form-label">Select Category</label>
                                        <select class="custom-select" name="category">
                                            <option value="">Select</option>
                                            @foreach ($getCategories as $category)
                                                <option value="{{ $category->id }}"
                                                    @if (old('category') == $category->id) selected @endif>
                                                    {{ $category->category }}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('category'))
                                            <div class="text-danger">{{ $errors->first('category') }}</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Feature Image</label>
                                <input type="file" class="form-control" id="exampleInputCategory"
                                    placeholder="Upload Feature Image" name="featured_image"
                                    value="{{ old('featured_image') }}"accept="image/jpeg">
                                @if ($errors->has('featured_image'))
                                    <div class="text-danger">{{ $errors->first('featured_image') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Images</label>
                                <input type="file" class="form-control" id="exampleInputCategory"
                                    placeholder="Upload Multiple Images" name="file[]" multiple
                                    value="{{ old('file.*') }}" accept="image/jpeg">
                                @if ($errors->has('file.*'))
                                    <div class="text-danger">{{ $errors->first('file.*') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Stock</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Stock" name="stock" value="{{ old('stock') }}">
                                @if ($errors->has('stock'))
                                    <div class="text-danger">{{ $errors->first('stock') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Price</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Price (Without GST)" name="price"
                                    value="{{ old('price') }}">
                                @if ($errors->has('price'))
                                    <div class="text-danger">{{ $errors->first('price') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Description</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Description" name="description" value="{{ old('description') }}">
                                @if ($errors->has('description'))
                                    <div class="text-danger">{{ $errors->first('description') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute">
                                    <option value="">Select</option>
                                    @foreach ($attributeTypes as $types)
                                        <option value="{{ $types->id }}"
                                            @if (old('attribute') == $types->id) selected @endif>
                                            {{ $types->name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('attribute'))
                                    <div class="text-danger">{{ $errors->first('attribute') }}</div>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
