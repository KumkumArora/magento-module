@extends('admin.layout.default')
@section('content')
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add More Details</h4>
                        <form method="post" action="{{ route('add.product.attributes') }}">
                            @csrf
                            @foreach ($attributeNames as $attributes)
                                <input type="hidden" name="product_id" value="{{ $id }}">
                                <input type="hidden" name="attribute_id[]" value="{{ $attributes['id'] }}">
                                <div class="form-group">
                                    @if ($attributes['type'] == 'Multiple')
                                        <label class="col-form-label">Select {{ $attributes['attribute_name'] }}</label>
                                        <select class="custom-select" name="attribute_values_id[]" multiple>
                                            <option value="">Select....</option>
                                            @foreach ($attributes->attribute_value as $values)
                                                <option value="{{ $values['id'] }}"
                                                    @if (old('attribute_values_id') == $values['id']) selected @endif>{{ $values->value }}
                                                </option>
                                            @endforeach
                                        </select>
                                    @endif
                                    @if ($attributes['type'] == 'boolean')
                                        <div class="form-group">
                                            <label class="col-form-label">{{ $attributes['attribute_name'] }}</label>
                                            <br>
                                            @foreach ($attributes->attribute_value as $values)
                                                @if ($attributes['id'] == $values['attributes_id'])
                                                    <label class="switch">
                                                        <input type="checkbox" value="{{ $values['id'] }}"
                                                            name="attribute_values_id[]">
                                                        <span class="slider round"></span>
                                                    </label>
                                                @endif
                                            @endforeach
                                        </div>
                                    @endif

                                    @if ($attributes['type'] == 'Single')
                                        <label class="col-form-label">Select {{ $attributes['attribute_name'] }}</label>
                                        <select class="custom-select" name="attribute_values_id[]">
                                            <option value="">Select....</option>
                                            @foreach ($attributes->attribute_value as $values)
                                                <option value="{{ $values['id'] }}"
                                                    @if (old('attribute_values_id') == $values['id']) selected @endif>{{ $values->value }}
                                                </option>
                                            @endforeach
                                        </select>
                                    @endif
                                    @if ($errors->has('attribute_values_id'))
                                        <div class="text-danger">{{ $errors->first('attribute_values_id') }}</div>
                                    @endif
                                </div>
                            @endforeach

                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
