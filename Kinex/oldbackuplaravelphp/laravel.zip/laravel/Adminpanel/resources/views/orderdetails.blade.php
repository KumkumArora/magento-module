@extends('layout.default')
@section('content')
    @include('layout.include.header');

    <div class="main-content-inner">
        @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
        <div class="container padding-bottom-3x mb-1">

            <!-- Shopping Cart-->
            <div class="table-responsive shopping-cart">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-center">Unit Price</th>
                            <th class="text-center">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orders as $order)
                            <tr>
                                <td>
                                    <div class="product-item">
                                        <a class="product-thumb"
                                            href="{{ route('view.details.product', $order->getCartValues->products['id']) }}"><img
                                                src="/storage/{{ $order->getCartValues->products->feature_image }}"
                                                alt="Product"></a>
                                        <div class="product-info">
                                            <h4 class="product-title"><a
                                                    href="#">{{ $order->getCartValues->products->product_name }}</a>
                                            </h4>
                                            <span><em>SKU:</em>{{ $order->getCartValues->products->sku }}</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center text-lg text-medium">
                                    {{ $order->getCartValues->qty }} Pcs</td>
                                <td class="text-center text-lg text-medium">₹
                                    {{ $order->getCartValues->products->price }}</td>
                                <td class="text-center text-lg text-medium">₹
                                    {{ $order->getCartValues->products->price * $order->getCartValues->qty }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="shopping-cart-footer">
                <div class="column text-lg">Subtotal: {{ $total }}<span class="text-medium"></span>
                </div>
            </div>
            <div class="shopping-cart-footer">
                <div class="column"><a class="btn btn-outline-secondary" href="{{ route('my.order.list') }}"><i
                            class="icon-arrow-left"></i>&nbsp;Back</a></div>
            </div>
        </div>
    </div>
    </div>
@endsection
