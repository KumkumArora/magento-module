@extends('layout.default')
@section('content')
    @include('layout.include.header');

    <div class="main-content-inner">

        <!-- basic form start -->
        <div class="main-content-inner">
            @foreach (['danger', 'success'] as $status)
                @if (Session::has($status))
                    <p class="alert alert-{{ $status }}">{{ Session::get($status) }}</p>
                @endif
            @endforeach
            <div class="card-area">
                <div class="row">
                    @foreach ($allProducts as $products)
                        <div class="col-lg-3 col-md-4 mt-5 p-2">
                            <div class="card card-bordered">
                                <img class="card-img-top p-5" class="img1" src="/storage/{{ $products->feature_image }}"
                                    alt="image" width="100px" height="400px">
                                <div class="card-body">
                                    <h5 class="">{{ $products->product_name }}</h5>
                                    <p class="card-text">{{ Str::words($products->description, 8) }}</p>
                                    <h2 class="font-weight-bold text-dark">₹{{ $products->price }}</h2>
                                    <br>
                                    <a href="{{ route('view.details.product', $products->id) }}" class="btn btn-primary">Go
                                        More....</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection
<!-- Modal -->
