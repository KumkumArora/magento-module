<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <div class="row">
        <!-- basic form start -->
        <div class="col-11 p-5 ml-5">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h3 class="header-title">Asign Attributes</h3>
                        <a href="<?php echo e(route('attribute_types')); ?>" class="btn btn-sm btn-info">Back</a>
                    </div>
                    <form method="post" action="<?php echo e(route('add.asigned.attributes', ['id' => $id])); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($getAttributeType->id); ?>" name="attribute_type_id">
                        <div class="form-group">
                            <label for="exampleInputCategory">Attribute type</label>
                            <input type="text" class="form-control" id="exampleInputCategory" placeholder="Enter Attribute type (example - cloths,furniture)" name="attribute_type" value="<?php echo e($getAttributeType->name); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="hobby">Attributes:</label>
                            <div class="row">
                                <?php $__currentLoopData = $getAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-2 mt-5">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="<?php echo e($attributes->id); ?>" name="attributes[]" <?php if(in_array($attributes->id, $attributeIds)): ?> checked <?php endif; ?>><?php echo e($attributes->attribute_name); ?>

                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if($errors->has('attributes')): ?>
                            <div class="text-danger"><?php echo e($errors->first('attributes')); ?></div>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Asign</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/asign_attributes_form.blade.php ENDPATH**/ ?>