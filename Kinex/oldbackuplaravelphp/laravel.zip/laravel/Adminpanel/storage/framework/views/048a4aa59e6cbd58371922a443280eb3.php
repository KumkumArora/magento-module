<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <div class="row">
        <!-- basic form start -->
        <div class="col-11 p-5 ml-5">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add Attribute</h4>
                    <form>
                        <div class="form-group">
                            <label for="hobby">Select Colours</label>
                            <div class="row">
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="Playing"
                                                name="colour[]">Red
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="Art & Craft"
                                                name="colour[]">Green
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="black"
                                                name="colour[]">Black
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="white"
                                                name="colour[]">White
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="yellow"
                                                name="colour[]">Yellow
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="pink"
                                                name="colour[]">Pink
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="navy"
                                                name="colour[]">Navy
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="orange"
                                                name="colour[]">Orange
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="cream"
                                                name="colour[]">Cream
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="brown"
                                                name="colour[]">Brown
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="blue"
                                                name="colour[]">blue
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputCategory">Brand</label>
                            <input type="text" class="form-control" id="exampleInputCategory" placeholder="Enter Brand">
                        </div>
                        <div class="form-group">
                            <label for="hobby">Select Sizes</label>
                            <div class="row">
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="XS" name="size[]">XS
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="S" name="size[]">S
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="M" name="size[]">M
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="L" name="size[]">L
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="XL" name="size[]">Xl
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="XXL"
                                                name="size[]">XXl
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="3XL"
                                                name="size[]">3XL
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="4XL"
                                                name="size[]">4XL
                                        </label>
                                    </div>
                                </div>
                                <div class="col-1">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="5XL"
                                                name="size[]">5XL
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputCategory">Pattern</label>
                            <input type="text" class="form-control" id="exampleInputCategory"
                                placeholder="Enter What Type of Product (Cotton,Pc,lycra)">
                        </div>
                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/attribute.blade.php ENDPATH**/ ?>