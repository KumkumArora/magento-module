<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="main-content-inner">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="container padding-bottom-3x mb-1">

            <!-- Shopping Cart-->
            <div class="table-responsive shopping-cart">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-center">Unit Price</th>
                            <th class="text-center">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="product-item">
                                        <a class="product-thumb"
                                            href="<?php echo e(route('view.details.product', $order->getCartValues->products['id'])); ?>"><img
                                                src="/storage/<?php echo e($order->getCartValues->products->feature_image); ?>"
                                                alt="Product"></a>
                                        <div class="product-info">
                                            <h4 class="product-title"><a
                                                    href="#"><?php echo e($order->getCartValues->products->product_name); ?></a>
                                            </h4>
                                            <span><em>SKU:</em><?php echo e($order->getCartValues->products->sku); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center text-lg text-medium">
                                    <?php echo e($order->getCartValues->qty); ?> Pcs</td>
                                <td class="text-center text-lg text-medium">₹
                                    <?php echo e($order->getCartValues->products->price); ?></td>
                                <td class="text-center text-lg text-medium">₹
                                    <?php echo e($order->getCartValues->products->price * $order->getCartValues->qty); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="shopping-cart-footer">
                <div class="column text-lg">Subtotal: <?php echo e($total); ?><span class="text-medium"></span>
                </div>
            </div>
            <div class="shopping-cart-footer">
                <div class="column"><a class="btn btn-outline-secondary" href="<?php echo e(route('my.order.list')); ?>"><i
                            class="icon-arrow-left"></i>&nbsp;Back</a></div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/orderdetails.blade.php ENDPATH**/ ?>