<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Product</h4>
                        <form method="post" action="<?php echo e(route('add.product')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputCategory">Product Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Name" name="product_name" value="<?php echo e(old('product_name')); ?>">
                                <?php if($errors->has('product_name')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('product_name')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="exampleInputCategory">Product SKU Code</label>
                                        <input type="text" class="form-control" id="exampleInputCategory"
                                            placeholder="Enter Product SKU code" name="sku" value="<?php echo e(old('sku')); ?>">
                                        <?php if($errors->has('sku')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('sku')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label class="col-form-label">Select Category</label>
                                        <select class="custom-select" name="category">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $getCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                    <?php if(old('category') == $category->id): ?> selected <?php endif; ?>>
                                                    <?php echo e($category->category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('category')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('category')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Feature Image</label>
                                <input type="file" class="form-control" id="exampleInputCategory"
                                    placeholder="Upload Feature Image" name="featured_image"
                                    value="<?php echo e(old('featured_image')); ?>"accept="image/jpeg">
                                <?php if($errors->has('featured_image')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('featured_image')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Images</label>
                                <input type="file" class="form-control" id="exampleInputCategory"
                                    placeholder="Upload Multiple Images" name="file[]" multiple
                                    value="<?php echo e(old('file.*')); ?>" accept="image/jpeg">
                                <?php if($errors->has('file.*')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('file.*')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Stock</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Stock" name="stock" value="<?php echo e(old('stock')); ?>">
                                <?php if($errors->has('stock')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('stock')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Price</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Price (Without GST)" name="price"
                                    value="<?php echo e(old('price')); ?>">
                                <?php if($errors->has('price')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('price')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Description</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Description" name="description" value="<?php echo e(old('description')); ?>">
                                <?php if($errors->has('description')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('description')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $attributeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($types->id); ?>"
                                            <?php if(old('attribute') == $types->id): ?> selected <?php endif; ?>>
                                            <?php echo e($types->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('attribute')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute')); ?></div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/products/product_form.blade.php ENDPATH**/ ?>