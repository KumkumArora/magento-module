<?php $__env->startSection('content'); ?>
    <h1>Attribute Form</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/products/attributes/product_attribute_form.blade.php ENDPATH**/ ?>