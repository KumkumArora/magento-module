<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Values Of Attributes</h4>
                        <form method="post" action="<?php echo e(route('add.attribute.values')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute</label>
                                <select class="custom-select" name="attribute_id">
                                    <option value="">Choose attribute name</option>
                                    <?php if($getAttributes): ?>
                                        <?php $__currentLoopData = $getAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($values->id); ?>"
                                                <?php if(old('attribute_id') == $values->id): ?> selected <?php endif; ?>>
                                                <?php echo e($values->attribute_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('attribute_id')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute_id')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Enter Values</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter values of attribute" name="attribute_value"
                                    value="<?php echo e(old('attribute_value')); ?>">
                                <?php if($errors->has('attribute_value')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute_value')); ?></div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/attributevalue_form.blade.php ENDPATH**/ ?>