<footer>
    <div class="footer-area">
        <p>© Copyright 2023. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
    </div>
</footer>
<?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/layout/Includes/footer.blade.php ENDPATH**/ ?>