<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Attributes </h4>
                        <form method="post" action="<?php echo e(route('add.attribute.names')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputCategory">Attribute Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Attribute name (like color,size)" name="attribute_name"
                                    value="<?php echo e(old('attribute_name')); ?>">
                                <?php if($errors->has('attribute_name')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute_name')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute_type">
                                    <option value="">Select....</option>
                                    <option value="Multiple" <?php if(old('attribute_type') == 'Multiple'): ?> selected <?php endif; ?>>Multiple
                                    </option>
                                    <option value="boolean" <?php if(old('attribute_type') == 'boolean'): ?> selected <?php endif; ?>>Boolean
                                    </option>
                                    <option value="Single" <?php if(old('attribute_type') == 'Single'): ?> selected <?php endif; ?>>Single</option>
                                </select>
                                <?php if($errors->has('attribute_type')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute_type')); ?></div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/attributes_form.blade.php ENDPATH**/ ?>