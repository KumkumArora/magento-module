<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="main-content-inner">

        <!-- basic form start -->
        <div class="main-content-inner">
            <?php $__currentLoopData = ['danger', 'success']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Session::has($status)): ?>
                    <p class="alert alert-<?php echo e($status); ?>"><?php echo e(Session::get($status)); ?></p>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="card-area">
                <div class="row">
                    <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 mt-5 p-2">
                            <div class="card card-bordered">
                                <img class="card-img-top p-5" class="img1" src="/storage/<?php echo e($products->feature_image); ?>"
                                    alt="image" width="100px" height="400px">
                                <div class="card-body">
                                    <h5 class=""><?php echo e($products->product_name); ?></h5>
                                    <p class="card-text"><?php echo e(Str::words($products->description, 8)); ?></p>
                                    <h2 class="font-weight-bold text-dark">₹<?php echo e($products->price); ?></h2>
                                    <br>
                                    <a href="<?php echo e(route('view.details.product', $products->id)); ?>" class="btn btn-primary">Go
                                        More....</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- Modal -->

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views//all_products.blade.php ENDPATH**/ ?>