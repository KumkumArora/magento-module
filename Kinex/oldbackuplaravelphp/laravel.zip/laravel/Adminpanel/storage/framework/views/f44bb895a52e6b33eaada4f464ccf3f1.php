<div class='align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm text-center'>
    <a class="text-decoration-none" href="/">
        <h5 class='my-0 mr-md-auto font-weight-normal text-dark'>Add Payment</h5>
    </a>
</div>
<?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/partials/header.blade.php ENDPATH**/ ?>