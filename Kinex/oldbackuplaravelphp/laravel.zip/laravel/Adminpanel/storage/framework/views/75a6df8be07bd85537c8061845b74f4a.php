  <!-- sidebar menu area start -->
  <div class="sidebar-menu">
      <div class="sidebar-header">
          <div class="logo">
              <a href="<?php echo e(url('index')); ?>"><img src="assets/images/icon/logo.png" alt="logo"></a>
          </div>
      </div>
      <div class="main-menu">
          <div class="menu-inner">
              <nav>
                  <ul class="metismenu" id="menu">
                      <li class="active">
                          <a href="<?php echo e(url('index')); ?>" aria-expanded="true"><i
                                  class="ti-dashboard"></i><span>dashboard</span></a>
                      </li>
                      <li>
                          <a href="<?php echo e(url('show_users')); ?>" aria-expanded="true"><i
                                  class="ti-user"></i><span>Admin/Users
                              </span></a>
                      </li>
                      <li>
                          <a href="<?php echo e(url('product_form')); ?>" aria-expanded="true"><i class="ti-plus"></i><span>Add
                                  Product</span></a>
                      </li>
                      <li>
                          <a href="<?php echo e(url('product_list')); ?>" aria-expanded="true"><i class="ti-list"></i><span>Product
                                  Listing</span></a>
                      </li>
                      <li>
                          <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-table"></i>
                              <span>Product Categories</span></a>
                          <ul class="collapse">
                              <li><a href="table-basic.html">Appo</a></li>
                              <li><a href="table-layout.html">Vivo</a></li>
                              <li><a href="datatable.html">One plus</a></li>
                              <li><a href="datatable.html">Samsung</a></li>
                              <li><a href="datatable.html">apple</a></li>
                          </ul>
                      </li>
                      <li><a href="maps.html"><i class="fa fa-cart-shopping"></i><span>Go To
                                  Cart</span></a></li>

                      <li>
                          <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-cart-shopping"></i>
                              <span>Error</span></a>
                          <ul class="collapse">
                              <li><a href="404.html">Error 404</a></li>
                              <li><a href="403.html">Error 403</a></li>
                              <li><a href="500.html">Error 500</a></li>
                          </ul>
                      </li>
                      <li>
                          <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-align-left"></i> <span>Multi
                                  level menu</span></a>
                          <ul class="collapse">
                              <li><a href="#">Item level (1)</a></li>
                              <li><a href="#">Item level (1)</a></li>
                              <li><a href="#" aria-expanded="true">Item level (1)</a>
                                  <ul class="collapse">
                                      <li><a href="#">Item level (2)</a></li>
                                      <li><a href="#">Item level (2)</a></li>
                                      <li><a href="#">Item level (2)</a></li>
                                  </ul>
                              </li>
                              <li><a href="#">Item level (1)</a></li>
                          </ul>
                      </li>
                  </ul>
              </nav>
          </div>
      </div>
  </div>
  <!-- sidebar menu area end -->
  <style>
      /*-------------------- 2.1 Sidebar Menu -------------------*/

      .sidebar-menu {
          position: fixed;
          left: 0;
          top: 0;
          z-index: 99;
          height: 100vh;
          width: 280px;
          overflow: hidden;
          background: #303641;
          box-shadow: 2px 0 32px rgba(0, 0, 0, 0.05);
          -webkit-transition: all 0.3s ease 0s;
          transition: all 0.3s ease 0s;
      }

      .sbar_collapsed .sidebar-menu {
          left: -280px;
      }

      .main-menu {
          height: calc(100% - 100px);
          overflow: hidden;
          padding: 20px 10px 0 0;
          -webkit-transition: all 0.3s ease 0s;
          transition: all 0.3s ease 0s;
      }

      .menu-inner {
          overflow-y: scroll;
          height: 100%;
      }

      .slimScrollBar {
          background: #fff !important;
          opacity: 0.1 !important;
      }

      .sidebar-header {
          padding: 19px 32px 20px;
          background: #303641;
          border-bottom: 1px solid #343e50;
      }

      .sidebar-menu .logo {
          text-align: center;
      }

      .logo a {
          display: inline-block;
          max-width: 120px;
      }

      .metismenu>li>a {
          padding-left: 32px !important;
      }

      .metismenu li a {
          position: relative;
          display: block;
          color: #8d97ad;
          font-size: 15px;
          text-transform: capitalize;
          padding: 15px 15px;
          letter-spacing: 0;
          font-weight: 400;
      }

      .metismenu li a i {
          color: #6a56a5;
          -webkit-transition: all 0.3s ease 0s;
          transition: all 0.3s ease 0s;
      }

      .metismenu li a:after {
          position: absolute;
          content: '\f107';
          font-family: fontawesome;
          right: 15px;
          top: 12px;
          color: #8d97ad;
          font-size: 20px;
      }

      .metismenu li.active>a:after {
          content: '\f106';
      }

      .metismenu li a:only-child:after {
          content: '';
      }

      .metismenu li a span {
          margin-left: 10px;
      }

      .metismenu li.active>a,
      .metismenu li:hover>a {
          color: #fff;
      }

      .metismenu li li a {
          padding: 8px 20px;
      }

      .metismenu li ul {
          padding-left: 37px;
      }

      .metismenu>li:hover>a,
      .metismenu>li.active>a {
          color: #fff;
          background: #343942;
      }

      .metismenu li:hover>a,
      .metismenu li.active>a {
          color: #fff;
      }

      .metismenu li:hover>a i,
      .metismenu li.active>a i {
          color: #fff;
      }

      .metismenu li li a:after {
          top: 6px;
      }

      /*-------------------- END Sidebar Menu -------------------*/
  </style>
<?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/common/sidebar_menu.blade.php ENDPATH**/ ?>