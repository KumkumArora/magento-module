<?php $__env->startSection('title', 'Payment Form'); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="row">
            <aside class="col-sm-6 offset-3">
                <article class="card">
                    <div class="card-body p-5">
                        <ul class="nav bg-light nav-pills rounded nav-fill mb-3" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#nav-tab-card">
                                    <i class="fa fa-credit-card"></i> Credit Card</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="nav-tab-card">
                                <?php $__currentLoopData = ['danger', 'success']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Session::has($status)): ?>
                                        <p class="alert alert-<?php echo e($status); ?>"><?php echo e(Session::get($status)); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <form role="form" method="POST" id="paymentForm" action="<?php echo e(url('/payment')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="username">Full name (on the card)</label>
                                        <input type="text" class="form-control" name="fullName" placeholder="Full Name">
                                    </div>
                                    <div class="form-group">
                                        <label for="cardNumber">Card number</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="cardNumber"
                                                placeholder="Card Number">
                                            <div class="input-group-append">
                                                <span class="input-group-text text-muted">
                                                    <i class="fab fa-cc-visa fa-lg pr-1"></i>
                                                    <i class="fab fa-cc-amex fa-lg pr-1"></i>
                                                    <i class="fab fa-cc-mastercard fa-lg"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="username">Total Amount</label>
                                        <input type="text" class="form-control" name="amount"
                                            value="<?php echo e($total); ?>" readonly="true">
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <label><span class="hidden-xs">Expiration</span> </label>
                                                <div class="input-group">
                                                    <select class="form-control" name="month">
                                                        <option value="">MM</option>
                                                        <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <select class="form-control" name="year">
                                                        <option value="">YYYY</option>
                                                        <?php $__currentLoopData = range(date('Y'), date('Y') + 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label data-toggle="tooltip" title=""
                                                    data-original-title="3 digits code on back side of the card">CVV <i
                                                        class="fa fa-question-circle"></i></label>
                                                <input type="number" class="form-control" placeholder="CVV" name="cvv">
                                            </div>
                                        </div>
                                    </div>
                                    <button class="subscribe btn btn-primary btn-block" type="submit"> Confirm </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </article>
            </aside>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>
    <script>
        $("#paymentForm").validate({
            errorPlacement: function() {
                return false
            },
            rules: {
                fullName: {
                    required: true,
                    maxlength: 50
                },
                cardNumber: {
                    required: true,
                    creditcard: true
                },
                month: "required",
                year: "required",
                cvv: {
                    required: true,
                    minlength: 3,
                    maxlength: 3
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/payment.blade.php ENDPATH**/ ?>