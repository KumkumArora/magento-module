<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">

        <!-- basic form start -->
        <div class="main-content-inner">
            <div class="card-area">
                <div class="row">
                    <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mt-5">
                            <div class="card card-bordered">
                                <img class="card-img-top p-5" class="img1" src="/storage/<?php echo e($products->feature_image); ?>"
                                    alt="image" width="100px" height="400px">
                                <div class="card-body">
                                    <h4 class=""><?php echo e($products->product_name); ?></h4>
                                    <p class="card-text"><?php echo e($products->description); ?></p>
                                    <h2 class="font-weight-bold text-dark">₹<?php echo e($products->price); ?></h2>
                                    <br>
                                    <a href="<?php echo e(route('view.details.product', $products->id)); ?>" class="btn btn-primary">Go
                                        More....</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- Modal -->

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views//admin/product/products/all_products.blade.php ENDPATH**/ ?>