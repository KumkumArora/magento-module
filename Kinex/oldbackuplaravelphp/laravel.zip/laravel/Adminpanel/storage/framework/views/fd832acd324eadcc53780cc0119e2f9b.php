<?php $__env->startSection('content'); ?>
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <?php echo $__env->make('common.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- header area end -->

            <div class="main-content-inner">
                <div class="row">
                    <!-- basic form start -->
                    <div class="col-10 m-5 p-5 l-5 ">
                        <div class="card ml-5">
                            <div class="card-body">
                                <h4 class="header-title">Product form</h4>
                                <form>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Mobile</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            placeholder="Enter Mobile">
                                        <small id="emailHelp" class="form-text text-muted"></small>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Brand</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1"
                                            placeholder="Enter Brandname">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Model</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1"
                                            placeholder="Enter Model details">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Colour</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1"
                                            placeholder="Enter Colours">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Images</label>
                                        <input type="file" class="form-control" id="exampleInputPassword1"
                                            placeholder="upload images" multiple name="images[]">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Features</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1"
                                            placeholder="Enter Features">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Price</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1"
                                            placeholder="Price">
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- basic form end -->
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    <?php echo $__env->make('common.offset', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
    </body>

    </html>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/product_form.blade.php ENDPATH**/ ?>