<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h3 class="header-title text-dark ">Edit Product</h3>
                        <form method="post" action="<?php echo e(route('update.product')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <div class="form-group">
                                <label for="exampleInputCategory">Product Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Name" name="product_name"
                                    value="<?php echo e($product->product_name); ?>">
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="exampleInputCategory">Product SKU Code</label>
                                        <input type="text" class="form-control" id="exampleInputCategory"
                                            placeholder="Enter Product SKU code" name="sku"
                                            value="<?php echo e($product->sku); ?>"disabled>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label class="col-form-label">Select Category</label>
                                        <select class="custom-select" name="category">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $getCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                    <?php echo e($category->id == $product->product_category ? 'selected' : ''); ?>>
                                                    <?php echo e($category->category); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Feature Image</label>
                                <input type="file" class="form-control" id="image" placeholder="Upload Feature Image"
                                    name="new_featured_image">
                                <input type="hidden" name="old_featured_image" value="<?php echo e($product->feature_image); ?>">
                                <img src="/storage/<?php echo e($product->feature_image); ?>" width="75">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Images</label>
                                <input type="file" class="form-control" id="images"
                                    placeholder="Upload Multiple Images" name="new_file[]" multiple>
                                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="/storage/<?php echo e($images->product_images); ?>" width="75">
                                    <input type="hidden" name="old_images[]" value="<?php echo e($images->product_images); ?>">
                                    <input type="hidden" name="imagesId[]" value="<?php echo e($images->id); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Stock</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Stock" name="stock" value="<?php echo e($product->stock); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Price</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Product Price (Without GST)" name="price"
                                    value="<?php echo e($product->price); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputCategory">Description</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Description" name="description" value="<?php echo e($product->description); ?>">
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">Select Attribute Type</label>
                                <select class="custom-select" name="attribute" disabled>
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $attributeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($types->id); ?>"
                                            <?php echo e($types->id == $product->attribute ? 'selected' : ''); ?>><?php echo e($types->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__currentLoopData = $attributeNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="attribute_id[]" value="<?php echo e($attributes['id']); ?>">
                                <?php if($attributes['type'] == 'Multiple'): ?>
                                    <div class="form-group">
                                        <label class="col-form-label">Select <?php echo e($attributes['attribute_name']); ?></label>
                                        <select class="custom-select" name="attribute_values_id[]" multiple>
                                            <option value="">Select....</option>
                                            <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($values['id']); ?>"
                                                    <?php echo e(in_array($values['id'], $attributeValueId) ? 'selected' : ''); ?>>
                                                    <?php echo e($values->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                                <?php if($attributes['type'] == 'boolean'): ?>
                                    <div class="form-group">
                                        <label class="col-form-label"><?php echo e($attributes['attribute_name']); ?></label>
                                        <br>
                                        <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($attributes['id'] == $values['attributes_id']): ?>
                                                <label class="switch">
                                                    <input type="checkbox" value="<?php echo e($values['id']); ?>"
                                                        name="attribute_values_id[]"
                                                        <?php echo e(in_array($values['id'], $attributeValueId) ? 'checked' : ''); ?>>
                                                    <span class="slider round"></span>
                                                </label>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($attributes['type'] == 'Single'): ?>
                                    <div class="form-group">
                                        <label class="col-form-label">Select <?php echo e($attributes['attribute_name']); ?></label>
                                        <select class="custom-select" name="attribute_values_id[]">
                                            <option value="">Select....</option>
                                            <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($values['id']); ?>"
                                                    <?php echo e(in_array($values['id'], $attributeValueId) ? 'selected' : ''); ?>>
                                                    <?php echo e($values->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views//admin/product/products/product_edit_form.blade.php ENDPATH**/ ?>