   <div class="main-content">
       <!-- header area start -->
       <div class="header-area">
           <div class="row align-items-center">
               <!-- nav and search button -->
               <div class="col-md-6 col-sm-8 clearfix">
                   <button type="button" class="close" data-dismiss="modal">&times;</button>
                   <div class="search-box pull-left">
                       <form action="#">
                           <input type="text" name="search" placeholder="Search..." required>
                           <i class="ti-search"></i>
                       </form>
                   </div>
               </div>
               <!-- profile info & task notification -->
               <div class="col-md-6 col-sm-4 clearfix">
                   <ul class="notification-area pull-right">
                       <li id="full-view"><i class="ti-fullscreen"></i></li>
                       <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
                       <li class="dropdown">
                           <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
                               <span>2</span>
                           </i>
                       </li>

                       <li class="settings-btn">
                           <i class="ti-settings"></i>
                       </li>
                   </ul>
               </div>
           </div>
       </div>
       <!-- header area end -->
       <!-- page title area start -->
       <div class="page-title-area">
           <div class="row align-items-center">
               <div class="col-sm-6">
                   <div class="breadcrumbs-area clearfix">
                       <h4 class="page-title pull-left">SrtDash</h4>
                       <ul class="breadcrumbs pull-left">
                           <li><a href="<?php echo e(url('products')); ?>">Home</a></li>
                           <li><a href="<?php echo e(route('cart.list')); ?>">My Cart</a></li>
                           <li><a href="<?php echo e(route('my.order.list')); ?>">My Orders</a></li>
                       </ul>
                   </div>
               </div>
               <div class="col-sm-6 clearfix">
                   <?php if(Auth::user()): ?>
                       <a href="<?php echo e(url('logout')); ?>">
                           <div class="user-profile pull-right">
                               <img class="avatar user-thumb" src="<?php echo e(asset('assets/images/author/avatar.png')); ?>"
                                   alt="avatar">
                               <h4 class="user-name dropdown-toggle" data-toggle="dropdown">
                                   <?php echo e(Auth::user()->fullname); ?><i class="fa fa-power-off"></i> </h4>
                           </div>
                       </a>
                   <?php else: ?>
                       <a href="<?php echo e(url('/')); ?>">
                           <div class="user-profile pull-right">
                               <img class="avatar user-thumb" src="<?php echo e(asset('assets/images/author/avatar.png')); ?>"
                                   alt="avatar">
                               <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Login</h4>
                           </div>
                       </a>
                   <?php endif; ?>
               </div>
           </div>
       </div>
<?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/layout/include/header.blade.php ENDPATH**/ ?>