<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h3 class="header-title">Attributes Types</h3>
                            <a href="<?php echo e(route('attribute_types')); ?>" class="btn btn-sm btn-info">Back To listing</a>
                        </div>
                        <form method="post" action="<?php echo e(route('add.attribute.type')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputCategory">Attribute type</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Attribute type (example - cloths,furniture)" name="attribute_type"
                                    value="<?php echo e(old('attribute_type')); ?>">
                                <?php if($errors->has('attribute_type')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('attribute_type')); ?></div>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/attributetype_form.blade.php ENDPATH**/ ?>