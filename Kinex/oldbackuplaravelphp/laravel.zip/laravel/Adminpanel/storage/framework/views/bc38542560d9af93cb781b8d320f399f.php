<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="main-content-inner">
            <div class="card-area">

                <div class="carousel">
                    <ul class="slides">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $value->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="radio" name="radio-buttons" id="img-<?php echo e($key + 1); ?>" checked />
                                <li class="slide-container">
                                    <div class="slide-image">
                                        <img src="/storage/<?php echo e($images->product_images); ?>">
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-dots">
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $value->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="img-<?php echo e($key + 1); ?>" class="carousel-dot"
                                        id="img-dot-<?php echo e($key + 1); ?>"></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </ul>
                </div>

                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4 class=""><?php echo e($value->product_name); ?></h4>
                    <p class="card-text"><?php echo e($value->description); ?></p>
                    <h2 class="font-weight-bold text-dark">₹<?php echo e($value->price); ?></h2>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- Modal -->

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views//admin/product/products/detailed_product.blade.php ENDPATH**/ ?>