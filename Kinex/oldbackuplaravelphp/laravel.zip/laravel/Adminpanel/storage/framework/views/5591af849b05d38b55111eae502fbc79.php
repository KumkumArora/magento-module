<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add Attribute</h4>
                        <form>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputCategory">Attribute Name</label>
                                <input type="text" class="form-control" id="exampleInputCategory"
                                    placeholder="Enter Brand">
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/attributes/product_attribute_form.blade.php ENDPATH**/ ?>