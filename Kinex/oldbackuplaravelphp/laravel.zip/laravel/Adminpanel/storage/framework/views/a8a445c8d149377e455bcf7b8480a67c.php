<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="<?php echo e(route('admin.dashboard')); ?>"><img src="<?php echo e(asset('assets/images/icon/logo.png')); ?>" alt="logo"
                    class="img2"></a>
        </div>
    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <li class="active">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" aria-expanded="true"><i
                                class="ti-dashboard"></i><span>dashboard</span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('show.products')); ?>" aria-expanded="true"><i
                                class="ti-list"></i><span>Products</span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.customers')); ?>" aria-expanded="true"><i
                                class="ti-user"></i><span>Customers</span></a>
                    </li>
                    <li>
                        <a href="" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Products
                                Attributes
                            </span></a>
                        <ul class="collapse">
                            <li class="active"><a href="<?php echo e(route('attribute_types')); ?>">Add Attribute type</a>
                            </li>
                            <li><a href="<?php echo e(route('attribute.name.form')); ?>">Add Attribute Names</a></li>
                            <li><a href="<?php echo e(route('attribute.values.form')); ?>">Add Attribute Value</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('show.product.categories')); ?>" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Product Categories
                            </span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.product.products')); ?>" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Add Products </span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.product.show')); ?>" aria-expanded="true"><i
                                class="ti-layout-sidebar-left"></i><span>Listing</span></a>
                    </li>

                </ul>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/layout/Includes/sidebar.blade.php ENDPATH**/ ?>