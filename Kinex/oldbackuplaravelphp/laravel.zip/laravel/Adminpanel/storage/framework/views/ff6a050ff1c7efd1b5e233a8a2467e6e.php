<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <div class="row">
            <!-- basic form start -->
            <div class="col-11 p-5 ml-5">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Add More Details</h4>
                        <form method="post" action="<?php echo e(route('add.product.attributes')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $attributeNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($id); ?>">
                                <input type="hidden" name="attribute_id[]" value="<?php echo e($attributes['id']); ?>">
                                <div class="form-group">
                                    <?php if($attributes['type'] == 'Multiple'): ?>
                                        <label class="col-form-label">Select <?php echo e($attributes['attribute_name']); ?></label>
                                        <select class="custom-select" name="attribute_values_id[]" multiple>
                                            <option value="">Select....</option>
                                            <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($values['id']); ?>"
                                                    <?php if(old('attribute_values_id') == $values['id']): ?> selected <?php endif; ?>><?php echo e($values->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                    <?php if($attributes['type'] == 'boolean'): ?>
                                        <div class="form-group">
                                            <label class="col-form-label"><?php echo e($attributes['attribute_name']); ?></label>
                                            <br>
                                            <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($attributes['id'] == $values['attributes_id']): ?>
                                                    <label class="switch">
                                                        <input type="checkbox" value="<?php echo e($values['id']); ?>"
                                                            name="attribute_values_id[]">
                                                        <span class="slider round"></span>
                                                    </label>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($attributes['type'] == 'Single'): ?>
                                        <label class="col-form-label">Select <?php echo e($attributes['attribute_name']); ?></label>
                                        <select class="custom-select" name="attribute_values_id[]">
                                            <option value="">Select....</option>
                                            <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($values['id']); ?>"
                                                    <?php if(old('attribute_values_id') == $values['id']): ?> selected <?php endif; ?>><?php echo e($values->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                    <?php if($errors->has('attribute_values_id')): ?>
                                        <div class="text-danger"><?php echo e($errors->first('attribute_values_id')); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/admin/product/products/product_attributes_form.blade.php ENDPATH**/ ?>