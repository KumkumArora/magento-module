<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="main-content-inner">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="container padding-bottom-3x mb-1">

            <!-- Shopping Cart-->
            <div class="table-responsive shopping-cart">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-center">Unit Price</th>
                            <th class="text-center">Subtotal</th>
                            <th class="text-center">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="product-item">
                                        <a class="product-thumb"
                                            href="<?php echo e(route('view.details.product', $cartItems->products->id)); ?>"><img
                                                src="/storage/<?php echo e($cartItems->products->feature_image); ?>" alt="Product"></a>
                                        <div class="product-info">
                                            <h4 class="product-title"><a
                                                    href="#"><?php echo e($cartItems->products->product_name); ?></a></h4>
                                            <span><em>SKU:</em><?php echo e($cartItems->products->sku); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <div class="count-input">
                                        <input type="text" class="form-control" id="qty"
                                            data-id="<?php echo e($cartItems->id); ?>" value="<?php echo e($cartItems->qty); ?>" name="qty">
                                    </div>
                                </td>
                                <td class="text-center text-lg text-medium">₹
                                    <?php echo e($cartItems->products->price); ?></td>
                                <td class="text-center text-lg text-medium">₹
                                    <?php echo e($cartItems->products->price * $cartItems->qty); ?></td>
                                <td class="text-center"><a class="remove-from-cart"
                                        href="<?php echo e(route('delete.cart.item', $cartItems->id)); ?>" data-toggle="tooltip"
                                        title="Remove" data-original-title="Remove item"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="shopping-cart-footer">
                <div class="column">
                    <form class="coupon-form" method="post">
                        <input class="form-control form-control-sm" type="text" placeholder="Coupon code" required="">
                        <button class="btn btn-outline-primary btn-sm" type="submit">Apply Coupon</button>
                    </form>
                </div>
                <div class="column text-lg">Subtotal: <span class="text-medium">₹ <?php echo e($total); ?></span>
                </div>
            </div>
            <div class="shopping-cart-footer">
                <div class="column"><a class="btn btn-outline-secondary" href="<?php echo e(route('show.products')); ?>"><i
                            class="icon-arrow-left"></i>&nbsp;Back to Shopping</a></div>
                <div class="column"><a class="btn btn-success" href="<?php echo e(url('checkout')); ?>">Checkout</a></div>
            </div>
        </div>
    </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('input').on('change', function(e) {
                var cart_id = $(this).data('id');
                var qty = $(this).val();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "<?php echo e(route('update.cart.qty')); ?>",
                    type: 'Post',
                    data: {
                        "cart_id": cart_id,
                        "qty": qty,
                    },
                    success: function(data) {

                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views/addtocart.blade.php ENDPATH**/ ?>