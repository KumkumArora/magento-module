<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="main-content-inner">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <!-- basic form start -->
            <div class="col-12 p-5 ml-5">
                <div class="carousel">
                    <ul class="slides">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $value->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="radio" name="radio-buttons" id="img-<?php echo e($key + 1); ?>" checked />
                                <li class="slide-container">
                                    <div class="slide-image">
                                        <img src="/storage/<?php echo e($images->product_images); ?>" width="250px" height="400px">
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-dots">
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $value->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="img-<?php echo e($key + 1); ?>" class="carousel-dot"
                                        id="img-dot-<?php echo e($key + 1); ?>"></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </ul>
                </div><br>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h1 class=""><?php echo e($value->product_name); ?></h1>
                    <h5 class="card-text"><?php echo e($value->description); ?></h5>
                    <br>
                    <h2 class="font-weight-bold text-dark">Price : ₹<?php echo e($value->price); ?></h2>
                    <br>
                    <div class="container">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="p-3 border bg-light">
                                    <h4>Product Sku :- <?php echo e($value->sku); ?></h4>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-3 border bg-light">
                                    <h4>In Stock :- <?php echo e($value->stock); ?></h4>
                                </div>
                            </div>
                            <?php if($productInfo): ?>
                                <?php $__currentLoopData = $productInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6">
                                        <div class="p-3 border bg-light">
                                            <h4><?php echo e($key); ?> : <?php echo e(implode(',', $data)); ?></h4>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('add.to.cart')); ?>">
                        <?php echo csrf_field(); ?>
                        <label for="exampleInputCategory">Add Qty</label>
                        <br>
                        <input type="hidden" name="product_id" value="<?php echo e($value->id); ?>">
                        <input type="text" name="qty" value="" required>
                        <br><br>
                        <button type="submit" class="btn btn-flat btn-primary btn-lg mb-3">
                            <h5>Add To Cart <i class="fa fa-shopping-cart"></i></h5>
                        </button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- Modal -->

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/Adminpanel/resources/views//detailed_product.blade.php ENDPATH**/ ?>