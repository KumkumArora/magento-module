<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PaymentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('login');
})->name('login');

Route::get('register', function () {
    return view('register');
});

Route::get('/admin/product/categories', function () {
    return view('admin.product.categories.product_category_form');
})->name('admin.product.categories');

Route::get('/admin/customers', [UserController::class, 'showCustomers'])->name('admin.customers');
Route::get('/admin/dashboard', [AdminController::class, 'showDashborad'])->name('admin.dashboard');
Route::get('attributetype_form', [AdminController::class, 'showAttributeNameForm'])->name('attribute.type.form');
Route::get('/admin/product/attribute/type', [AdminController::class, 'attributeTypeListing'])->name('attribute_types');
Route::get('/admin/product/attribute/asign/{id}', [AdminController::class, 'asignAttributes'])->name('asign_attributes');
Route::post('/admin/product/attribute/asign/{id}', [AdminController::class, 'addAsignedAttributes'])->name('add.asigned.attributes');
Route::get('attributevalue_form', [AdminController::class, 'showAttributevalueForm'])->name('attribute.values.form');
Route::get('attributes', [AdminController::class, 'showAttributeForm'])->name('attribute.name.form');
Route::post('add_attrubute_type', [AdminController::class, 'addAttributeType'])->name('add.attribute.type');
Route::post('add_attribute_name', [AdminController::class, 'addAttributeNames'])->name('add.attribute.names');
Route::post('add_attribute_values', [AdminController::class, 'addAttributeValues'])->name('add.attribute.values');
Route::post('/admin/product/products/add', [AdminController::class, 'addProduct'])->name('add.product');
Route::get('/admin/product/productform', [AdminController::class, 'showProductForm'])->name('admin.product.products');
Route::get('admin/product/products/addmore/{id}', [AdminController::class, 'showProductAttributeForm'])->name('product.attribute.form');
Route::post('/admin/product/products/addproductattributes', [AdminController::class, 'addProductAttributes'])->name('add.product.attributes');
Route::post('/admin/product/categories', [AdminController::class, 'addCategory'])->name('add.category');
Route::get('/admin/product/category', [AdminController::class, 'showCategories'])->name('show.product.categories');
Route::get('/admin/product/products/show', [AdminController::class, 'showListing'])->name('admin.product.show');
Route::get('/admin/product/products/show/{id}', [AdminController::class, 'viewProductImages'])->name('view.more.images');
Route::get('/admin/product/products/delete/{id}', [AdminController::class, 'deleteImage']);
Route::post('/admin/product/products/editimage', [AdminController::class, 'editSingleImage'])->name('edit.single.image');
Route::get('/admin/product/products/deleteproduct/{id}', [AdminController::class, 'deleteProduct'])->name('delete.product');
Route::get('/admin/product/products/editproduct/{id}', [AdminController::class, 'editProduct'])->name('edit.product');
Route::post('/admin/product/products/update', [AdminController::class, 'updateProduct'])->name('update.product');


Route::get('/products', [ProductController::class, 'showAllProducts'])->name('show.products');
Route::get('/products/{id}', [ProductController::class, 'showMoreDeatils'])->name('view.details.product');


Route::post('/registration',[UserController::class,'registration'])->name('add.user');
Route::post('/login',[UserController::class, 'login'])->name('login.user');
Route::get('/logout',[UserController::class,'logout'])->name('logout');

Route::post('addcart', [ProductController::class,'addToCart'])->name('add.to.cart')->middleware('auth');
Route::get('mycart',[ProductController::class,'cartListing'])->name('cart.list')->middleware('auth');
Route::get('delete/{id}',[ProductController::class,'deleteCartItem'])->name('delete.cart.item');
Route::post('updateqty',[ProductController::class, 'updateCartQty'])->name('update.cart.qty');

Route::get('checkout',  [PaymentController::class, 'index'])->middleware('auth');
Route::post('/payment', [PaymentController::class, 'payment']);

Route::get('myorders',[ProductController::class,'myOrderList'])->name('my.order.list')->middleware('auth');
Route::get('orders/{id}',[ProductController::class,'orderDetails'])->name('ordered.products.details')->middleware('auth');