<?php

namespace App\Listeners;

use App\Events\verificationEmail;
use App\Mail\verifyUser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class handleEmail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\verificationEmail  $event
     * @return void
     */
    public function handle(verificationEmail $event)
    {
         Mail::to($event->user->email)->send(

         new verifyUser($event->user));
    }
}
