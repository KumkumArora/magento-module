<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\userRegisterationtRequest;
use App\Models\User;
use App\Events\verificationEmail;
use Illuminate\Support\Str;

class userController extends Controller
{

    public function userRegistration(userRegisterationtRequest $request)
    {
        $token = Str::random(20);
        $user = User::create([

            'first_name'=> $request['firstname'],
            'last_name' => $request['lastname'],
            'gender'    => $request['gender'],
            'email'     => $request['email'],
            'password'  => $request['password'],
            'type'      => $request['type'],
            'token'     => $token,
        ]);

        if(!is_null($user)){
            event(new verificationEmail($user));
        }
        return redirect()->back()->with('message', 'Your Account has been register successfully please check the vesrification email');

    }

    public function verifyAccount($token)
    {
        {
            $user = User::where('token', $token)->first();

            $message = 'Sorry your email cannot be identified.';

            if(!is_null($user) ){

                if(!$user->email_verified_at) {
                    $user->email_verified_at = date('Y-m-d H:i:s');
                    $user->save();
                    $message = "Your e-mail is verified. You can now login.";
                } else {
                    $message = "Your e-mail is already verified. You can now login.";
                }
            }

          return redirect()->route('/')->with('message', $message);
        }
    }
}
