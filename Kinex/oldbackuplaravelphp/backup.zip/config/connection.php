<?php

$servername = "localhost";
$username = "root";
$password = "root";
$db = "texting";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);

// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
} else {
   echo "Connected successfully";
}

// insert Query
try {

   if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $name = $_REQUEST['name'];
      $email = $_REQUEST['email'];
      $address =  $_REQUEST['address'];
      $city = $_REQUEST['city'];

      $sql = "INSERT INTO student (name,email,address,city) VALUES ('$name','$email','$address','$city')";

      if ($conn->query($sql) == TRUE) {
         echo "New record created successfully";
      } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
      }
   }
} catch (Exception $e) {
   echo 'Message: ' . $e->getMessage();
}
