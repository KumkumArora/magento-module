<?php

session_start();
include('user.php');
$userModel = new User();

$valid = true;

if (isset($_POST['save-user'])) {

    $hobbies     = $_POST['hobby'];
    $filename    = $_FILES['file']['name'];
    $fileTmpName = $_FILES["file"]["tmp_name"];
    $random      = rand(1111, 9999);
    $newFileName = $random . $filename;
    $file_ext    = strtolower(end(explode('.', $_FILES['file']['name'])));
    $expensions  = array("jpeg", "jpg", "png");

    if (empty($_POST["firstname"])) {
        $valid = false;
        $errorMsg['firstname'] = 'Firstname is required field';
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])) {
        $valid = false;
        $errorMsg['nameErr'] = 'Only letters and white space allowed.';
    }

    if (empty($_POST["lastname"])) {
        $valid = false;
        $errorMsg['lastnameEmptyErr'] = 'lastname is required field';
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST['lastname'])) {
        $valid = false;
        $errorMsg['lastnameErr'] = 'Only letters and white space allowed.';
    }

    if (empty($_POST["email"])) {
        $valid = false;
        $errorMsg['emailEmptyErr'] = 'email is required field';
    } else if (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $_POST['email'])) {
        $valid = false;
        $errorMsg['emailErr'] = ' Email format is not valid..';
    }

    if (empty($_POST["gender"])) {
        $valid = false;
        $errorMsg['genderErr'] = 'Specify Your Gender';
    }

    if (empty($_POST["hobby"])) {
        $valid = false;
        $errorMsg['hobbyErr'] = 'Select your Hobbies';
    }

    if (empty($_FILES['file']['name'])) {
        $valid = false;
        $errorMsg['fileEmptyErr'] = 'image is required field';
    } elseif (in_array($file_ext, $expensions) === false) {
        $valid = false;
        $errorMsg['fileErr'] = "* File must be PNG, JPEG or GIF format.</br>";
    }

    if (empty($_POST["address"])) {
        $valid = false;
        $errorMsg['addressErr'] = 'Address is required field';
    }

    if (empty($_POST["city"])) {
        $valid = false;
        $errorMsg['cityErr'] = 'City is required field';
    }

    if (empty($_POST["state"])) {
        $valid = false;
        $errorMsg['stateErr'] = 'state is required field';
    }

    if (empty($_POST["pincode"])) {
        $valid = false;
        $errorMsg['pincodeErr'] = 'pincode is required field';
    }


    if ($valid != true) {
        $_SESSION['errors']  = $errorMsg;
        header('location:registrationForm.php');
    } else {

        $userInfo   = array(
            'firstname'  => $_POST['firstname'],
            'lastname'   => $_POST['lastname'],
            'email'      => $_POST['email'],
            'gender'     => $_POST['gender'],
            'hobbies'    => implode(",", $hobbies),
            'profile'    => $newFileName,
            'address'    => $_POST['address'],
            'city'       => $_POST['city'],
            'state'      => $_POST['state'],
            'pincode'    => $_POST['pincode'],
        );

        $uploadPath  = "uploads/" . $newFileName;
        move_uploaded_file($fileTmpName, $uploadPath);
        $userModel->store($userInfo);
    }
}


if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $userModel->deleteUser($id);
}


if (isset($_POST['update-user'])) {

    $is_uploading = $_FILES['file']['error'];
    $can_pass     = $is_uploading == 0 ? true : false;
    $userId       = $_POST['user_id'];
    $hobbies      = $_POST['hobby'];
    if ($can_pass) {
        $filename    = $_FILES['file']['name'];
        $fileTmpName = $_FILES["file"]["tmp_name"];
        $random      = rand(1111, 9999);
        $newFileName = $random . $filename;
        $file_ext    = strtolower(end(explode('.', $_FILES['file']['name'])));
        $expensions  = array("jpeg", "jpg", "png");
        $imagename = $_POST['file'];

        unlink("uploads/$imagename");

        if (empty($_FILES['file']['name'])) {

            $valid = false;
            $errorMsg['fileEmptyErr'] = 'image is required field';
        } elseif (in_array($file_ext, $expensions) === false) {
            $valid = false;
            $errorMsg['fileErr'] = "*File must be PNG, JPEG or GIF format.</br>";
        }
    } else {
        $newFileName = $_POST['file1'];
    }
    if (empty($_POST["firstname"])) {
        $valid = false;
        $errorMsg['firstname'] = 'Firstname is required field';
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST['firstname'])) {
        $valid = false;
        $errorMsg['nameErr'] = 'Only letters and white space allowed.';
    }

    if (empty($_POST["lastname"])) {
        $valid = false;
        $errorMsg['lastnameEmptyErr'] = 'lastname is required field';
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST['lastname'])) {
        $valid = false;
        $errorMsg['lastnameErr'] = 'Only letters and white space allowed.';
    }

    if (empty($_POST["email"])) {
        $valid = false;
        $errorMsg['emailEmptyErr'] = 'email is required field';
    } else if (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $_POST['email'])) {
        $valid = false;
        $errorMsg['emailErr'] = ' Email format is not valid..';
    }

    if (empty($_POST["gender"])) {
        $valid = false;
        $errorMsg['genderErr'] = 'Specify Your Gender';
    }

    if (empty($_POST["hobby"])) {
        $valid = false;
        $errorMsg['hobbyErr'] = 'Select your Hobbies';
    }

    if (empty($_POST["address"])) {
        $valid = false;
        $errorMsg['addressErr'] = 'Address is required field';
    }

    if (empty($_POST["city"])) {
        $valid = false;
        $errorMsg['cityErr'] = '*City is required field';
    }

    if (empty($_POST["state"])) {
        $valid = false;
        $errorMsg['stateErr'] = 'state is required field';
    }

    if (empty($_POST["pincode"])) {
        $valid = false;
        $errorMsg['pincodeErr'] = 'pincode is required field';
    }

    if ($valid != true) {
        $_SESSION['errors']  = $errorMsg;
        header('location:registrationForm.php?edit_id=' . $userId);
    } else {
        $updateUserinfo  = array(
            'firstname'  => $_POST['firstname'],
            'lastname'   => $_POST['lastname'],
            'email'      => $_POST['email'],
            'gender'     => $_POST['gender'],
            'hobbies'    => implode(",", $hobbies),
            'profile'    => $newFileName,
            'address'    => $_POST['address'],
            'city'       => $_POST['city'],
            'state'      => $_POST['state'],
            'pincode'    => $_POST['pincode'],
            'fileTmpName' => $_FILES["file"]["tmp_name"],
        );
        $userModel->updateUser($updateUserinfo, $userId);
        $uploadPath  = "uploads/" . $updateUserinfo['profile'];
        move_uploaded_file($updateUserinfo['fileTmpName'], $uploadPath);
    }
}
