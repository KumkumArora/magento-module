<?php
session_start();
include('user.php');

if (isset($_SESSION['inserted']))
{
?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Hey !</strong> <?= $_SESSION['inserted']; ?>
    </div>
<?php
    unset($_SESSION['inserted']);
}

if (isset($_SESSION['deleted']))
{
?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Hey !</strong> <?= $_SESSION['deleted']; ?>
    </div>
<?php
    unset($_SESSION['deleted']);
}

if (isset($_SESSION['updated']))
{
?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <strong>Hey !</strong> <?= $_SESSION['updated']; ?>
    </div>
<?php
    unset($_SESSION['updated']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Display Registered Users</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div style="padding: 100px 100px;">
        <a href="registrationForm.php"><button type="button" class="btn btn-primary float-right mt-2 mb-3">Create User</button></a>
        <h2 class="mt-3">Registered Users</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Hobbies</th>
                    <th>Profile</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Pincode</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <?php
            $obj = new User();
            $userDetails = $obj->fetchData();
            if ($userDetails) {
                foreach ($userDetails as $row) {
            ?>
                    <tbody>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['firstname']; ?></td>
                            <td><?php echo $row['lastname']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['gender']; ?></td>
                            <td><?php echo $row['hobbies']; ?></td>
                            <td><img src="uploads/<?php echo $row['profile']; ?>" width="100px" height="100px"></td>
                            <td><?php echo $row['address']; ?></td>
                            <td><?php echo $row['city']; ?></td>
                            <td><?php echo $row['state']; ?></td>
                            <td><?php echo $row['pincode']; ?></td>
                            <td><a href="registrationForm.php?edit_id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary">Edit</button></a></td>
                            <td><a href="usercontroller.php?delete_id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-danger">Delete</button></a></td>
                        </tr>
                    </tbody>
            <?php
                }
            }
            ?>
        </table>
    </div>

</body>

</html>