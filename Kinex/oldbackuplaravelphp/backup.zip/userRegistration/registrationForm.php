<?php
session_start();
include('user.php');

if (isset($_GET['edit_id'])) {
    $userId = $_GET['edit_id'];
    $user = new User();
    $userDetail = $user->editUser($userId);
    $checkbox_array = explode(",", $userDetail['hobbies']);
}

if (isset($_SESSION['errors'])) {
    $errorMsg = $_SESSION['errors'];
    session_destroy();
} else {
    $errorMsg = null;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>User Registration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        function validateForm() {

            var form_data = new FormData(document.querySelector("form"));
            var file = document.getElementById("file");

            if (document.forms["myForm"]["name"].value == "") {
                document.getElementById("name-error").innerHTML = "Name must be filled Out";
                return false;
            }

            if (document.forms["myForm"]["lastname"].value == "") {
                document.getElementById("lastname-error").innerHTML = "Lastname must be filled out";
                return false;
            }

            if (document.forms["myForm"]["email"].value == "") {
                document.getElementById("email-error").innerHTML = "Email must be filled Out";
                return false;
            }

            if (document.forms["myForm"]["gender"].value == "") {
                document.getElementById("gender-error").innerHTML = "Specify Your Gender";
                return false;
            }

            if (!form_data.has("hobby[]")) {
                document.getElementById("hobby-error").innerHTML = "please select atleast one option";
                return false;
            }
            var filePath = file.value;
            var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
            if (file.files.length == 0 && document.forms["myForm"]["file1"].value == ""){
                document.getElementById("file-error").innerHTML = "Image Must be Uploaded";
                return false;
             } 
             else if(!allowedExtensions.exec(filePath)){
                document.getElementById("file-error").innerHTML ='Please upload file having extensions .jpeg/.jpg/.png/.gif only.';
                file.value = '';
                return false;
             }
             
            if (document.forms["myForm"]["address"].value == "") {
                document.getElementById("address-error").innerHTML = "Address must be filled out";
                return false;
            }
            if (document.forms["myForm"]["city"].value == "") {
                document.getElementById("city-error").innerHTML = "City must be filled out";
                return false;
            }
            if (document.forms["myForm"]["state"].value == "") {
                document.getElementById("state-error").innerHTML = "State must be filled out";
                return false;
            }
            if (document.forms["myForm"]["pincode"].value == "") {
                document.getElementById("pincode-error").innerHTML = "Pincode must be filled out";
                return false;
            }

            return true;
        }
    </script>
</head>

<body>
    <div class="container" style="padding: 50px 0px;">
        <a href="userDisplay.php"><button type="submit" class="btn btn-primary" name="show">User Listing</button></a>
        </br>
        </br>
        <h2 class="text-center">Registration form</h2>
        </br></br>
        <form action="usercontroller.php" method="post" enctype="multipart/form-data" name="myForm" onsubmit="return validateForm()">
            <input type="hidden" name="user_id" value="<?php echo (isset($userDetail) ? $userDetail['id'] : '') ?>">
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="firstname">First Name:</label>
                        <span class="text-danger"><?php echo $errorMsg['firstname']; ?></span>
                        <span class="text-danger"><?php echo $errorMsg['nameErr']; ?></span>
                        <input type="text" class="form-control" id="name" value="<?php echo (isset($userDetail) ? $userDetail['firstname'] : '') ?>" placeholder="Enter Your Name" name="firstname">
                        <span id="name-error" class="text-danger"></span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="lastname">Last Name:</label>
                        <span class="text-danger"><?php echo $errorMsg['lastnameEmptyErr']; ?></span>
                        <span class="text-danger"><?php echo $errorMsg['lastnameErr']; ?></span>
                        <input type="text" class="form-control" id="lastname" value="<?php echo (isset($userDetail) ? $userDetail['lastname'] : '') ?>" placeholder="Enter Last Name" name="lastname">
                        <span id="lastname-error" class="text-danger"></span>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <span class="text-danger"><?php echo $errorMsg['emailEmptyErr']; ?></span>
                <span class="text-danger"><?php echo $errorMsg['emailErr']; ?></span>
                <input type="email" class="form-control" id="email" value="<?php echo (isset($userDetail) ? $userDetail['email'] : '') ?>" placeholder="Enter email" name="email">
                <span id="email-error" class="text-danger"></span>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <span class="text-danger"><?php echo $errorMsg['genderErr']; ?></span>
                        </br>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio1">
                                        <input type="radio" class="form-check-input" id="gender" name="gender" value="male" <?php if ($userDetail['gender'] == 'male') {echo " checked=\"checked\"";} ?>>Male
                                    </label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio2">
                                        <input type="radio" class="form-check-input" id="gender" name="gender" value="female" <?php if ($userDetail['gender'] == 'female') { echo " checked=\"checked\"";  } ?>>Female
                                    </label>
                                </div>
                            </div>
                            <span id="gender-error" class="text-danger"></span>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="hobby">Hobbies:</label>
                        <span class="text-danger"><?php echo $errorMsg['hobbyErr']; ?></span>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="check1">
                                        <input type="checkbox" class="form-check-input checkbox" id="reading" name="hobby[]" value="reading" <?php if (in_array("reading", $checkbox_array)) {echo " checked=\"checked\""; } ?>>Reading
                                    </label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="check2">
                                        <input type="checkbox" class="form-check-input checkbox" id="travelling" name="hobby[]" value="travelling" <?php if (in_array("travelling", $checkbox_array)) {echo " checked=\"checked\""; } ?>>Travelling
                                    </label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input checkbox" id="playing" name="hobby[]" value="playing" <?php if (in_array("playing", $checkbox_array)) { echo " checked=\"checked\""; } ?>>Playing
                                    </label>
                                </div>
                            </div>
                            <span id="hobby-error" class="text-danger"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="profile">Upload Profile Pic:</label>
                <span class="text-danger"><?php echo $errorMsg['fileEmptyErr']; ?></span>
                <span class="text-danger"><?php echo $errorMsg['fileErr']; ?></span>
                <input type="file" class="form-control-file border" name="file" id="file">
                <input type="hidden" class="form-control-file border" name="file1" value="<?php echo (isset($userDetail) ? $userDetail['profile'] : '') ?>">
                <span id="file-error" class="text-danger"></span>
                <?php if ($userDetail) {
                ?>
                    <img src="uploads/<?php echo $userDetail['profile']; ?>" width="100px" height="100px">
                <?php } ?>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <span class="text-danger"><?php echo $errorMsg['addressErr']; ?></span>
                <input type="text" class="form-control" id="address" value="<?php echo (isset($userDetail) ? $userDetail['address'] : '') ?>" placeholder="Enter Address" name="address">
                <span id="address-error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="city">City:</label>
                <span class="text-danger"><?php echo $errorMsg['cityErr']; ?></span>
                <select name="city" class="custom-select mb-3">
                    <option value="">Select Your City</option>
                    <option value="ludhiana" <?php if ($userDetail['city'] == 'ludhiana') {echo " selected=\"selected\""; } ?>>Ludhiana</option>
                    <option value="jalandher" <?php if ($userDetail['city'] == 'jalandher') {echo " selected=\"selected\"";} ?>>Jalandher</option>
                    <option value="chandigarh" <?php if ($userDetail['city'] == 'chandigarh') {echo " selected=\"selected\"";} ?>>Chandigarh</option>
                    <option value="patiala" <?php if ($userDetail['city'] == 'patiala') { echo " selected=\"selected\"";} ?>>Patiala</option>
                    <option value="bathinda" <?php if ($userDetail['city'] == 'bathinda') {echo " selected=\"selected\"";} ?>>Bathinda</option>
                </select>
                <span id="city-error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="state">State:</label>
                <span class="text-danger"><?php echo $errorMsg['stateErr']; ?></span>
                <select name="state" class="custom-select mb-3">
                    <option value="">Select Your State</option>
                    <option value="india" <?php if ($userDetail['state'] == 'india') {echo " selected=\"selected\"";} ?>>India</option>
                    <option value="usa" <?php if ($userDetail['state'] == 'usa') {echo " selected=\"selected\"";} ?>>USA</option>
                    <option value="uk" <?php if ($userDetail['state'] == 'uk') {echo " selected=\"selected\"";} ?>>UK</option>
                    <option value="canada" <?php if ($userDetail['state'] == 'canada') {echo " selected=\"selected\"";} ?>>Canada</option>
                </select>
                <span id="state-error" class="text-danger"></span>
            </div>
            <div class="form-group">
                <label for="pincode">Pincode:</label>
                <span class="text-danger"><?php echo $errorMsg['pincodeErr']; ?></span>
                <input type="text" class="form-control" id="pincode" value="<?php echo (isset($userDetail) ? $userDetail['pincode'] : '') ?>" placeholder="Enter Pincode" name="pincode">
                <span id="pincode-error" class="text-danger"></span>
            </div>
            <?php
            if ($userDetail) {
            ?>
                <button type="submit" class="btn btn-danger" name="update-user">Update</button>
            <?php } else {
            ?>
                <button type="submit" class="btn btn-primary" name="save-user">Save</button>
            <?php } ?>
        </form>
    </div>

</body>

</html>