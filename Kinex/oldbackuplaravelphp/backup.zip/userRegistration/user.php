<?php
include('connection.php');

class User
{
    private $conn;

    function __construct()
    {
        $dbConnection = new Database();
        $this->conn = $dbConnection->getDbConnection();
    }

    function store($userInfo)
    {
        $store = "INSERT INTO user(firstname, lastname, email, gender, hobbies, profile, address, city, state, pincode) VALUES ('$userInfo[firstname]', '$userInfo[lastname]', '$userInfo[email]', '$userInfo[gender]', '$userInfo[hobbies]', '$userInfo[profile]', '$userInfo[address]', '$userInfo[city]','$userInfo[state]', $userInfo[pincode])";

        if ($this->conn->query($store) == TRUE)
        {
            $_SESSION['inserted'] = "Successfully a new User added";
            header("Location: userDisplay.php");
        }
        else
        {
            echo "Error: " . $store . "<br>" . $this->conn->error;
        }
    }

    function fetchData()
    {
        $array = array();
        $query = "SELECT * FROM user";
        $result = mysqli_query($this->conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            $array[] = $row;
        }
        return $array;
    }

    function deleteUser($id)
    {
        $sql = "SELECT * FROM user WHERE id=$id";
        $result = mysqli_query($this->conn, $sql);
        $row = mysqli_fetch_array($result);

        unlink("uploads/$row[profile]");

        $query = "DELETE FROM user WHERE id = $id";
        $result = mysqli_query($this->conn, $query);
        if ($result)
        {
            $_SESSION['deleted'] = "User Deleted Successfully";
            header('location:userDisplay.php');
        } 
        else 
        {
            echo "Error: " . $query . "<br>" . $this->conn->error;
        }
    }

    function editUser($id)
    {
        $query = "SELECT * FROM user WHERE id = $id";
        $result = mysqli_query($this->conn, $query);
        $row = mysqli_fetch_assoc($result);

        return $row;

    }

    function updateUser($updateUserinfo, $userId)
    {      
        $update = "UPDATE user SET firstname = '$updateUserinfo[firstname]', lastname = '$updateUserinfo[lastname]', email = '$updateUserinfo[email]', gender = '$updateUserinfo[gender]', hobbies = '$updateUserinfo[hobbies]', profile = '$updateUserinfo[profile]', address = '$updateUserinfo[address]', city = '$updateUserinfo[city]', state= '$updateUserinfo[state]', pincode= '$updateUserinfo[pincode]' WHERE id = $userId";

        $result = $this->conn->query($update);
        if($result)
        {
            $_SESSION['updated'] = "User Updated successfully";
            header('location:userDisplay.php');
        }
        else
        {
            echo "Error: " . $result . "<br>" . $this->conn->error;
        }
    }
}
