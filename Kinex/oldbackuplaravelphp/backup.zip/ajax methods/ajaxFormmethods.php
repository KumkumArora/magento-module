   <!-- for reset the value of input type text -->
   $('#userForm').find('input').val('');  
   
      <!-- for reset the value of input type radio-->
   $("input[type=radio]").prop('checked', false); ;
   
     <!-- for reset the value of input type checkbox-->
   $("input[type=checkbox]").prop('checked', false); ;
   
   <!-- for reset the value of input type select-->
   $('select').val('');


<?php
   if ($getUsersdata) {
    $i = 1;
    foreach ($getUsersdata as $users) {
        $images = explode(",", $users['image']);
?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $users['name']; ?></td>
            <td><?= $users['email']; ?></td>
            <td><?= $users['gender']; ?></td>
            <td><?= $users['hobbies']; ?></td>
            <td><?php
                foreach ($images as $image) {
                ?>
                    <img src="images/<?php echo $image; ?>" width="100px" height="100px">
                <?php
                }
                ?>
            </td>
            <td><?= $users['state']; ?></td>
            <td><a id="delete" data-id="<?= $users['user_id']; ?>"><button type="button" class="btn btn-danger">Delete</button>
        </tr>
<?php
        $i++;
    }
}