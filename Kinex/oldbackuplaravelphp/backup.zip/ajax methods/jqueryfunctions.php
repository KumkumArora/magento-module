<html lang="en">

<head>
  <title>Jquery functions</title>

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/javascript" src="ajax-script.js"></script>
  <style>
    .important {
      font-weight: bold;
      font-size: xx-large;
    }

    .blue {
      color: blue;
    }
  </style>
  <script>
    $(document).ready(function() {
      $("#hide").click(function() {
        $("div").hide(1000);
      });
      $("#show").click(function() {
        $("div").show(1000);
      });
      $("#toggle").click(function() {
        $("div").toggle();
      });
      $("#fadeout").click(function() {
        $("div").fadeOut(1000);
      });
      $("#fadein").click(function() {
        $("div").fadeIn(3000);
      });
      $("#fadeto").click(function() {
        $("div").fadeTo("slow", 0.25);
      });
      $("#fadetoggle").click(function() {
        $("div").fadeToggle();
      });
      $("#slidedown").click(function() {
        $("div").slideDown(3000).slideUp("slow");
      });
      $("#slideup").click(function() {
        $("div").slideUp("slow");
      });
      $("#slidetoggle").click(function() {
        $("div").slideToggle();
      });
      $("#animate").click(function() {
        $("div").animate({
          left: '250px',
          width: '100px',
          height: '100px',
          opacity: '0.5',
          fontSize: '3rem',
        }, 5000);
      });

      $("#reload").click(function() {
        location.reload();
      });
      $("#stop").click(function() {
        $("div").stop();
      });
      $("#addclass").click(function() {
        $("div").addClass("blue");
        $("div").addClass("important");
      });
      $("#removeclass").click(function() {
        $("div").removeClass("blue");
        $("div").removeClass("important");
      });
      $("#toggleclass").click(function() {
        $("div").toggleClass("blue");
        $("div").toggleClass("important");
      });



    });
  </script>

</head>

<body>
  <button type="button" id="reload"> Reload Page</button>
  <button type="button" id="stop">Stop Running</button>
  <br>
  <br>
  <button type="button" id="hide"> hide</button>
  <button type="button" id="show"> Show</button>
  <button type="button" id="toggle">toggle</button>
  <button type="button" id="fadeout">fadeout </button>
  <button type="button" id="fadein">fadein</button>
  <button type="button" id="fadeto">fadeto</button>
  <button type="button" id="fadetoggle">fadetoggle</button>
  <button type="button" id="slidedown">slidedown</button>
  <button type="button" id="slideup">sildeup</button>
  <button type="button" id="slidetoggle">slidetoggle</button>
  <button type="button" id="animate">animate</button>
  <button type="button" id="addclass">addclass</button>
  <button type="button" id="removeclass">removeclass</button>
  <button type="button" id="toggleclass">toggleclass</button>
  <br>
  <br>
  <div style="width:200px; height:200px; background-color:cyan;">hello</div>

</body>

</html>