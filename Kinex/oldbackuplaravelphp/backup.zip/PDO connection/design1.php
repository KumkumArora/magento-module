<html>

<head>
<title>Texting</title>
</head>

<body>
  <form action="db_connection.php" method="post">
   </br>
   Name <input type="text" name="name">
   </br> </br>
   Email <input type="email" name="email">
   </br> </br>
   Address <input type="text" name="address">
   </br> </br>
   City  <input type="text" name="city">
   </br> </br>
   <input type="submit" value="save">
  </form>

</body>

</html>