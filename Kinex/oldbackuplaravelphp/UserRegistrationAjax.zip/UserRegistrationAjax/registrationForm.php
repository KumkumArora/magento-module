<!DOCTYPE html>
<html lang="en">

<head>
    <title>User Registration </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="ajax-script.js"></script>
</head>

<body>
    <div class="container" style="padding: 50px 0px;">
       <a href="showUsers.php" class="btn btn-primary btn-lg active float-right" role="button" aria-pressed="true">Listed Users</a>
        <div class="container pt-3">
            <h1 class="text-center text-danger font-weight-bold">User Registration</h1>
        </div>
        <h4 id="msg" class="text-primary font-weight-bold"></h4>
        <form method="post" id="userForm" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Enter Your Name</label>
                <input type="text" class="form-control" placeholder="Enter Name" id="name" name="name">
            </div>
            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" class="form-control" placeholder="Enter email" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" placeholder="Enter password" id="pwd" name="password">
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio1">
                                        <input type="radio" class="form-check-input" id="gender1" name="gender" value="male">Male
                                    </label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio2">
                                        <input type="radio" class="form-check-input" id="gender2" name="gender" value="female">Female
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="hobby">Hobbies:</label>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" value="Playing" name="hobby[]">Playing
                                    </label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" value="Art & Craft" name="hobby[]">Art & Craft
                                    </label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-check-inline">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" value="Travelling" name="hobby[]">Travelling
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="name">Upload Profile</label>
                <input type="file" class="form-control-file border" name="files[]" id="file" multiple>
            </div>
            <div class="form-group">
                <label for="inputState">State</label>
                <select id="state" class="form-control" name="state">
                    <option value="">Choose...</option>
                    <option value="India">India</option>
                    <option value="Pakistan">Pakistan</option>
                    <option value="Shree lanka">Shree Lanka</option>
                    <option value="Nepal">Nepal</option>
                    <option value="USA">USA</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

    </div>
</body>

</html>