<?php
include('user.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Show Users Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"
        integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <div class="container" style="padding: 50px 0px;">
        <h4 id="msg" class="text-primary font-weight-bold"></h4>
        <a href="registrationForm.php" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">New
            Create</a>
        <div class="container pt-3 pb-3">
            <h1 class="text-center text-danger font-weight-bold">User Details</h1>
        </div>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Hobbies</th>
                    <th scope="col">State</th>
                    <th scope="col">Images</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody id="table">

            </tbody>
        </table>
    </div>

    <!-- View Images Modal -->
    <div id="viewImages" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h4 class="modal-title">View Images</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <table class="table" id="showimages">
                        </table>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" id="closeViewmodal"
                            value="Cancel">

                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- edit images modal-->
    <div id="editImage" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Edit Image</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="" id="editForm" enctype="multipart/form-data" method="post">

                        <div class="form-group" id="image">
                            <label for="image">Upload Image</label>

                        </div>
                        <button type="submit" class="btn btn-primary" id="btnUpdateSubmit">Update</button>
                        <input type="button" class="btn btn-default float-right" data-dismiss="modal"
                            id="closeEditmodal" value="Cancel">

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- update user modal -->
    <div id="edit-user-modal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Edit User</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="" id="editUser" enctype="multipart/form-data" method="post">
                        <input class="form-control" type="hidden" name="id">
                        <div class="form-group">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input class="form-control" type="text" name="name">
                            </div>
                            <label for="email">Email</label>
                            <input class="form-control" type="text" name="email">
                        </div>

                        <div class="form-group">
                            <label for="Password">Password</label>
                            <input class="form-control" type="text" name="password">
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio1">
                                            <input type="radio" class="form-check-input" id="gender1" name="gender"
                                                value="male">Male
                                        </label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio2">
                                            <input type="radio" class="form-check-input" id="gender2" name="gender"
                                                value="female">Female
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="hobby">Hobbies:</label>
                            <div class="row">
                                <div class="col-4">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="Playing"
                                                name="hobby[]">Playing
                                        </label>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="Art & Craft"
                                                name="hobby[]">Art & Craft
                                        </label>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" value="Travelling"
                                                name="hobby[]">Travelling
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputState">State</label>
                            <select id="state" class="form-control" name="state">
                                <option value="">Choose...</option>
                                <option value="India">India</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Shree lanka">Shree Lanka</option>
                                <option value="Nepal">Nepal</option>
                                <option value="USA">USA</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" id="UpdateSubmit">Update</button>
                        <button type="button" class="btn btn-danger float-right" data-dismiss="modal">Close</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="ajax-script.js"></script>
    <script>
    $.ajax({
        url: "userController.php",
        type: "GET",
        data: {
            action: 'show'
        },
        success: function(data) {
            $('#table').html(data);
        }
    });
    </script>
</body>

</html>