<?php

include('user.php');
$userDetail = new User();


if (count($_POST) == 6 && count($_FILES) == 1) {

    foreach ($_FILES['files']['name'] as $ke => $val) {
        $filename    = $_FILES['files']['name'][$key];
        $fileTmpName = $_FILES["files"]["tmp_name"][$key];
        $random      = rand(1111, 9999);
        $newFileName = $random . $filename;
        $uploadPath  = "images/" . $newFileName;
        move_uploaded_file($fileTmpName, $uploadPath);

        $images[] = $newFileName;
    }

    $userInfo   = array(
        'name'     => $_POST['name'],
        'email'    => $_POST['email'],
        'password' => $_POST['password'],
        'gender'   => $_POST['gender'],
        'hobbies'  => implode(",", $_POST['hobby']),
        'file'     => implode(",", $images),
        'state'    => $_POST['state'],
    );
    $userDetail->insertUser($userInfo);
}


if (isset($_GET) && $_GET['action'] == 'show') {
    $getUsersdata = $userDetail->showUser();

    if ($getUsersdata) {
        $i = 1;
        foreach ($getUsersdata as $users) {
?>
<tr>
    <td><?= $i ?></td>
    <td><?= $users['name']; ?></td>
    <td><?= $users['email']; ?></td>
    <td><?= $users['gender']; ?></td>
    <td><?= $users['hobbies']; ?></td>
    <td><?= $users['state']; ?></td>
    <td>
        <a data-target="#viewImages" id="view" data-id="<?= $users['id']; ?>" data-toggle="modal">
            <button type="button" class="btn btn-info btn-sm"><i class="fa fa-eye" data-toggle="tooltip"
                    title="View Images"></i></button>
        </a>
    </td>
    <td>
        <a id="delete" data-id="<?= $users['id']; ?>" data-toggle="modal">
            <button type="button" class="btn btn-danger btn-sm"><i class="fa fa-trash" data-toggle="tooltip"
                    title="Delete!"></i></button>
        </a>
        <a data-target="#edit-user-modal" id="edit" data-id="<?= $users['id']; ?>" data-toggle="modal">
            <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-pencil" data-toggle="tooltip"
                    title="Edit!"></i></button>
        </a>
    </td>
</tr>
<?php
            $i++;
        }
    }
}


if (isset($_POST) && $_POST['action'] == 'delete') {
    $id = $_POST['id'];
    $userDetail->deleteUser($id);
}


if (isset($_POST) && $_POST['action'] == 'viewimages') {

    $id = $_POST['id'];
    getImages($id);
}

function getImages($id) {
    $userDetail = new User();
    $getImages = $userDetail->showUserimages($id);
    if($getImages) {
        foreach ($getImages as $images) {
?>
<h6 id="successmsg" class="text-primary font-weight-bold"></h6>
<tr>
    <td><img src="images/<?= $images['image']; ?>" width="150px" height="100px"></td>
    <td>
        <a id="deleteimage" data-id="<?= $images['id']; ?>" data-toggle="tooltip" title="Delete!">
            <button type="button" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
        </a>
        <a data-target="#editImage" id="editimage" data-id="<?= $images['id']; ?>" data-toggle="modal">
            <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-pencil" data-toggle="tooltip"
                    title="Edit!"></i></button>
        </a>
    </td>
</tr>
<?php

        }
    }
}

if (isset($_POST) && $_POST['action'] == 'deleteimage') {
    $id = $_POST['id'];
    $userDetail->deleteParticularimage($id);
}

if (isset($_POST) && $_POST['action'] == 'editimage') {
    $id = $_POST['id'];
    $selectedImage=$userDetail->editParticularimage($id);

    if($selectedImage)
    { 
        ?>
<h6 id="message" class="text-primary font-weight-bold"></h6>
<input class="form-control" type="hidden" name="id" value="<?= $selectedImage['id']; ?>">
<input class="form-control" type="hidden" name="user_id" value="<?= $selectedImage['user_id']; ?>">
<input class="form-control" type="hidden" name="image" value="<?= $selectedImage['image']; ?>">
<input class="form-control" type="file" name="image">
<?php
    }
}

if (count($_POST) == 3 && count($_FILES) == 1){
    
    $imagename = $_POST['image'];
    unlink("images/$imagename");

    $imageId = $_POST['id'];
    $userId = $_POST['user_id'];
    $filename    = $_FILES['image']['name'];
    $fileTmpName = $_FILES["image"]["tmp_name"];
    $random      = rand(1111, 9999);
    $newFileName = $random . $filename;
    $uploadPath  = "images/" . $newFileName;
    move_uploaded_file($fileTmpName, $uploadPath);
    
    $userDetail->updateImage($imageId, $newFileName, $userId);
   
} 

if (isset($_POST) && $_POST['action'] == 'editUser'){
    $id = $_POST['id'];
    $getUser = $userDetail->geteditUser($id);
}

if(count($_POST) == 7 ){
    
    $editedData   = array(
        'id'       => $_POST['id'],
        'name'     => $_POST['name'],
        'email'    => $_POST['email'],
        'password' => $_POST['password'],
        'gender'   => $_POST['gender'],
        'hobbies'  => implode(",", $_POST['hobby']),
        'state'    => $_POST['state'],
    );
    $userDetail->updateUser($editedData);
}