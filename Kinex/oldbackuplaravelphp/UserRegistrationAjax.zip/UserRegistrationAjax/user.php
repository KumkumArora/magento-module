<?php

include('database.php');

class User
{

  private $conn;

  function __construct()
  {
    $dbConnection = new Database();
    $this->conn = $dbConnection->getDbConnection();
  }

  function insertUser($userInfo)
  {
    if ($store = mysqli_query($this->conn, "INSERT INTO User(name, email, password, gender, hobbies,state) VALUES ('$userInfo[name]', '$userInfo[email]', '$userInfo[password]', '$userInfo[gender]', '$userInfo[hobbies]','$userInfo[state]')")) {
      $userId = mysqli_insert_id($this->conn);
    }
    $images = explode(",", $userInfo['file']);

    foreach ($images as $image) {
      $imagesStore = mysqli_query($this->conn, "INSERT INTO userImages(image, user_id) VALUES ('$image', $userId)");
    }
    if ($images && $store) {
      echo "User data was inserted successfully";
      
    } else {
      echo  "Error: " . $store . $imagesStore . "<br>" . mysqli_error($this->conn);
    }
  }

  function showUser()
  {
    $array = array();
    $query = "SELECT * FROM  User";
    $result = mysqli_query($this->conn, $query);
    while ($row = mysqli_fetch_assoc($result)) {
      $array[] = $row;
    }
    return $array;
  }

  function deleteUser($id)
  {
    $sql = "SELECT image FROM userImages WHERE user_id = $id";
    $result = mysqli_query($this->conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
      $array[] = $row;
    }
    foreach ($array as $image) {

      unlink("images/$image[image]");
    }
    $query = "DELETE User, userImages FROM User INNER JOIN userImages ON User.id = userImages.user_id WHERE User.id = $id";
    $result = mysqli_query($this->conn, $query);
    if ($result) {
      echo "User Deleted Successfully";
    } else {
      echo  "Error: " . $query .  "<br>" . mysqli_error($this->conn);
    }
  }

  function showUserimages($id)
  {
    $sql = "SELECT * FROM userImages WHERE user_id = $id";
    $result = mysqli_query($this->conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
      $array[] = $row;
    }
    return $array;
  }

  function deleteParticularimage($id)
  {
    $sql = "SELECT image FROM userImages WHERE id = $id";
    $result = mysqli_query($this->conn, $sql);
    $image = mysqli_fetch_assoc($result);

    unlink("images/$image[image]");

    $query = "DELETE FROM userImages WHERE id = $id";
    $result = mysqli_query($this->conn, $query);
    if ($result) {
      echo "Image Deleted Successfully";
    } else {
      echo  "Error: " . $query .  "<br>" . mysqli_error($this->conn);
    }
  }

  function editParticularimage($id)
  {
    $sql = "SELECT * FROM userImages WHERE id = $id";
    $result = mysqli_query($this->conn, $sql);
    $image = mysqli_fetch_assoc($result);

    return $image;
  }

  function updateImage($imageId, $newFileName, $userId)
  {
    $update = "UPDATE userImages SET image = '$newFileName' WHERE id = $imageId";
    $result = $this->conn->query($update);
    if ($result) {
      $msg = [
        'msg' => 'Image Updated successfully',
        'user_id' => $userId
      ];
      echo json_encode($msg);
    } else {
      echo "Error: " . $result . "<br>" . $this->conn->error;
    }
  }

  function geteditUser($id)
  {
    $sql = "SELECT * FROM User WHERE id = $id";
    $result = mysqli_query($this->conn, $sql);
    $image = mysqli_fetch_assoc($result);
      
    echo json_encode($image);
  }

  function updateUser($editedData)
  {  
    $updateuser ="UPDATE User SET name = '$editedData[name]', email = '$editedData[email]', password = '$editedData[password]', gender = '$editedData[gender]',  hobbies = '$editedData[hobbies]', state = '$editedData[state]' WHERE id = $editedData[id]";
    $result = $this->conn->query($updateuser);
    if ($result)
    {
      echo 'User Updated successfully';
     
    } else {
      echo "Error: " . $result . "<br>" . $this->conn->error;
    }
  }

}
