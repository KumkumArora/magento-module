<?php

class database{

private $servername;
private $username;
private $password;
private $db;

function __construct()
{
    $this->servername = "localhost";
    $this->username = "root";
    $this->password = "root";
    $this->db = "registrationAjax";
}

function getDbConnection()
{
    $conn = mysqli_connect($this->servername, $this->username, $this->password, $this->db);

    return $conn;
}

}
