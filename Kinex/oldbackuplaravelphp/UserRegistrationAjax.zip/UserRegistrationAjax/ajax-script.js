$(document).ready(function (e) {

    $("#userForm").on('submit', (function (e) {
        e.preventDefault();
        $.ajax({
            url: "userController.php",
            method: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $('#msg').html(data);
                $("#userForm").trigger('reset');

                setTimeout(() => {
                    $('#msg').html('');
                }, 3000);
            },
            error: function (e) {
                $("#err").html(e).fadeIn();
            }
        });
    }));


    $(document).on("click", "#view", function () {
        var userid = $(this).data('id');
        getImages(userid);
    });


    $(document).on("click", "#delete", function () {
        var el = this;
        var deleteid = $(this).data('id');

        $.ajax({
            url: "userController.php",
            type: "POST",
            cache: false,
            data: { id: deleteid, action: 'delete' },
            success: function (dataResult) {
                $('#msg').html(dataResult);
                $(el).closest('tr').css('background', 'tomato');
                $(el).closest('tr').fadeOut(800, function () {
                    $(this).remove();
                });
                setTimeout(() => {
                    $('#msg').html('');
                }, 2000);

            }
        });
    });


    $(document).on("click", "#deleteimage", function () {
        var el = this;
        var imageid = $(this).data('id');

        $.ajax({
            url: "userController.php",
            type: "POST",
            data: { id: imageid, action: 'deleteimage' },
            success: function (dataResult) {
                $('#message').html(dataResult);
                $(el).closest('tr').css('background', 'tomato');
                $(el).closest('tr').fadeOut(800, function () {
                    $(this).remove();
                });
                setTimeout(() => {
                    $('#msg').html('');
                }, 2000);

            }
        });
    });

    $(document).on("click", "#editimage", function () {
        var el = this;
        var imageid = $(this).data('id');
        $('#viewImages').hide();

        $.ajax({
            url: "userController.php",
            type: "POST",
            data: { id: imageid, action: 'editimage' },
            success: function (dataResult) {
                $('#image').html(dataResult);

                setTimeout(() => {
                    $('#msg').html('');
                }, 2000);

            }
        });
    });

    $(document).on("click", "#closeEditmodal", function () {
        $('#viewImages').show();
    })

    $(document).on("click", "#closeViewmodal", function () {
       location.reload();
    })

    $("#editForm").on('submit', (function (e) {
        e.preventDefault();
        $.ajax({
            url: "userController.php",
            method: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                var response = JSON.parse(data);
                $("#editForm").trigger('reset');
                $('#editImage').hide();
                getImages(response.user_id);
             
                $('#viewImages').show();
                setTimeout(() => {
                    $('#successmsg').html(response.msg);  
                }, 200);
              

            },
        });
    }));


    $(document).on("click", "#edit", function () {
        var el = this;
        var editid = $(this).data('id');

        $.ajax({
            url: "userController.php",
            type: "POST",
            cache: false,
            data: { id: editid, action: 'editUser' },
            success: function (data) {
                $("input[type=checkbox]").prop('checked', false);
                var response = JSON.parse(data);
                var hobbies = response.hobbies.split(",");
                $("#editUser  [name=\"id\"]").val(response.id);
                $("#editUser  [name=\"name\"]").val(response.name);
                $("#editUser  [name=\"email\"]").val(response.email);
                $("#editUser  [name=\"password\"]").val(response.password);
                $('select').val(response.state);
                $("input[name=gender][value=" + response.gender + "]").prop('checked', true);
                hobbies.forEach(function (element) {
                    $("input[type=checkbox][value='" + element + "']").prop('checked', true);

                });
            }
        });
    });


    $("#editUser").on('submit', (function (e) {
        e.preventDefault();
        $.ajax({
            url: "userController.php",
            method: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $('#msg').html(data);
                $("#editUser").trigger('reset');
                $('#edit-user-modal').hide();
                alert(data);                 
                location.reload();
            },
        });
    }));



});

function getImages(userid) {
    $.ajax({
        url: "userController.php",
        type: "POST",
        data: { id: userid, action: 'viewimages' },
        success: function (imagesdata) {
            $('#showimages').html(imagesdata);
        }
    });
}


