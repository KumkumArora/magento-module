<?php

namespace App\Providers;

use App\Events\AppointmentConfirm;
use App\Events\verificationEmail;
use App\Events\AppointmentCancel;
use App\Listeners\handleEmail;
use App\Listeners\sendConfirmAppointmentEmail;
use App\Listeners\SendAppointmentCancelEmail;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        verificationEmail::class => [
            handleEmail::class,
        ],
        AppointmentConfirm::class => [
            sendConfirmAppointmentEmail::class
        ],
        AppointmentCancel::class => [
            SendAppointmentCancelEmail::class
        ],


    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}