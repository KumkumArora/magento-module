<?php

namespace App\Models;

use App\Models\Doctor;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Appointment extends Model
{
    use HasFactory;

    use SoftDeletes;
    protected $fillable = [
        'doctors_id',
        'patient_id',
        'fullname',
        'age',
        'gender',
        'disease',
        'description',
        'appointment_date',
        'doctor_loginId',
    ];

    public function getdoctor()
    {
        return $this->belongsTo(Doctor::class, 'doctors_id', 'id');
    }
    public function getdoctoruser()
    {
        return $this->belongsTo(User::class, 'doctor_loginId', 'id');
    }

    public function getPatientInfo()
    {
        return $this->belongsTo(User::class, 'patient_id', 'id');
    }
}