<?php

namespace App\Models;

use App\Models\Appointment;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Prescriptions extends Model
{
    use HasFactory;

    use SoftDeletes;

    protected $fillable = [
        'appointment_id',
        'doctors_id',
        'patient_id',
        'prescription_detail',
    ];

    public function getAppointment()
    {
        return $this->belongsTo(Appointment::class, 'appointment_id', 'id');
    }

    public function getdoctorInfo()
    {
        return $this->belongsTo(Doctor::class, 'doctors_id', 'user_id');
    }

    public function getdoctorname()
    {
        return $this->belongsTo(User::class, 'doctors_id', 'id');
    }
}