<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CancelAppointmentMail extends Mailable
{
    use Queueable, SerializesModels;

    public $patient;
    public $date;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($patient, $date)
    {
        $this->patient = $patient;
        $this->date = $date;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Your Appointment is cancelled By the Doctor')
            ->view('emails.cancelappointmentmail');
    }
}