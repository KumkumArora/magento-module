<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Events\verificationEmail;
use App\Http\Requests\loginRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\userRegisterationtRequest;

class userController extends Controller
{

    public function userRegistration(userRegisterationtRequest $request)
    {
        $token = Str::random(20);
        $user = User::create([

            'first_name' => $request['firstname'],
            'last_name' => $request['lastname'],
            'gender' => $request['gender'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'type' => $request['type'],
            'token' => $token,
        ]);

        if (!is_null($user)) {
            event(new verificationEmail($user));
        }
        return redirect()->back()->with('message', 'Your Account has been register successfully please check the verification email');

    }

    public function verifyAccount($token)
    {
        $user = User::where('token', $token)->first();

        $message = 'Sorry your email cannot be identified.';

        if (!is_null($user)) {
            if (!$user->email_verified_at) {
                $user->email_verified_at = date('Y-m-d H:i:s');
                $user->save();
                $message = "Your e-mail is verified. You can now login.";
            } else {
                $message = "Your e-mail is already verified. Now you can login your account.";
            }
        }

        return redirect('login')->with('message', $message);

    }
    public function login(loginRequest $request)
    {
        $credentials = [
            'email' => $request['email'],
            'password' => $request['password'],
        ];
        if (Auth::attempt($credentials)) {
            if (!is_null(Auth::user()->email_verified_at)) {
                return view('dashborad');
            } else {
                return redirect()->back()->with('message', 'Please check the varification Email and confirm your account before login');
            }
        } else {
            return redirect()->back()->with('message', 'Invalid Credentials');

        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('login');
    }
}
