<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Doctor;
use App\Models\Appointment;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Prescriptions;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\AdminDoctorFormRequest;

class adminController extends Controller
{
    public function viewDoctors()
    {
        $getDoctors = User::where('type', 2)->with('getDoctor')->get();
        return view('doctorList', compact('getDoctors'));
    }

    public function viewAppointments()
    {
        $allAppointments = Appointment::with('getdoctor')->with('getdoctoruser')->get();
        return view('allAppointments', compact('allAppointments'));
    }

    public function viewCancelappointments()
    {
        $onlySoftDeleted = Appointment::onlyTrashed()->with('getdoctor')->with('getdoctoruser')->get();
        return view('cancelledappointments', compact('onlySoftDeleted'));
    }

    public function viewPatients()
    {
        $getPatients = Appointment::withTrashed()->with('getPatientInfo')->get();
        return view('patientlist', compact('getPatients'));
    }

    public function doctorStatusActive($id)
    {
        Doctor::where('id', $id)->update(['status' => 1]);
        return redirect()->back();
    }
    public function doctorStatusInactive($id)
    {
        Doctor::where('id', $id)->update(['status' => 0]);
        return redirect()->back();
    }

    public function showPrescriptions()
    {
        $getPrescriptions = Prescriptions::with('getAppointment')->with('getdoctorInfo')->with('getdoctorname')->get();
        return view('prescriptionlist', compact('getPrescriptions'));
    }

    public function showHistory()
    {
        $getHistory = Appointment::where('appointment_date', '<', date('Y-m-d'))->withTrashed()->get();
        return view('history', compact('getHistory'));
    }

    public function addDoctor(AdminDoctorFormRequest $request)
    {
        $token = Str::random(20);
        $user = User::create([

            'first_name' => $request['firstname'],
            'last_name' => $request['lastname'],
            'gender' => $request['gender'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'type' => $request['type'],
            'token' => $token,
        ]);
        Doctor::create([
            'user_id' => $user['id'],
            'age' => $request['age'],
            'educations' => $request['educations'],
            'specialist' => $request['specialist'],
            'experience' => $request['experience'],
        ]);
        return redirect('dashborad')->with('msg', 'Your profile has been created Successfully');
    }
}
