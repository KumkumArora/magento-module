<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Doctor;
use App\Models\Appointment;
use Illuminate\Http\Request;
use App\Models\Prescriptions;
use App\Http\Requests\appointmentFormRequest;

class patientController extends Controller
{

    public function viewAppointmentForm()
    {
        $getDoctors = User::where('type', 2)->with('getDoctor')->get();
        return view('appointmentForm', compact('getDoctors'));

    }
    public function addAppointment(appointmentFormRequest $request)
    {
        $getInsertId = Appointment::create([
            'doctors_id' => $request['doctor_id'],
            'patient_id' => $request['patient_id'],
            'fullname' => $request['fullname'],
            'age' => $request['age'],
            'gender' => $request['gender'],
            'disease' => $request['diseases'],
            'description' => $request['description'],
            'appointment_date' => $request['appointmentDate'],
        ]);
        $Doctor = Doctor::where('id', $request['doctor_id'])->first();
        Appointment::where('id', $getInsertId['id'])->update(['doctor_loginId' => $Doctor['login_id']]);
        return redirect('dashborad')->with('message', 'Your Appointment Booked Successfully');
    }

    public function myAppointments($id)
    {
        $myAppointments = Appointment::where('patient_id', $id)->where('appointment_date', '>=', date('Y-m-d'))->withTrashed()->with('getdoctor')->get();
        return view('allAppointments', compact('myAppointments'));

    }

    public function showPrescriptions($id)
    {
        $getPrescriptionInfo = Prescriptions::where('patient_id', $id)->with('getAppointment')->with('getdoctorInfo')->get();
        return view('prescriptionlist', compact('getPrescriptionInfo'));
    }

    public function showPatienthistory($id)
    {
        $getHistory = Appointment::where('patient_id', $id)->where('appointment_date', '<', date('Y-m-d'))->withTrashed()->get();
        return view('history', compact('getHistory'));
    }


}