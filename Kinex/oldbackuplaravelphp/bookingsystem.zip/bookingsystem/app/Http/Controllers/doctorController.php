<?php

namespace App\Http\Controllers;


use App\Models\User;
use App\Models\Doctor;
use App\Models\Appointment;
use Illuminate\Http\Request;
use App\Models\Prescriptions;
use App\Events\AppointmentCancel;
use App\Events\AppointmentConfirm;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CancelFormRequest;
use App\Http\Requests\PrescriptionRequest;
use App\Http\Requests\doctorprofileRequest;

class doctorController extends Controller
{
    public function showDoctorForm($id)
    {
        $getDoctoruser = User::where('id', $id)->get();
        return view('doctorForm', compact('getDoctoruser'));
    }

    public function add_doctor(doctorprofileRequest $request)
    {
        if (Doctor::where('user_id', Auth::user()->id)->exists()) {
            return redirect('dashborad')->with('message', 'Your profile is already created');
        } else {
            Doctor::create([
                'user_id' => $request['user_id'],
                'age' => $request['age'],
                'educations' => $request['educations'],
                'specialist' => $request['specialist'],
                'experience' => $request['experience'],
            ]);
            return redirect('dashborad')->with('msg', 'Your profile has been created Successfully');
        }
    }
    public function viewDoctorAppointments($id)
    {
        $doctorAppointments = Appointment::where('doctor_loginId', $id)->where('appointment_date', '>=', date('Y-m-d'))->with('getdoctor')->get();
        return view('allAppointments', compact('doctorAppointments'));
    }

    public function confirmAppointment($id)
    {
        $statusConfirm = Appointment::where('id', $id)->update(['status' => 1]);
        $appointment = Appointment::find($id)->first();
        $appointment->status = 1;
        $appointment->save();
        event(new AppointmentConfirm($appointment));
        return redirect()->back();
    }

    public function cancelAppointment($id)
    {
        $getAppointmentinfo = Appointment::find($id);
        return response()->json($getAppointmentinfo);
    }

    public function addCancelreason(CancelFormRequest $request)
    {
        $id = $request['a_id'];
        $cancel = Appointment::where('id', $id)->update(['cancelreason' => $request['cancelreason']]);

        $appointment = Appointment::where('id', $id)->first();
        event(new AppointmentCancel($appointment));
        $appointment->delete();
        return $cancel;
    }

    public function showPrescriptionForm($id)
    {
        $appointmentInfo = Appointment::where('id', $id)->get();
        return view('prescriptionform', compact('appointmentInfo'));

    }

    public function addPrescriptionDetails(PrescriptionRequest $request)
    {
        if (Appointment::Where('id', $request['appointment_id'])->exists()) {
            return redirect()->back()->with('message', 'Prescription Is already added in this Appointment');
        } else {
            Prescriptions::create([
                'appointment_id' => $request['appointment_id'],
                'patient_id' => $request['patient_id'],
                'doctors_id' => $request['doctor_id'],
                'prescription_detail' => $request['prescription'],
            ]);
            return redirect()->back()->with('message', 'Prescription Details added Succesfully');
        }
    }

    public function showPrescriptions($id)
    {
        $getPrescriptionInfo = Prescriptions::where('doctors_id', $id)->with('getAppointment')->get();
        return view('prescriptionlist', compact('getPrescriptionInfo'));
    }

    public function showDoctorhistory($id)
    {
        $getDoctorhistory = Appointment::where('doctor_loginId', $id)->where('appointment_date', '<', date('Y-m-d'))->withTrashed()->get();
        return view('history', compact('getDoctorhistory'));
    }

}