<?php

namespace App\Listeners;

use App\Mail\ConfirmAppointmentMail;
use App\Models\User;
use App\Events\appointmentConfirm;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class sendConfirmAppointmentEmail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\appointmentConfirm  $event
     * @return void
     */
    public function handle(appointmentConfirm $event)
    {
        $getPatientId = $event->user->patient_id;
        $getPatientinfo = User::where('id', $getPatientId)->first();
        Mail::to($getPatientinfo->email)->send(
            new ConfirmAppointmentMail($getPatientinfo)
        );
    }
}