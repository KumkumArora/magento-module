<?php

namespace App\Listeners;

use App\Models\User;
use App\Events\AppointmentCancel;
use App\Mail\CancelAppointmentMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendAppointmentCancelEmail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\AppointmentCancel  $event
     * @return void
     */
    public function handle(AppointmentCancel $event)
    {
        $getPatientId = $event->user->patient_id;
        $getPatient = User::where('id', $getPatientId)->first();
        Mail::to($getPatient->email)->send(
            new CancelAppointmentMail($getPatient, $event->user->appointment_date)
        );

    }
}