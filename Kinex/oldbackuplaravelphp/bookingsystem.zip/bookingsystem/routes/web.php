<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;
use App\Http\Controllers\adminController;
use App\Http\Controllers\doctorController;
use App\Http\Controllers\patientController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/login', function () {
    return view('loginForm');
});

Route::get('/dashborad', function () {
    return view('dashborad');
});

Route::get('/allAppointments', function () {
    return view('allAppointments');
});

Route::post('/userRegister', [userController::class, 'userRegistration']);

Route::post('/userLogin', [userController::class, 'login'])->middleware('verify');
Route::get('/logout', [userController::class, 'logout']);
Route::get('account/verify/{token}', [userController::class, 'verifyAccount'])->name('user.verify');

Route::middleware(['verify.doctor.profile'])->group(function () {
    Route::get('profile/{id}', [doctorController::class, 'showDoctorForm']);
    Route::post('addDoctor', [doctorController::class, 'add_doctor'])->name('create.doctor');
    Route::get('viewDoctorAppointments/{id}', [doctorController::class, 'viewDoctorAppointments']);
    Route::get('confirmAppointment/{id}', [doctorController::class, 'confirmAppointment']);
    Route::get('cancelappointment/{id}', [doctorController::class, 'cancelAppointment'])->name('cancel.appointment');
    Route::post('cancel', [doctorController::class, 'addCancelreason']);
    Route::get('prescription/{id}', [doctorController::class, 'showPrescriptionForm']);
    Route::post('addprescription', [doctorController::class, 'addPrescriptionDetails'])->name('add');
    Route::get('showprescriptions/{id}', [doctorController::class, 'showPrescriptions']);
    Route::get('doctorhistory/{id}', [doctorController::class, 'showDoctorhistory']);

});

Route::middleware(['verify.admin'])->group(function () {
    Route::get('/doctors', [adminController::class, 'viewDoctors']);
    Route::get('/viewAppointments', [adminController::class, 'viewAppointments']);
    Route::get('/showcancelappointments', [adminController::class, 'viewCancelappointments']);
    Route::get('patients', [adminController::class, 'viewPatients']);
    Route::get('activedoctor/{id}', [adminController::class, 'doctorStatusActive']);
    Route::get('inactivedoctor/{id}', [adminController::class, 'doctorStatusInactive']);
    Route::get('showprescriptions', [adminController::class, 'showPrescriptions']);
    Route::get('history', [adminController::class, 'showHistory']);
    Route::post('createDoctor', [adminController::class, 'addDoctor'])->name('add.doctor.by.admin');
});

Route::middleware(['verify.patient'])->group(function () {
    Route::get('/appointment', [patientController::class, 'viewAppointmentForm']);
    Route::post('bookappointment', [patientController::class, 'addAppointment']);
    Route::get('myAppointments/{id}', [patientController::class, 'myAppointments']);
    Route::get('myprescriptions/{id}', [patientController::class, 'showPrescriptions']);
    Route::get('history/{id}', [patientController::class, 'showPatienthistory']);
});