@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border border-primary">
                @if (session()->has('msg'))
                    <div class="alert alert-success">
                        {{ session()->get('msg') }}
                    </div>
                @endif
                @if (session()->has('message'))
                    <div class="alert alert-danger">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <h4 class="font-weight-bold text-center pt-5 mb-5 text-primary"> Welcome!
                    {{ Auth::user()->first_name }} in Your Profile
                </h4>
                @if (Auth::user()->type == 1)
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-users"></i>
                            <h4>Docter List</h4>
                            <div class="link"><a href="{{ url('doctors') }}">View Docter</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-users"></i>
                            <h4>Patient List</h4>
                            <div class="link"><a href="{{ url('patients') }}">View Patients</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="viewAppointments">View Appointments</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="{{ url('showprescriptions') }}">View
                                    Prescriptions</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-plus-large"></i>
                            <h4>Manage Doctors</h4>
                            <div class="link"><a href="profile">add Doctor</a>
                            </div>
                        </li>
                    </ul>
                @endif
                @if (Auth::user()->type == 2)
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="{{ url('viewDoctorAppointments/' . Auth::user()->id) }}">View
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="{{ url('showprescriptions/' . Auth::user()->id) }}">View
                                    Prescriptions</a></div>
                        </li>
                    </ul>
                @endif
                @if (Auth::user()->type == 3)
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Book My Appointments</h4>
                            <div class="link"><a href="{{ url('appointment') }}">Book
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                        </li>
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="{{ url('myAppointments/' . Auth::user()->id) }}">View Your
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="{{ url('myprescriptions/' . Auth::user()->id) }}">View
                                    Prescriptions</a></div>
                        </li>
                    </ul>
                @endif

            </div>
        </div>
    </div>
@endsection
