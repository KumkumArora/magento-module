@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">

                <br>
                <div class="col-8 border border-primary p-5 ">
                    @if (session()->has('message'))
                        <div class="alert alert-success">
                            {{ session()->get('message') }}
                        </div>
                    @endif
                    <h4 class="font-weight-bold text-center text-primary"> Add Prescription Details </h4>
                    <br>
                    <form class="search" method="post" action="{{ route('add') }}">
                        @csrf
                        @if ($appointmentInfo)
                            @foreach ($appointmentInfo as $value)
                                <input type="hidden" name="appointment_id" value="{{ $value->id }}">
                                <input type="hidden" name="patient_id" value="{{ $value->patient_id }}">
                                <input type="hidden" name="doctor_id" value="{{ $value->doctor_loginId }}">
                            @endforeach
                        @endif
                        <div class="form-group">
                            <label for="name">Add Prescription:</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" name="prescription" value="{{ old('prescription') }}"
                                placeholder="Enter Prescription Details" rows="4"></textarea>
                            @if ($errors->has('prescription'))
                                <div class="text-danger">{{ $errors->first('prescription') }}</div>
                            @endif
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
