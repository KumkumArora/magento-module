@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">
                <br>
                <div class="col-8 border border-primary p-5 ">
                    <h4 class="font-weight-bold text-center text-primary">Appointment Form</h4>
                    <br>
                    <form class="search" method="post" action="bookappointment">
                        @csrf
                        <input type="hidden" name="patient_id" value="{{ Auth::user()->id }}">
                        <div class="form-group">
                            <label for="name">Patient Name:</label>
                            <input type="text" class="form-control" placeholder="Enter Name" id="fname"
                                name="fullname" value="{{ old('fullname') }}">
                            @if ($errors->has('fullname'))
                                <div class="text-danger">{{ $errors->first('fullname') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="age"> Patient Age :</label>
                            <input type="text" class="form-control" placeholder="Enter Age" id="email" name="age"
                                value="{{ old('age') }}">
                            @if ($errors->has('age'))
                                <div class="text-danger">{{ $errors->first('age') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio1">
                                            <input type="radio" class="form-check-input" id="gender1" name="gender"
                                                value="male" @if (old('gender') == 'male') checked @endif>Male
                                        </label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio2">
                                            <input type="radio" class="form-check-input" id="gender2" name="gender"
                                                value="female" @if (old('gender') == 'female') checked @endif>Female
                                        </label>
                                    </div>
                                </div>
                            </div>
                            @if ($errors->has('gender'))
                                <div class="text-danger">{{ $errors->first('gender') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="type">disease :</label>
                            <input type="text" class="form-control" placeholder="diseases" id="type" name="diseases"
                                value="{{ old('diseases') }}">
                            @if ($errors->has('diseases'))
                                <div class="text-danger">{{ $errors->first('diseases') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="age">Description :</label>
                            <input type="text" class="form-control" placeholder="Enter Description" id="email"
                                name="description" value="{{ old('description') }}">
                            @if ($errors->has('description'))
                                <div class="text-danger">{{ $errors->first('description') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="inputState">Select Doctor</label>
                            <select id="doctor" class="form-control" name="doctor_id">
                                <option value="">Choose...</option>
                                @if ($getDoctors)
                                    @foreach ($getDoctors as $value)
                                        <option value="{{ $value->getDoctor['id'] }}"
                                            @if (old('doctor_id') == $value->id) selected @endif>
                                            @if ($value->getDoctor['status'] == 1)
                                                {{ $value->first_name }} {{ $value->last_name }}/
                                                {{ $value->getDoctor['specialist'] }}
                                            @endif
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            @if ($errors->has('doctor_id'))
                                <div class="text-danger">{{ $errors->first('doctor_id') }}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="age">Appointment Date:</label>
                            <input type="date" class="form-control" placeholder="Enter Description" id="email"
                                name="appointmentDate" value="{{ old('appointmentDate') }}">
                            @if ($errors->has('appointmentDate'))
                                <div class="text-danger">{{ $errors->first('appointmentDate') }}</div>
                            @endif
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
