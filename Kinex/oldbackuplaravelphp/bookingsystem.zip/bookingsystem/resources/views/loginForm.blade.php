<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background-color: #bcd9f5;
        }

        /* nav */
        .card {
            max-width: 25rem;
            padding: 0;
            border: none;
            border-radius: 0.5rem;
        }

        a.active {
            border-bottom: 2px solid #55c57a;
        }

        .nav-link {
            color: rgb(110, 110, 110);
            font-weight: 500;
        }

        .nav-link:hover {
            color: #55c57a;
        }

        .nav-pills .nav-link.active {
            color: black;
            background-color: white;
            border-radius: 0.5rem 0.5rem 0 0;
            font-weight: 600;
        }

        .tab-content {
            padding-bottom: 1.3rem;
        }

        .form-control {
            background-color: rgb(241, 243, 247);
            border: none;
        }

        /* 3nd card */
        span {
            margin-left: 0.5rem;
            padding: 1px 10px;
            color: white;
            background-color: rgb(143, 143, 143);
            border-radius: 4px;
            font-weight: 600;
        }

        .third {
            padding: 0 1.5rem 0 1.5rem;
        }

        label {
            font-weight: 500;
            color: rgb(104, 104, 104);
        }

        .btn-success {
            float: right;
        }

        .form-control:focus {
            box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.075) inset, 0px 0px 7px rgba(0, 0, 0, 0.2);
        }

        select {
            webkit-appearance: none;
            moz-appearance: none;
            text-indent: 1px;
            text-overflow: "";
        }

        /* 1st card */

        ul {
            list-style: none;
            margin-top: 1rem;
            padding-inline-start: 0;
        }

        .search {
            padding: 0 1rem 0 1rem;
        }

        .ccontent li .wrapp {
            padding: 0.3rem 1rem 0.001rem 1rem;
        }

        .ccontent li .wrapp div {
            font-weight: 600;
        }

        .ccontent li .wrapp p {
            font-weight: 360;
        }

        .ccontent li:hover {
            background-color: rgb(117, 93, 255);
            color: white;
        }

        /* 2nd card */

        .addinfo {
            padding: 0 1rem;
        }
    </style>
</head>

<body>

    @if (session()->has('message'))
        <div class="alert alert-danger">
            {{ session()->get('message') }}
        </div>
    @endif
    <div class="container card shadow d-flex justify-content-center mt-5">
        <!-- nav options -->
        <ul class="nav nav-pills mb-3 shadow-sm justify-content-center " id="pills-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link  active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab"
                    aria-controls="pills-home" aria-selected="true">Login Your Account</a>
            </li>
        </ul>
        <!-- content -->
        <div class="tab-content" id="pills-tabContent p-3">
            {{-- login Form --}}
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">

                <form class="search" method="post" action="userLogin">
                    @csrf
                    <div class="form-group">
                        <label for="email">Email :</label>
                        <input type="email" class="form-control" placeholder="Enter Email" id="email"
                            name="email" value="{{ old('email') }}">
                        @if ($errors->has('email'))
                            <div class="text-danger">{{ $errors->first('email') }}</div>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password :</label>
                        <input type="password" class="form-control" placeholder="Enter password" id="password"
                            name="password" value="{{ old('password') }}">
                        @if ($errors->has('password'))
                            <div class="text-danger">{{ $errors->first('password') }}</div>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
        <a href="/" class="text-center pb-2">Click For Create a new account....</a>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
</body>

</html>
