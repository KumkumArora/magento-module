@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Patients</h4>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Patient Name</th>
                            <th scope="col">Patient Age</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Email</th>
                            <th scope="col">Disease</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($getPatients)
                            @php
                                $i = 1;
                            @endphp
                            @foreach ($getPatients as $value)
                                <tr>
                                    <th scope="row">{{ $i }}</th>
                                    <td>{{ $value->fullname }}</td>
                                    <td>{{ $value->age }}</td>
                                    <td>{{ $value->gender }}</td>
                                    <td>{{ $value->getPatientInfo->email }}</td>
                                    <td>{{ $value->disease }}</td>
                                </tr>
                                @php
                                    $i++;
                                @endphp
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
