@extends('layout.default')

@section('content')
<div class="container-fluid">
    <div class="row">

        {{-- include side bar --}}
        @include('common/sidebar')
        <div class="col-10 border border-primary p-5">
            @if (session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif
            <h4 class="font-weight-bold text-center text-primary">All Appointments</h4>
            <br>
            @if (Auth::user()->type == 1 || Auth::user()->type == 3)
            <table class="table ">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">Patient Name</th>
                        <th scope="col">Patient Age</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Disease</th>
                        <th scope="col">Description</th>
                        <th scope="col">Appointment Date</th>
                        <th scope="col">Doctor Name</th>
                        <th scope="col">Doctor type</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    {{-- all patients appointments (Admin view) --}}
                    @if (Auth::user()->type == 1)
                    @if ($allAppointments)
                    @php
                    $i = 1;
                    @endphp

                    @foreach ($allAppointments as $value)
                    <tr>
                        <th scope="row">{{ $i }}</th>
                        <td>{{ $value->fullname }}</td>
                        <td>{{ $value->age }}</td>
                        <td>{{ $value->gender }}</td>
                        <td>{{ $value->disease }}</td>
                        <td>{{ $value->description }}</td>
                        <td>{{ $value->appointment_date }}</td>
                        <td> Dr.{{ $value->getdoctoruser->first_name }}
                            {{ $value->getdoctoruser->last_name }}</td>
                        @if (empty($value->getdoctor->specialist))
                        <td>Doctor details are unavailable</td>
                        @else
                        <td>{{ $value->getdoctor->specialist }}</td>
                        @endif
                        <td>
                            @if ($value->status == 0)
                            <a id="confirm">
                                <button type="button" class="btn btn-primary">Pending</button>
                            </a>
                            @else
                            <a id="confirm">
                                <button type="button" class="btn btn-success">Confirmed</button>
                            </a>
                            @endif

                        </td>
                    </tr>
                    @php
                    $i++;
                    @endphp
                    @endforeach
                    @endif
                    @endif
                    {{-- logged patient appointments --}}
                    @if (Auth::user()->type == 3)
                    @if ($myAppointments)
                    @php
                    $i = 1;
                    @endphp

                    @foreach ($myAppointments as $value)
                    <tr>
                        <th scope="row">{{ $i }}</th>
                        <td>{{ $value->fullname }}</td>
                        <td>{{ $value->age }}</td>
                        <td>{{ $value->gender }}</td>
                        <td>{{ $value->disease }}</td>
                        <td>{{ $value->description }}</td>
                        <td>{{ $value->appointment_date }}</td>
                        <td> Dr.{{ $value->getdoctoruser->first_name }}
                            {{ $value->getdoctoruser->last_name }}</td>
                        @if (empty($value->getdoctor->specialist))
                        <td>Doctor details are unavailable</td>
                        @else
                        <td>{{ $value->getdoctor->specialist }}</td>
                        @endif
                        <td>
                            @if ($value->deleted_at == null)
                            @if ($value->status == 0)
                            <a id="confirm">
                                <button type="button" class="btn btn-primary btn-sm">Pending</button>
                            </a>
                            @else
                            <a id="confirm">
                                <button type="button" class="btn btn-success btn-sm">Confirmed</button>
                            </a>
                            @endif
                            @else
                            <button type="button" class="btn btn-danger btn-sm">Cancelled</button>
                            @endif
                            <a id="edit">
                                <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-pencil"
                                        data-toggle="tooltip" title="Edit!"></i></button>
                            </a>
                        </td>
                    </tr>
                    @php
                    $i++;
                    @endphp
                    @endforeach
                    @endif
                    @endif
                </tbody>
            </table>
            @endif
            @if (Auth::user()->type == 2)
            @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            <table class="table ">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">Patient Name</th>
                        <th scope="col">Patient Age</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Disease</th>
                        <th scope="col">Description</th>
                        <th scope="col">Appointment Date</th>
                        <th scope="col">Action</th>
                        <th scope="col">Add Prescription</th>
                    </tr>
                </thead>
                <tbody>
                    {{-- all doctors appointments --}}
                    @if ($doctorAppointments)
                    @php
                    $i = 1;
                    @endphp

                    @foreach ($doctorAppointments as $value)
                    <tr>
                        <th scope="row">{{ $i }}</th>
                        <td>{{ $value->fullname }}</td>
                        <td>{{ $value->age }}</td>
                        <td>{{ $value->gender }}</td>
                        <td>{{ $value->disease }}</td>
                        <td>{{ $value->description }}</td>
                        <td>{{ $value->appointment_date }}</td>
                        <td>
                            @if ($value->status == 0)
                            <a id="confirm" href="{{ url('confirmAppointment/' . $value->id) }}">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="tooltip"
                                    title="Pending To confirm!">Pending...</button>
                            </a>
                            @else
                            <a id="confirm">
                                <button type="button" class="btn btn-success btn-sm">Confirmed</button>
                            </a>
                            @endif
                            <button id="cancel" type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                data-target="#myModal" data-attr="{{ route('cancel.appointment', $value->id) }}">
                                Cancel
                            </button>
                        </td>
                        <td> <a href="{{ url('prescription/' . $value->id) }}">
                                <button type="button" class="btn btn-primary btn-sm">Click To
                                    add</button>
                            </a>
                        </td>
                    </tr>
                    @php
                    $i++;
                    @endphp
                    @endforeach
                    @endif
                </tbody>
            </table>
            @endif
            <!-- The Modal -->
            <div class="modal fade" id="myModal">
                <div class="modal-dialog ">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Cancel Appointment</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <form class="cancelForm" id="cancelForm">

                                <input type="hidden" id="a_id" name="a_id">
                                <div class="form-group">
                                    <label for="cancel">Reason:</label>
                                    <input type="text" class="form-control" placeholder="Enter Reason" id="reason"
                                        name="cancelreason" value="{{ old('cancelreason') }}">
                                    @if ($errors->has('cancelreason'))
                                    <div class="text-danger">{{ $errors->first('cancelreason') }}</div>
                                    @endif
                                </div>
                                <button type="submit" class="btn btn-primary" id="addcancelreason">Cancel</button>
                            </form>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$(document).ready(function() {

    $(document).on("click", "#cancel", function() {
        event.preventDefault();
        let href = $(this).attr('data-attr');
        $.ajax({
            url: href,
            success: function(data) {
                $('#a_id').val(data.id);
            }
        });
    });

    $(document).on("click", "#addcancelreason", function(e) {
        e.preventDefault();
        $(this).html('Canceling');
        $.ajax({
            type: "POST",
            url: "{{ url('cancel') }}",
            data: $('#cancelForm').serialize(),
            dataType: 'json',
            success: function(data) {
                $("#cancelForm").trigger('reset')
                $('#myModal').hide()
                setTimeout(() => {
                    location.reload();
                }, 1000)
            },
            error: function(data) {
                console.log(data)
            }

        });
    });

})
</script>
@endsection