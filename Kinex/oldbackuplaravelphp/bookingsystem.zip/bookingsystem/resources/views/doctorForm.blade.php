@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">
                <br>
                @if (Auth::user()->type == 1)
                    <div class="col-8 border border-primary p-5 ">
                        <h4 class="font-weight-bold text-center text-primary"> Create Your Profile </h4>
                        <br>
                        <form class="search" method="post" action="{{ route('add.doctor.by.admin') }}">
                            @csrf
                            <div class="form-group">
                                <label for="name">First Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Name" id="fname"
                                    name="firstname" value="{{ old('firstname') }}">
                                @if ($errors->has('firstname'))
                                    <div class="text-danger">{{ $errors->first('firstname') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="lname">Last Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Last name" id="lname"
                                    name="lastname" value="{{ old('lastname') }}">
                                @if ($errors->has('lastname'))
                                    <div class="text-danger">{{ $errors->first('lastname') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="email">Email :</label>
                                <input type="email" class="form-control" placeholder="Enter Email" id="email"
                                    name="email" value="{{ old('email') }}">
                                @if ($errors->has('email'))
                                    <div class="text-danger">{{ $errors->first('email') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender:</label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-check-inline">
                                            <label class="form-check-label" for="radio1">
                                                <input type="radio" class="form-check-input" id="gender1" name="gender"
                                                    value="male" @if (old('gender') == 'male') checked @endif>Male
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-check-inline">
                                            <label class="form-check-label" for="radio2">
                                                <input type="radio" class="form-check-input" id="gender2" name="gender"
                                                    value="female" @if (old('gender') == 'female') checked @endif>Female
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                @if ($errors->has('gender'))
                                    <div class="text-danger">{{ $errors->first('gender') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="pwd">Password :</label>
                                <input type="password" class="form-control" placeholder="Enter password" id="password"
                                    name="password" value="{{ old('password') }}">
                                @if ($errors->has('password'))
                                    <div class="text-danger">{{ $errors->first('password') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="inpu">Register As a ..</label>
                                <select id="as" class="form-control" name="type">
                                    <option value="">Choose...</option>
                                    <option value="2" @if (old('type') == '2') selected @endif>Doctor
                                    </option>
                                </select>
                                @if ($errors->has('type'))
                                    <div class="text-danger">{{ $errors->first('type') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="age">Age :</label>
                                <input type="text" class="form-control" placeholder="Enter Age" id="age"
                                    name="age" value="{{ old('age') }}">
                                @if ($errors->has('age'))
                                    <div class="text-danger">{{ $errors->first('age') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="edu">Educations:</label>
                                <input type="text" class="form-control" placeholder="Enter Your educations"
                                    id="educations" name="educations" value="{{ old('educations') }}">
                                @if ($errors->has('educations'))
                                    <div class="text-danger">{{ $errors->first('educations') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="type">Specialist :</label>
                                <input type="text" class="form-control" placeholder="Specialist" id="specialist"
                                    name="specialist" value="{{ old('specialist') }}">
                                @if ($errors->has('specialist'))
                                    <div class="text-danger">{{ $errors->first('specialist') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="type">Experience :</label>
                                <input type="text" class="form-control" placeholder="Experience" id="experience"
                                    name="experience" value="{{ old('experience') }}">
                                @if ($errors->has('experience'))
                                    <div class="text-danger">{{ $errors->first('experience') }}</div>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </form>
                    </div>
                @endif
                @if (Auth::user()->type == 2)
                    <div class="col-8 border border-primary p-5 ">
                        <h4 class="font-weight-bold text-center text-primary"> Create Your Profile </h4>
                        <br>
                        <form class="search" method="post" action="{{ route('create.doctor') }}">
                            @csrf
                            <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                            @if ($getDoctoruser)
                                @foreach ($getDoctoruser as $value)
                                    <div class="form-group">
                                        <label for="name">Full name:</label>
                                        <input type="text" class="form-control" placeholder="Enter Name"
                                            id="fname" name="fullname"
                                            value="{{ $value->first_name }} {{ $value->last_name }}" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="gender">Gender:</label>
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" id="gender1"
                                                            name="gender"
                                                            @if ($value->gender == 'male') checked @elseif ($value->gender == 'female') disabled @endif>Male
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" id="gender2"
                                                            name="gender"
                                                            @if ($value->gender == 'female') checked @elseif ($value->gender == 'male') disabled @endif>Female
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                            <div class="form-group">
                                <label for="age">Age :</label>
                                <input type="text" class="form-control" placeholder="Enter Age" id="age"
                                    name="age" value="{{ old('age') }}">
                                @if ($errors->has('age'))
                                    <div class="text-danger">{{ $errors->first('age') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="edu">Educations:</label>
                                <input type="text" class="form-control" placeholder="Enter Your educations"
                                    id="educations" name="educations" value="{{ old('educations') }}">
                                @if ($errors->has('educations'))
                                    <div class="text-danger">{{ $errors->first('educations') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="type">Specialist :</label>
                                <input type="text" class="form-control" placeholder="Specialist" id="specialist"
                                    name="specialist" value="{{ old('specialist') }}">
                                @if ($errors->has('specialist'))
                                    <div class="text-danger">{{ $errors->first('specialist') }}</div>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="type">Experience :</label>
                                <input type="text" class="form-control" placeholder="Experience" id="experience"
                                    name="experience" value="{{ old('experience') }}">
                                @if ($errors->has('experience'))
                                    <div class="text-danger">{{ $errors->first('experience') }}</div>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </form>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
