@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">

            {{-- include side bar --}}
            @include('common/sidebar')
            <div class="col-10 border border-primary p-5">
                <h3 class="font-weight-bold text-center text-danger">Cancelled Appointments By Doctor</h3>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Patient Name</th>
                            <th scope="col">Patient Age</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Disease</th>
                            <th scope="col">Description</th>
                            <th scope="col">Appointment Date</th>
                            <th scope="col">Doctor Name</th>
                            <th scope="col">Doctor type</th>
                            <th scope="col">Doctor Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{-- all patients appointments (Admin view) --}}
                        @if (Auth::user()->type == 1)
                            @if ($onlySoftDeleted)
                                @php
                                    $i = 1;
                                @endphp

                                @foreach ($onlySoftDeleted as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->fullname }}</td>
                                        <td>{{ $value->age }}</td>
                                        <td>{{ $value->gender }}</td>
                                        <td>{{ $value->disease }}</td>
                                        <td>{{ $value->description }}</td>
                                        <td>{{ $value->appointment_date }}</td>

                                        <td> Dr.{{ $value->getdoctoruser->first_name }}
                                            {{ $value->getdoctoruser->last_name }}</td>
                                        @if (empty($value->getdoctor->specialist))
                                            <td>Doctor details are unavailable</td>
                                        @else
                                            <td>{{ $value->getdoctor->specialist }}</td>
                                        @endif
                                        <th class="text-danger">{{ $value->cancelreason }}</th>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif
                        @endif

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
