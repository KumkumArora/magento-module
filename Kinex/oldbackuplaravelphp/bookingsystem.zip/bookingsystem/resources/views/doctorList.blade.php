@extends('layout.default')

{{-- include header here --}}
@include('common/header')
@section('content')
    <div class="container-fluid">
        <div class="row">
            @include('common/sidebar')
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Doctors</h4>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Doctor Name</th>
                            <th scope="col">Doctor Age</th>
                            <th scope="col">Email</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Educations</th>
                            <th scope="col">Specialist Of</th>
                            <th scope="col">Experience</th>
                            <th scope="col">Doctor status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($getDoctors)
                            @php
                                $i = 1;
                            @endphp
                            @foreach ($getDoctors as $value)
                                <tr>
                                    <th scope="row">{{ $i }}</th>
                                    <td>{{ $value->first_name }} {{ $value->last_name }}</td>
                                    <td>{{ $value->getDoctor['age'] }}</td>
                                    <td>{{ $value->email }}</td>
                                    <td>{{ $value->gender }}</td>
                                    <td>{{ $value->getDoctor['educations'] }}</td>
                                    <td>{{ $value->getDoctor['specialist'] }}</td>
                                    <td>{{ $value->getDoctor['experience'] }}</td>
                                    <td>
                                        @if ($value->getDoctor['status'] == 0)
                                            <a href="{{ url('activedoctor/' . $value->getDoctor['id']) }}"> <button
                                                    type="button" class="btn btn-danger btn-sm">Inactive</button>
                                            </a>
                                        @else
                                            <a href="{{ url('inactivedoctor/' . $value->getDoctor['id']) }}">
                                                <button type="button" class="btn btn-primary btn-sm">active</button>
                                            </a>
                                        @endif
                                    </td>
                                    </td>
                                </tr>
                                @php
                                    $i++;
                                @endphp
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
