@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">

            {{-- include side bar --}}
            @include('common/sidebar')
            <div class=" col-10 border border-primary p-5 ">
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session()->get('message') }}
                    </div>
                @endif
                <h4 class="font-weight-bold text-center text-primary">Closed Appointments</h4>
                <br>
                @if (Auth::user()->type == 1 || Auth::user()->type == 3)
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Doctor Name</th>
                                <th scope="col">Doctor type</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($getHistory)
                                @php
                                    $i = 1;
                                @endphp
                                @foreach ($getHistory as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->fullname }}</td>
                                        <td>{{ $value->age }}</td>
                                        <td>{{ $value->gender }}</td>
                                        <td>{{ $value->disease }}</td>
                                        <td>{{ $value->description }}</td>
                                        <td>{{ $value->appointment_date }}</td>
                                        <td>Dr.{{ $value->getdoctoruser->first_name }}
                                            {{ $value->getdoctoruser->last_name }}</td>
                                        <td>{{ $value->getdoctor->specialist }}</td>
                                        <td>
                                            @if ($value->deleted_at == null)
                                                <a id="closed">
                                                    <button type="button" class="btn btn-success">Closed</button>
                                                </a>
                                            @else
                                                <a id="Cancel">
                                                    <button type="button" class="btn btn-danger">Cancelled</button>
                                                </a>
                                            @endif
                                        </td>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif

                        </tbody>
                    </table>
                @endif
                @if (Auth::user()->type == 2)
                    @if (session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{-- all doctors appointments --}}
                            @if ($getDoctorhistory)
                                @php
                                    $i = 1;
                                @endphp

                                @foreach ($getDoctorhistory as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->fullname }}</td>
                                        <td>{{ $value->age }}</td>
                                        <td>{{ $value->gender }}</td>
                                        <td>{{ $value->disease }}</td>
                                        <td>{{ $value->description }}</td>
                                        <td>{{ $value->appointment_date }}</td>
                                        <td>
                                            @if ($value->deleted_at == null)
                                                <a id="closed">
                                                    <button type="button" class="btn btn-success">Closed</button>
                                                </a>
                                            @else
                                                <a id="Cancel">
                                                    <button type="button" class="btn btn-danger">Cancelled</button>
                                                </a>
                                            @endif
                                        </td>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>
    </div>
@endsection
