@extends('layout.default')

@section('content')
    <div class="container-fluid">
        <div class="row">
            {{-- include Side Bar  --}}
            @include('common/sidebar')
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Prescriptions</h4>
                <br>
                @if (Auth::user()->type == 2)
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($getPrescriptionInfo)
                                @php
                                    $i = 1;
                                @endphp
                                @foreach ($getPrescriptionInfo as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->getAppointment->fullname }}</td>
                                        <td>{{ $value->getAppointment->age }}</td>
                                        <td>{{ $value->getAppointment->gender }}</td>
                                        <td>{{ $value->getAppointment->disease }}</td>
                                        <td>{{ $value->getAppointment->appointment_date }}</td>
                                        <td>{{ $value->prescription_detail }}</td>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                @elseif (Auth::user()->type == 3)
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Specialist</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($getPrescriptionInfo)
                                @php
                                    $i = 1;
                                @endphp
                                @foreach ($getPrescriptionInfo as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->getAppointment->fullname }}</td>
                                        <td>{{ $value->getAppointment->age }}</td>
                                        <td>{{ $value->getAppointment->gender }}</td>
                                        <td>{{ $value->getAppointment->disease }}</td>
                                        <td>{{ $value->getAppointment->appointment_date }}</td>
                                        <td>Dr.{{ $value->getdoctorname->first_name }}
                                            {{ $value->getdoctorname->last_name }} /
                                            {{ $value->getdoctorInfo->specialist }}
                                        </td>
                                        <td>{{ $value->prescription_detail }}</td>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                @elseif(Auth::user()->type == 1)
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Specialist Details</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($getPrescriptions)
                                @php
                                    $i = 1;
                                @endphp
                                @foreach ($getPrescriptions as $value)
                                    <tr>
                                        <th scope="row">{{ $i }}</th>
                                        <td>{{ $value->getAppointment->fullname }}</td>
                                        <td>{{ $value->getAppointment->age }}</td>
                                        <td>{{ $value->getAppointment->gender }}</td>
                                        <td>{{ $value->getAppointment->disease }}</td>
                                        <td>{{ $value->getAppointment->appointment_date }}</td>
                                        <td>Dr.{{ $value->getdoctorname->first_name }}
                                            {{ $value->getdoctorname->last_name }}/
                                            {{ $value->getdoctorInfo->specialist }}
                                        </td>
                                        <td>{{ $value->prescription_detail }}</td>
                                    </tr>
                                    @php
                                        $i++;
                                    @endphp
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>
@endsection
