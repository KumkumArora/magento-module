<br>
<br>
Dear {{ $patient->first_name }} {{ $patient->last_name }}
<br>
<br>
<br>
Your appointment of date:{{ $date }} is cancelled Due to some issues.So please try to book your appointment for another
day..
<br>
<br>
Sorry For this inconvenience.
<br>
<br>
<br>
Thanks
<br>
ABC Hospital