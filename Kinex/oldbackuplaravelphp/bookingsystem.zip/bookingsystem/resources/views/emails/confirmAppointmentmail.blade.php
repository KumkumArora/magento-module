Hello {{ $patient->first_name }} {{ $patient->last_name }}
<br>
Your Appointment has been confirmed. <a href="{{ url('login') }}">
    Click here View Appointment</a>