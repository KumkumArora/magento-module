<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Doctors</h4>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Doctor Name</th>
                            <th scope="col">Doctor Age</th>
                            <th scope="col">Email</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Educations</th>
                            <th scope="col">Specialist Of</th>
                            <th scope="col">Experience</th>
                            <th scope="col">Doctor status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($getDoctors): ?>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $getDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($i); ?></th>
                                    <td><?php echo e($value->first_name); ?> <?php echo e($value->last_name); ?></td>
                                    <td><?php echo e($value->getDoctor['age']); ?></td>
                                    <td><?php echo e($value->email); ?></td>
                                    <td><?php echo e($value->gender); ?></td>
                                    <td><?php echo e($value->getDoctor['educations']); ?></td>
                                    <td><?php echo e($value->getDoctor['specialist']); ?></td>
                                    <td><?php echo e($value->getDoctor['experience']); ?></td>
                                    <td>
                                        <?php if($value->getDoctor['status'] == 0): ?>
                                            <a href="<?php echo e(url('activedoctor/' . $value->getDoctor['id'])); ?>"> <button
                                                    type="button" class="btn btn-danger btn-sm">Inactive</button>
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('inactivedoctor/' . $value->getDoctor['id'])); ?>">
                                                <button type="button" class="btn btn-primary btn-sm">active</button>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    </td>
                                </tr>
                                <?php
                                    $i++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/doctorList.blade.php ENDPATH**/ ?>