<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">

            
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary p-5">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <h4 class="font-weight-bold text-center text-primary">All Appointments</h4>
                <br>
                <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Doctor Name</th>
                                <th scope="col">Doctor type</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php if(Auth::user()->type == 1): ?>
                                <?php if($allAppointments): ?>
                                    <?php
                                        $i = 1;
                                    ?>

                                    <?php $__currentLoopData = $allAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i); ?></th>
                                            <td><?php echo e($value->fullname); ?></td>
                                            <td><?php echo e($value->age); ?></td>
                                            <td><?php echo e($value->gender); ?></td>
                                            <td><?php echo e($value->disease); ?></td>
                                            <td><?php echo e($value->description); ?></td>
                                            <td><?php echo e($value->appointment_date); ?></td>
                                            <td> Dr.<?php echo e($value->getdoctoruser->first_name); ?>

                                                <?php echo e($value->getdoctoruser->last_name); ?></td>
                                            <?php if(empty($value->getdoctor->specialist)): ?>
                                                <td>Doctor details are unavailable</td>
                                            <?php else: ?>
                                                <td><?php echo e($value->getdoctor->specialist); ?></td>
                                            <?php endif; ?>
                                            <td>
                                                <?php if($value->status == 0): ?>
                                                    <a id="confirm">
                                                        <button type="button" class="btn btn-primary">Pending</button>
                                                    </a>
                                                <?php else: ?>
                                                    <a id="confirm">
                                                        <button type="button" class="btn btn-success">Confirmed</button>
                                                    </a>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php if(Auth::user()->type == 3): ?>
                                <?php if($myAppointments): ?>
                                    <?php
                                        $i = 1;
                                    ?>

                                    <?php $__currentLoopData = $myAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i); ?></th>
                                            <td><?php echo e($value->fullname); ?></td>
                                            <td><?php echo e($value->age); ?></td>
                                            <td><?php echo e($value->gender); ?></td>
                                            <td><?php echo e($value->disease); ?></td>
                                            <td><?php echo e($value->description); ?></td>
                                            <td><?php echo e($value->appointment_date); ?></td>
                                            <td> Dr.<?php echo e($value->getdoctoruser->first_name); ?>

                                                <?php echo e($value->getdoctoruser->last_name); ?></td>
                                            <?php if(empty($value->getdoctor->specialist)): ?>
                                                <td>Doctor details are unavailable</td>
                                            <?php else: ?>
                                                <td><?php echo e($value->getdoctor->specialist); ?></td>
                                            <?php endif; ?>
                                            <td>
                                                <?php if($value->deleted_at == null): ?>
                                                    <?php if($value->status == 0): ?>
                                                        <a id="confirm">
                                                            <button type="button"
                                                                class="btn btn-primary btn-sm">Pending</button>
                                                        </a>
                                                    <?php else: ?>
                                                        <a id="confirm">
                                                            <button type="button"
                                                                class="btn btn-success btn-sm">Confirmed</button>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-danger btn-sm">Cancelled</button>
                                                <?php endif; ?>
                                                <a id="edit">
                                                    <button type="button" class="btn btn-primary btn-sm"><i
                                                            class="fa fa-pencil" data-toggle="tooltip"
                                                            title="Edit!"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Action</th>
                                <th scope="col">Add Prescription</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php if($doctorAppointments): ?>
                                <?php
                                    $i = 1;
                                ?>

                                <?php $__currentLoopData = $doctorAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->fullname); ?></td>
                                        <td><?php echo e($value->age); ?></td>
                                        <td><?php echo e($value->gender); ?></td>
                                        <td><?php echo e($value->disease); ?></td>
                                        <td><?php echo e($value->description); ?></td>
                                        <td><?php echo e($value->appointment_date); ?></td>
                                        <td>
                                            <?php if($value->status == 0): ?>
                                                <a id="confirm" href="<?php echo e(url('confirmAppointment/' . $value->id)); ?>">
                                                    <button type="button"
                                                        class="btn btn-primary btn-sm"data-toggle="tooltip"
                                                        title="Pending To confirm!">Pending...</button>
                                                </a>
                                            <?php else: ?>
                                                <a id="confirm">
                                                    <button type="button" class="btn btn-success btn-sm">Confirmed</button>
                                                </a>
                                            <?php endif; ?>
                                            <button id="cancel" type="button" class="btn btn-danger btn-sm"
                                                data-toggle="modal" data-target="#myModal"
                                                data-attr="<?php echo e(route('cancel.appointment', $value->id)); ?>">
                                                Cancel
                                            </button>
                                        </td>
                                        <td> <a href="<?php echo e(url('prescription/' . $value->id)); ?>">
                                                <button type="button" class="btn btn-primary btn-sm">Click To
                                                    add</button>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <!-- The Modal -->
                <div class="modal fade" id="myModal">
                    <div class="modal-dialog ">
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Cancel Appointment</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                                <form class="cancelForm" id="cancelForm">

                                    <input type="hidden" id="a_id" name="a_id">
                                    <div class="form-group">
                                        <label for="cancel">Reason:</label>
                                        <input type="text" class="form-control" placeholder="Enter Reason" id="reason"
                                            name="cancelreason" value="<?php echo e(old('cancelreason')); ?>">
                                        <?php if($errors->has('cancelreason')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('cancelreason')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <button type="submit" class="btn btn-primary" id="addcancelreason">Cancel</button>
                                </form>
                            </div>
                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function() {

            $(document).on("click", "#cancel", function() {
                event.preventDefault();
                let href = $(this).attr('data-attr');
                $.ajax({
                    url: href,
                    success: function(data) {
                        $('#a_id').val(data.id);
                    }
                });
            });

            $(document).on("click", "#addcancelreason", function(e) {
                e.preventDefault();
                $(this).html('Canceling');
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('cancel')); ?>",
                    data: $('#cancelForm').serialize(),
                    dataType: 'json',
                    success: function(data) {
                        $("#cancelForm").trigger('reset')
                        $('#myModal').hide()
                        setTimeout(() => {
                            location.reload();
                        }, 1000)
                    },
                    error: function(data) {
                        console.log(data)
                    }

                });
            });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/allAppointments.blade.php ENDPATH**/ ?>