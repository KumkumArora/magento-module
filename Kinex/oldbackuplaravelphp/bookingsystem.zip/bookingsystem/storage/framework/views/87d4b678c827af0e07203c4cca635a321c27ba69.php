<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">

            
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class=" col-10 border border-primary p-5 ">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <h4 class="font-weight-bold text-center text-primary">Closed Appointments</h4>
                <br>
                <?php if(Auth::user()->type == 1 || Auth::user()->type == 3): ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Doctor Name</th>
                                <th scope="col">Doctor type</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($getHistory): ?>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $getHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->fullname); ?></td>
                                        <td><?php echo e($value->age); ?></td>
                                        <td><?php echo e($value->gender); ?></td>
                                        <td><?php echo e($value->disease); ?></td>
                                        <td><?php echo e($value->description); ?></td>
                                        <td><?php echo e($value->appointment_date); ?></td>
                                        <td>Dr.<?php echo e($value->getdoctoruser->first_name); ?>

                                            <?php echo e($value->getdoctoruser->last_name); ?></td>
                                        <td><?php echo e($value->getdoctor->specialist); ?></td>
                                        <td>
                                            <?php if($value->deleted_at == null): ?>
                                                <a id="closed">
                                                    <button type="button" class="btn btn-success">Closed</button>
                                                </a>
                                            <?php else: ?>
                                                <a id="Cancel">
                                                    <button type="button" class="btn btn-danger">Cancelled</button>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>
                    </table>
                <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Description</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php if($getDoctorhistory): ?>
                                <?php
                                    $i = 1;
                                ?>

                                <?php $__currentLoopData = $getDoctorhistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->fullname); ?></td>
                                        <td><?php echo e($value->age); ?></td>
                                        <td><?php echo e($value->gender); ?></td>
                                        <td><?php echo e($value->disease); ?></td>
                                        <td><?php echo e($value->description); ?></td>
                                        <td><?php echo e($value->appointment_date); ?></td>
                                        <td>
                                            <?php if($value->deleted_at == null): ?>
                                                <a id="closed">
                                                    <button type="button" class="btn btn-success">Closed</button>
                                                </a>
                                            <?php else: ?>
                                                <a id="Cancel">
                                                    <button type="button" class="btn btn-danger">Cancelled</button>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/history.blade.php ENDPATH**/ ?>