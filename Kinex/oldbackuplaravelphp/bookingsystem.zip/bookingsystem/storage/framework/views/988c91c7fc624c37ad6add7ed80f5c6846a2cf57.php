<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">
                <br>
                <div class="col-8 border border-primary p-5 ">
                    <h4 class="font-weight-bold text-center text-primary">Appointment Form</h4>
                    <br>
                    <form class="search" method="post" action="bookappointment">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="patient_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="form-group">
                            <label for="name">Patient Name:</label>
                            <input type="text" class="form-control" placeholder="Enter Name" id="fname"
                                name="fullname" value="<?php echo e(old('fullname')); ?>">
                            <?php if($errors->has('fullname')): ?>
                                <div class="text-danger"><?php echo e($errors->first('fullname')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="age"> Patient Age :</label>
                            <input type="text" class="form-control" placeholder="Enter Age" id="email" name="age"
                                value="<?php echo e(old('age')); ?>">
                            <?php if($errors->has('age')): ?>
                                <div class="text-danger"><?php echo e($errors->first('age')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio1">
                                            <input type="radio" class="form-check-input" id="gender1" name="gender"
                                                value="male" <?php if(old('gender') == 'male'): ?> checked <?php endif; ?>>Male
                                        </label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="radio2">
                                            <input type="radio" class="form-check-input" id="gender2" name="gender"
                                                value="female" <?php if(old('gender') == 'female'): ?> checked <?php endif; ?>>Female
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <?php if($errors->has('gender')): ?>
                                <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="type">disease :</label>
                            <input type="text" class="form-control" placeholder="diseases" id="type" name="diseases"
                                value="<?php echo e(old('diseases')); ?>">
                            <?php if($errors->has('diseases')): ?>
                                <div class="text-danger"><?php echo e($errors->first('diseases')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="age">Description :</label>
                            <input type="text" class="form-control" placeholder="Enter Description" id="email"
                                name="description" value="<?php echo e(old('description')); ?>">
                            <?php if($errors->has('description')): ?>
                                <div class="text-danger"><?php echo e($errors->first('description')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="inputState">Select Doctor</label>
                            <select id="doctor" class="form-control" name="doctor_id">
                                <option value="">Choose...</option>
                                <?php if($getDoctors): ?>
                                    <?php $__currentLoopData = $getDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->getDoctor['id']); ?>"
                                            <?php if(old('doctor_id') == $value->id): ?> selected <?php endif; ?>>
                                            <?php if($value->getDoctor['status'] == 1): ?>
                                                <?php echo e($value->first_name); ?> <?php echo e($value->last_name); ?>/
                                                <?php echo e($value->getDoctor['specialist']); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <?php if($errors->has('doctor_id')): ?>
                                <div class="text-danger"><?php echo e($errors->first('doctor_id')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="age">Appointment Date:</label>
                            <input type="date" class="form-control" placeholder="Enter Description" id="email"
                                name="appointmentDate" value="<?php echo e(old('appointmentDate')); ?>">
                            <?php if($errors->has('appointmentDate')): ?>
                                <div class="text-danger"><?php echo e($errors->first('appointmentDate')); ?></div>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/appointmentForm.blade.php ENDPATH**/ ?>