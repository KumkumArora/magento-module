<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">

                <br>
                <div class="col-8 border border-primary p-5 ">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                    <h4 class="font-weight-bold text-center text-primary"> Add Prescription Details </h4>
                    <br>
                    <form class="search" method="post" action="<?php echo e(route('add')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($appointmentInfo): ?>
                            <?php $__currentLoopData = $appointmentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="appointment_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="patient_id" value="<?php echo e($value->patient_id); ?>">
                                <input type="hidden" name="doctor_id" value="<?php echo e($value->doctor_loginId); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="name">Add Prescription:</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" name="prescription" value="<?php echo e(old('prescription')); ?>"
                                placeholder="Enter Prescription Details" rows="4"></textarea>
                            <?php if($errors->has('prescription')): ?>
                                <div class="text-danger"><?php echo e($errors->first('prescription')); ?></div>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/prescriptionform.blade.php ENDPATH**/ ?>