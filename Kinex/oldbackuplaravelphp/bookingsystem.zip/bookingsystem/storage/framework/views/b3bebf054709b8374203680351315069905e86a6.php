<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">

            
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary p-5">
                <h3 class="font-weight-bold text-center text-danger">Cancelled Appointments By Doctor</h3>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Patient Name</th>
                            <th scope="col">Patient Age</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Disease</th>
                            <th scope="col">Description</th>
                            <th scope="col">Appointment Date</th>
                            <th scope="col">Doctor Name</th>
                            <th scope="col">Doctor type</th>
                            <th scope="col">Doctor Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php if(Auth::user()->type == 1): ?>
                            <?php if($onlySoftDeleted): ?>
                                <?php
                                    $i = 1;
                                ?>

                                <?php $__currentLoopData = $onlySoftDeleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->fullname); ?></td>
                                        <td><?php echo e($value->age); ?></td>
                                        <td><?php echo e($value->gender); ?></td>
                                        <td><?php echo e($value->disease); ?></td>
                                        <td><?php echo e($value->description); ?></td>
                                        <td><?php echo e($value->appointment_date); ?></td>

                                        <td> Dr.<?php echo e($value->getdoctoruser->first_name); ?>

                                            <?php echo e($value->getdoctoruser->last_name); ?></td>
                                        <?php if(empty($value->getdoctor->specialist)): ?>
                                            <td>Doctor details are unavailable</td>
                                        <?php else: ?>
                                            <td><?php echo e($value->getdoctor->specialist); ?></td>
                                        <?php endif; ?>
                                        <th class="text-danger"><?php echo e($value->cancelreason); ?></th>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/cancelledappointments.blade.php ENDPATH**/ ?>