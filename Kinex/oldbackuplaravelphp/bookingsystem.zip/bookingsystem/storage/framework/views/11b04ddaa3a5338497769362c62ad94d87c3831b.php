Hello <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?>

<br>
Your Appointment has been confirmed. <a href="<?php echo e(url('login')); ?>">
    Click here View Appointment</a><?php /**PATH /var/www/html/bookingsystem/resources/views/emails/confirmAppointmentmail.blade.php ENDPATH**/ ?>