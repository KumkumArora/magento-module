<br>
<br>
Dear <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?>

<br>
<br>
<br>
Your appointment of date:<?php echo e($date); ?> is cancelled Due to some issues.So please try to book your appointment for another
day..
<br>
<br>
Sorry For this inconvenience.
<br>
<br>
<br>
Thanks
<br>
ABC Hospital<?php /**PATH /var/www/html/bookingsystem/resources/views/emails/cancelappointmentmail.blade.php ENDPATH**/ ?>