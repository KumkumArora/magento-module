<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary">
                <?php if(session()->has('msg')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('msg')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <h4 class="font-weight-bold text-center pt-5 mb-5 text-primary"> Welcome!
                    <?php echo e(Auth::user()->first_name); ?> in Your Profile
                </h4>
                <?php if(Auth::user()->type == 1): ?>
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-users"></i>
                            <h4>Docter List</h4>
                            <div class="link"><a href="<?php echo e(url('doctors')); ?>">View Docter</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-users"></i>
                            <h4>Patient List</h4>
                            <div class="link"><a href="<?php echo e(url('patients')); ?>">View Patients</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="viewAppointments">View Appointments</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="<?php echo e(url('showprescriptions')); ?>">View
                                    Prescriptions</a></div>
                        </li>
                        <li>
                            <i class="fa-solid fa-plus-large"></i>
                            <h4>Manage Doctors</h4>
                            <div class="link"><a href="profile">add Doctor</a>
                            </div>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="<?php echo e(url('viewDoctorAppointments/' . Auth::user()->id)); ?>">View
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="<?php echo e(url('showprescriptions/' . Auth::user()->id)); ?>">View
                                    Prescriptions</a></div>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(Auth::user()->type == 3): ?>
                    <ul class="listing">
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Book My Appointments</h4>
                            <div class="link"><a href="<?php echo e(url('appointment')); ?>">Book
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                        </li>
                        <li>
                            <i class="fa-solid fa-paperclip"></i>
                            <h4>Appointment Deatils</h4>
                            <div class="link"><a href="<?php echo e(url('myAppointments/' . Auth::user()->id)); ?>">View Your
                                    Appointments</a>
                            </div>
                        </li>
                        <li>
                            <i class="fa-solid fa-list"></i>
                            <h4>Prescription List</h4>
                            <div class="link"><a href="<?php echo e(url('myprescriptions/' . Auth::user()->id)); ?>">View
                                    Prescriptions</a></div>
                        </li>
                    </ul>
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/dashborad.blade.php ENDPATH**/ ?>