<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border justify-content-center border-primary p-5 d-sm-flex">
                <br>
                <?php if(Auth::user()->type == 1): ?>
                    <div class="col-8 border border-primary p-5 ">
                        <h4 class="font-weight-bold text-center text-primary"> Create Your Profile </h4>
                        <br>
                        <form class="search" method="post" action="<?php echo e(route('add.doctor.by.admin')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">First Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Name" id="fname"
                                    name="firstname" value="<?php echo e(old('firstname')); ?>">
                                <?php if($errors->has('firstname')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('firstname')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="lname">Last Name:</label>
                                <input type="text" class="form-control" placeholder="Enter Last name" id="lname"
                                    name="lastname" value="<?php echo e(old('lastname')); ?>">
                                <?php if($errors->has('lastname')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('lastname')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="email">Email :</label>
                                <input type="email" class="form-control" placeholder="Enter Email" id="email"
                                    name="email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender:</label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-check-inline">
                                            <label class="form-check-label" for="radio1">
                                                <input type="radio" class="form-check-input" id="gender1" name="gender"
                                                    value="male" <?php if(old('gender') == 'male'): ?> checked <?php endif; ?>>Male
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-check-inline">
                                            <label class="form-check-label" for="radio2">
                                                <input type="radio" class="form-check-input" id="gender2" name="gender"
                                                    value="female" <?php if(old('gender') == 'female'): ?> checked <?php endif; ?>>Female
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <?php if($errors->has('gender')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="pwd">Password :</label>
                                <input type="password" class="form-control" placeholder="Enter password" id="password"
                                    name="password" value="<?php echo e(old('password')); ?>">
                                <?php if($errors->has('password')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="inpu">Register As a ..</label>
                                <select id="as" class="form-control" name="type">
                                    <option value="">Choose...</option>
                                    <option value="2" <?php if(old('type') == '2'): ?> selected <?php endif; ?>>Doctor
                                    </option>
                                </select>
                                <?php if($errors->has('type')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('type')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="age">Age :</label>
                                <input type="text" class="form-control" placeholder="Enter Age" id="age"
                                    name="age" value="<?php echo e(old('age')); ?>">
                                <?php if($errors->has('age')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('age')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="edu">Educations:</label>
                                <input type="text" class="form-control" placeholder="Enter Your educations"
                                    id="educations" name="educations" value="<?php echo e(old('educations')); ?>">
                                <?php if($errors->has('educations')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('educations')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="type">Specialist :</label>
                                <input type="text" class="form-control" placeholder="Specialist" id="specialist"
                                    name="specialist" value="<?php echo e(old('specialist')); ?>">
                                <?php if($errors->has('specialist')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('specialist')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="type">Experience :</label>
                                <input type="text" class="form-control" placeholder="Experience" id="experience"
                                    name="experience" value="<?php echo e(old('experience')); ?>">
                                <?php if($errors->has('experience')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('experience')); ?></div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </form>
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->type == 2): ?>
                    <div class="col-8 border border-primary p-5 ">
                        <h4 class="font-weight-bold text-center text-primary"> Create Your Profile </h4>
                        <br>
                        <form class="search" method="post" action="<?php echo e(route('create.doctor')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <?php if($getDoctoruser): ?>
                                <?php $__currentLoopData = $getDoctoruser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <label for="name">Full name:</label>
                                        <input type="text" class="form-control" placeholder="Enter Name"
                                            id="fname" name="fullname"
                                            value="<?php echo e($value->first_name); ?> <?php echo e($value->last_name); ?>" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="gender">Gender:</label>
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" id="gender1"
                                                            name="gender"
                                                            <?php if($value->gender == 'male'): ?> checked <?php elseif($value->gender == 'female'): ?> disabled <?php endif; ?>>Male
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" id="gender2"
                                                            name="gender"
                                                            <?php if($value->gender == 'female'): ?> checked <?php elseif($value->gender == 'male'): ?> disabled <?php endif; ?>>Female
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <div class="form-group">
                                <label for="age">Age :</label>
                                <input type="text" class="form-control" placeholder="Enter Age" id="age"
                                    name="age" value="<?php echo e(old('age')); ?>">
                                <?php if($errors->has('age')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('age')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="edu">Educations:</label>
                                <input type="text" class="form-control" placeholder="Enter Your educations"
                                    id="educations" name="educations" value="<?php echo e(old('educations')); ?>">
                                <?php if($errors->has('educations')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('educations')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="type">Specialist :</label>
                                <input type="text" class="form-control" placeholder="Specialist" id="specialist"
                                    name="specialist" value="<?php echo e(old('specialist')); ?>">
                                <?php if($errors->has('specialist')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('specialist')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="type">Experience :</label>
                                <input type="text" class="form-control" placeholder="Experience" id="experience"
                                    name="experience" value="<?php echo e(old('experience')); ?>">
                                <?php if($errors->has('experience')): ?>
                                    <div class="text-danger"><?php echo e($errors->first('experience')); ?></div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/doctorForm.blade.php ENDPATH**/ ?>