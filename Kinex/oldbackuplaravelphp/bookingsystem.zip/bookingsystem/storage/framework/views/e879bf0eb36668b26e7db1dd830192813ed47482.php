<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="container card shadow d-flex justify-content-center mt-5">
        <!-- nav s -->
        <ul class="nav nav-pills mb-3 shadow-sm justify-content-center h4" id="pills-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link  active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab"
                    aria-controls="pills-home" aria-selected="true">Register Your Account Here</a>
            </li>
        </ul>
        <!-- content -->
        <div class="tab-content" id="pills-tabContent p-3">
            
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">

                <form class="search" method="post" action="userRegister">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">First Name:</label>
                        <input type="text" class="form-control" placeholder="Enter Name" id="fname" name="firstname"
                            value="<?php echo e(old('firstname')); ?>">
                        <?php if($errors->has('firstname')): ?>
                            <div class="text-danger"><?php echo e($errors->first('firstname')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="lname">Last Name:</label>
                        <input type="text" class="form-control" placeholder="Enter Last name" id="lname"
                            name="lastname" value="<?php echo e(old('lastname')); ?>">
                        <?php if($errors->has('lastname')): ?>
                            <div class="text-danger"><?php echo e($errors->first('lastname')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email :</label>
                        <input type="email" class="form-control" placeholder="Enter Email" id="email" name="email"
                            value="<?php echo e(old('email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio1">
                                        <input type="radio" class="form-check-input" id="gender1" name="gender"
                                            value="male" <?php if(old('gender') == 'male'): ?> checked <?php endif; ?>>Male
                                    </label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="radio2">
                                        <input type="radio" class="form-check-input" id="gender2" name="gender"
                                            value="female" <?php if(old('gender') == 'female'): ?> checked <?php endif; ?>>Female
                                    </label>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('gender')): ?>
                            <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password :</label>
                        <input type="password" class="form-control" placeholder="Enter password" id="password"
                            name="password" value="<?php echo e(old('password')); ?>">
                        <?php if($errors->has('password')): ?>
                            <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Confirm Password :</label>
                        <input type="password" class="form-control" placeholder="Confirm Password" id="password"
                            name="cpassword" value="<?php echo e(old('cpassword')); ?>">
                        <?php if($errors->has('cpassword')): ?>
                            <div class="text-danger"><?php echo e($errors->first('cpassword')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="inpu">Register As a ..</label>
                        <select id="as" class="form-control" name="type">
                            <option value="">Choose...</option>
                            <option value="2" <?php if(old('type') == '2'): ?> selected <?php endif; ?>>Doctor
                            </option>
                            <option value="3" <?php if(old('type') == '3'): ?> selected <?php endif; ?>>Patient</option>
                        </select>
                        <?php if($errors->has('type')): ?>
                            <div class="text-danger"><?php echo e($errors->first('type')); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
        <a href="login" class="text-center pb-2">Already have an Account. Login Here..</a>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/index.blade.php ENDPATH**/ ?>