<header>
    <nav class="navbar navbar-expand-lg navbar-light " style="background-color: #1e90e2;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
            aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 font-weight-bold h3">
                <li class="nav-item">
                    <a class="nav-link" href="#">ABC XYZ HOSPITAL<span class="sr-only">(current)</span></a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Search</button>
            </form>
            <a href="<?php echo e(url('logout')); ?>" class="text-dark pl-3 h3 pt-2"><i class="fa-solid fa-power-off"></i></a>
        </div>
    </nav>
</header>
<?php /**PATH /var/www/html/bookingsystem/resources/views/common/header.blade.php ENDPATH**/ ?>