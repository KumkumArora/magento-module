<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Prescriptions</h4>
                <br>
                <?php if(Auth::user()->type == 2): ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($getPrescriptionInfo): ?>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $getPrescriptionInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->getAppointment->fullname); ?></td>
                                        <td><?php echo e($value->getAppointment->age); ?></td>
                                        <td><?php echo e($value->getAppointment->gender); ?></td>
                                        <td><?php echo e($value->getAppointment->disease); ?></td>
                                        <td><?php echo e($value->getAppointment->appointment_date); ?></td>
                                        <td><?php echo e($value->prescription_detail); ?></td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php elseif(Auth::user()->type == 3): ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Specialist</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($getPrescriptionInfo): ?>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $getPrescriptionInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->getAppointment->fullname); ?></td>
                                        <td><?php echo e($value->getAppointment->age); ?></td>
                                        <td><?php echo e($value->getAppointment->gender); ?></td>
                                        <td><?php echo e($value->getAppointment->disease); ?></td>
                                        <td><?php echo e($value->getAppointment->appointment_date); ?></td>
                                        <td>Dr.<?php echo e($value->getdoctorname->first_name); ?>

                                            <?php echo e($value->getdoctorname->last_name); ?> /
                                            <?php echo e($value->getdoctorInfo->specialist); ?>

                                        </td>
                                        <td><?php echo e($value->prescription_detail); ?></td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php elseif(Auth::user()->type == 1): ?>
                    <table class="table ">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Patient Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Appointment Date</th>
                                <th scope="col">Specialist Details</th>
                                <th scope="col">Prescription Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($getPrescriptions): ?>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $getPrescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->getAppointment->fullname); ?></td>
                                        <td><?php echo e($value->getAppointment->age); ?></td>
                                        <td><?php echo e($value->getAppointment->gender); ?></td>
                                        <td><?php echo e($value->getAppointment->disease); ?></td>
                                        <td><?php echo e($value->getAppointment->appointment_date); ?></td>
                                        <td>Dr.<?php echo e($value->getdoctorname->first_name); ?>

                                            <?php echo e($value->getdoctorname->last_name); ?>/
                                            <?php echo e($value->getdoctorInfo->specialist); ?>

                                        </td>
                                        <td><?php echo e($value->prescription_detail); ?></td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/prescriptionlist.blade.php ENDPATH**/ ?>