<div class="col-2 bg-light border border-primary">
    <div class="card mt-5 " style="width: 17rem;">
        <div class="card-header font-weight-bold text-xl h5">
            Featured
        </div>
        <?php if(Auth::user()->type == 1): ?>
            <ul class="list-group list-group-flush font-weight-bold text-primary h6">
                <li class="list-group-item"><a href="<?php echo e(url('dashborad')); ?>">Home</a></li>
                <li class="list-group-item"><a href="viewAppointments">Apointments</a></li>
                <li class="list-group-item"><a href="<?php echo e(url('showcancelappointments')); ?>">Cancelled Appointments</a></li>
                <li class="list-group-item"><a href="profile">Create Doctor</a></li>
                <li class="list-group-item"><a href="<?php echo e(url('history')); ?>">History</a></li>
            </ul>
        <?php endif; ?>
        <?php if(Auth::user()->type == 2): ?>
            <ul class="list-group list-group-flush font-weight-bold text-primary h6">
                <li class="list-group-item"><a href="<?php echo e(url('dashborad')); ?>">Home</a></li>
                <li class="list-group-item"><a
                        href="<?php echo e(url('viewDoctorAppointments/' . Auth::user()->id)); ?>">Apointments
                    </a></li>
                <li class="list-group-item"><a href="<?php echo e(url('profile/' . Auth::user()->id)); ?>">Create Your Profile</a>
                </li>
                <li class="list-group-item"><a href="<?php echo e(url('doctorhistory/' . Auth::user()->id)); ?>">History</a></li>
            </ul>
        <?php endif; ?>
        <?php if(Auth::user()->type == 3): ?>
            <ul class="list-group list-group-flush font-weight-bold text-primary h6">
                <li class="list-group-item"><a href="<?php echo e(url('dashborad')); ?>">Home</a></li>
                <li class="list-group-item"><a href="<?php echo e(url('myAppointments/' . Auth::user()->id)); ?>">Apointments</a>
                </li>
                <li class="list-group-item"><a href="<?php echo e(url('history/' . Auth::user()->id)); ?>">History</a></li>
            </ul>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /var/www/html/bookingsystem/resources/views/common/sidebar.blade.php ENDPATH**/ ?>