<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('common/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-10 border border-primary p-5">
                <h4 class="font-weight-bold text-center text-primary">All Patients</h4>
                <br>
                <table class="table ">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Patient Name</th>
                            <th scope="col">Patient Age</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Email</th>
                            <th scope="col">Disease</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($getPatients): ?>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $getPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($i); ?></th>
                                    <td><?php echo e($value->fullname); ?></td>
                                    <td><?php echo e($value->age); ?></td>
                                    <td><?php echo e($value->gender); ?></td>
                                    <td><?php echo e($value->getPatientInfo->email); ?></td>
                                    <td><?php echo e($value->disease); ?></td>
                                </tr>
                                <?php
                                    $i++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/bookingsystem/resources/views/patientlist.blade.php ENDPATH**/ ?>