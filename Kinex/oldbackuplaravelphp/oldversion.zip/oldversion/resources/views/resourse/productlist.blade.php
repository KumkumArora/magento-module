<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2>Testing</h2>
        <br>
        <a href="{{ url('create') }}"><button class="btn btn-primary">Create</button></a>
        <br>
        <br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($product as $key => $values)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $values->productname }}</td>
                        <td>{{ $values->sku }}</td>
                        <td>{{ $values->price }}</td>
                        <td><a href="{{ action('ProController@show', $values->id) }}">View</a>
                            <a href="{{ action('ProductController@edit', $values->id) }}">edit</a>
                            <a href="{{ action('ProductController@destroy', $values->id) }}">Delete</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>
