<div class="form-edit form-custom">
    <div class="event">
        {{ Form::model($product, ['action' => $action == 'create' ? 'ProductController@store' : ['ProductController@update', $product->id], 'method' => 'post', 'id' => 'add_product_form']) }}
        <div class="row">

            <div class="form-group">
                {{ Form::Label('productname', 'Product Name') }}
                {{ Form::text('productname', $product->productname, ['id' => 'productname', 'class' => 'input-text border-style required']) }}
            </div>


            <div class="form-group">
                {{ Form::Label('sku', 'Product SKU') }}
                {{ Form::text('sku', $product->sku, ['id' => 'sku', 'class' => 'input-text border-style required']) }}
            </div>


            <div class="form-group">
                {{ Form::Label('price', 'Price') }}
                {{ Form::text('price', $product->price, ['class' => 'input-text border-style date']) }}
            </div>

            {{ Form::hidden('id', $product->id) }}
            <div class="from-group">
                {{ Form::submit($action == 'create' ? 'Create' : 'Update', ['class' => 'create-btn btn btn-primary', 'name' => 'add_product_form']) }}

            </div>
        </div>
    </div>
</div>
