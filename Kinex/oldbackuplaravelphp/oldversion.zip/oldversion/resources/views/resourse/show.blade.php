<h3>testing</h3>
{{ $product['productname'] }}
