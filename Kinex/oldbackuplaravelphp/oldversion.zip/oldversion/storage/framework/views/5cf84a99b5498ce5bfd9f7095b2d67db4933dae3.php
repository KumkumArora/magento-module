<?php echo e($user->firstname); ?>

<h1>Hello</h1>
<?php /**PATH /var/www/html/oldversion/resources/views/listing.blade.php ENDPATH**/ ?>