<h3>testing</h3>
<?php echo e($addProducts['productname']); ?>

<?php /**PATH /var/www/html/oldversion/resources/views/resourse/show.blade.php ENDPATH**/ ?>