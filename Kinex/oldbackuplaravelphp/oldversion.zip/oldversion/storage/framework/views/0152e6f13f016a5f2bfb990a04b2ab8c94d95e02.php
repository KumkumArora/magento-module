<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listing</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2>Testing</h2>
        <br>
        <a href="<?php echo e(url('create')); ?>"><button class="btn btn-primary">Create</button></a>
        <br>
        <br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($values->productname); ?></td>
                        <td><?php echo e($values->sku); ?></td>
                        <td><?php echo e($values->price); ?></td>
                        <td><a href="<?php echo e(action('ProController@show', $values->id)); ?>">View</a>
                            <a href="<?php echo e(action('ProductController@edit', $values->id)); ?>">edit</a>
                            <a href="<?php echo e(action('ProductController@destroy', $values->id)); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH /var/www/html/oldversion/resources/views/resourse/productlist.blade.php ENDPATH**/ ?>