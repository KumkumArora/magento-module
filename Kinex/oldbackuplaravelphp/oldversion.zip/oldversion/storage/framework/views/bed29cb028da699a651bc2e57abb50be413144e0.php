<div class="form-edit form-custom">
    <div class="event">
        <?php echo e(Form::model($product, ['action' => $action == 'create' ? 'ProductController@store' : ['ProductController@update', $product->id], 'method' => 'post', 'id' => 'add_product_form'])); ?>

        <div class="row">

            <div class="form-group">
                <?php echo e(Form::Label('productname', 'Product Name')); ?>

                <?php echo e(Form::text('productname', $product->productname, ['id' => 'productname', 'class' => 'input-text border-style required'])); ?>

            </div>


            <div class="form-group">
                <?php echo e(Form::Label('sku', 'Product SKU')); ?>

                <?php echo e(Form::text('sku', $product->sku, ['id' => 'sku', 'class' => 'input-text border-style required'])); ?>

            </div>


            <div class="form-group">
                <?php echo e(Form::Label('price', 'Price')); ?>

                <?php echo e(Form::text('price', $product->price, ['class' => 'input-text border-style date'])); ?>

            </div>

            <?php echo e(Form::hidden('id', $product->id)); ?>

            <div class="from-group">
                <?php echo e(Form::submit($action == 'create' ? 'Create' : 'Update', ['class' => 'create-btn btn btn-primary', 'name' => 'add_product_form'])); ?>


            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/oldversion/resources/views/resourse/form.blade.php ENDPATH**/ ?>