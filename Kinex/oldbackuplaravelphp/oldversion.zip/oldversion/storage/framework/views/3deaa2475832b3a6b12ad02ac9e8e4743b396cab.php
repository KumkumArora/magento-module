<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>
    <div class="container">
        <h1>Testing</h1>
        <form method="post" action="<?php echo e(url('submit')); ?>">
            <?php echo csrf_field(); ?>
            <label>FirstName</label>
            <input type="text" name="firstname">
            <br>
            <label>Lastname</label>
            <input type="text" name="lastname">
            <br>
            <label>Email</label>
            <input type="text" name="email">
            <br>
            <label>Address</label>
            <input type="text" name="address">
            <br>
            <label>Phone</label>
            <input type="text" name="phone">
            <br>
            <button type="submit" class="btn btn-primary">Sign in</button>
        </form>
        <br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $getUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($values->firstname); ?></td>
                        <td><?php echo e($values->lastname); ?></td>
                        <td><?php echo e($values->email); ?></td>
                        <td><a href="<?php echo e(url('view', $values->id)); ?>">View</a>
                            <a href="<?php echo e(url('delete', $values->id)); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

</body>

</html>
<?php /**PATH /var/www/html/oldversion/resources/views/index.blade.php ENDPATH**/ ?>